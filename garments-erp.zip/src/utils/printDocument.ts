/**
 * Bulletproof Print Utility for Texware Apparels Garments ERP
 * Works reliably across all functions, modals, webviews, and standalone windows.
 */

interface PrintOptions {
  title?: string;
  landscape?: boolean;
}

const COMMON_PRINT_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap');

  * {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
    color-adjust: exact !important;
  }

  body, html {
    margin: 0 !important;
    padding: 0 !important;
    background: #ffffff !important;
    color: #0f172a !important;
    font-family: 'Hind Siliguri', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
    font-size: 11px !important;
    line-height: 1.4 !important;
    overflow: visible !important;
  }

  .garments-print-wrapper {
    width: 100% !important;
    max-width: 100% !important;
    padding: 6mm !important;
    background: #ffffff !important;
    color: #0f172a !important;
    box-sizing: border-box !important;
  }

  /* Table styling */
  table {
    width: 100% !important;
    border-collapse: collapse !important;
    margin-top: 8px !important;
    margin-bottom: 8px !important;
    page-break-inside: auto !important;
  }

  tr {
    page-break-inside: avoid !important;
    break-inside: avoid !important;
    page-break-after: auto !important;
  }

  thead {
    display: table-header-group !important;
  }

  tfoot {
    display: table-footer-group !important;
  }

  th, td {
    border: 1px solid #cbd5e1 !important;
    padding: 5px 8px !important;
    text-align: left;
    font-size: 11px !important;
  }

  th {
    background-color: #f1f5f9 !important;
    font-weight: 700 !important;
    color: #1e293b !important;
  }

  .text-center { text-align: center !important; }
  .text-right { text-align: right !important; }
  .text-left { text-align: left !important; }
  .font-bold { font-weight: 700 !important; }
  .font-black { font-weight: 900 !important; }
  .font-mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important; }

  /* Official Print Header */
  .print-header {
    text-align: center !important;
    margin-bottom: 14px !important;
    padding-bottom: 8px !important;
    border-bottom: 2px solid #064e3b !important;
  }

  .company-title {
    font-size: 20px !important;
    font-weight: 800 !important;
    color: #064e3b !important;
    margin: 0 !important;
    letter-spacing: -0.02em !important;
  }

  .company-sub {
    font-size: 11px !important;
    color: #475569 !important;
    margin: 3px 0 !important;
  }

  .doc-title {
    display: inline-block !important;
    margin-top: 6px !important;
    padding: 4px 16px !important;
    background: #064e3b !important;
    color: #ffffff !important;
    font-size: 12px !important;
    font-weight: 700 !important;
    border-radius: 4px !important;
  }

  /* Summary Strip */
  .summary-strip {
    display: flex !important;
    flex-wrap: wrap !important;
    justify-content: space-between !important;
    gap: 8px !important;
    margin-bottom: 12px !important;
    padding: 8px 12px !important;
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 6px !important;
    font-size: 11px !important;
  }

  /* Flex & Grid Layouts in Print */
  .flex { display: flex !important; }
  .inline-flex { display: inline-flex !important; }
  .flex-col { flex-direction: column !important; }
  .items-center { align-items: center !important; }
  .justify-between { justify-content: space-between !important; }
  .justify-center { justify-content: center !important; }
  .justify-end { justify-content: flex-end !important; }
  .grid { display: grid !important; }
  .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)) !important; }
  .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
  .grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)) !important; }
  .grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)) !important; }
  .grid-cols-6 { grid-template-columns: repeat(6, minmax(0, 1fr)) !important; }
  .gap-1 { gap: 4px !important; }
  .gap-2 { gap: 8px !important; }
  .gap-3 { gap: 12px !important; }
  .gap-4 { gap: 16px !important; }
  .gap-6 { gap: 24px !important; }

  /* Backgrounds & Borders */
  .bg-white { background-color: #ffffff !important; }
  .bg-slate-50 { background-color: #f8fafc !important; }
  .bg-slate-100 { background-color: #f1f5f9 !important; }
  .bg-emerald-50 { background-color: #ecfdf5 !important; }
  .bg-emerald-600 { background-color: #059669 !important; color: #ffffff !important; }
  .bg-emerald-700 { background-color: #047857 !important; color: #ffffff !important; }
  .bg-emerald-800 { background-color: #065f46 !important; color: #ffffff !important; }
  .border { border: 1px solid #cbd5e1 !important; }
  .border-b { border-bottom: 1px solid #cbd5e1 !important; }
  .border-t { border-top: 1px solid #cbd5e1 !important; }
  .rounded-lg { border-radius: 6px !important; }
  .rounded-xl { border-radius: 8px !important; }
  .rounded-2xl { border-radius: 12px !important; }
  .p-2 { padding: 8px !important; }
  .p-3 { padding: 12px !important; }
  .p-4 { padding: 16px !important; }
  .p-5 { padding: 20px !important; }
  .p-6 { padding: 24px !important; }

  /* Status Badges */
  .badge {
    display: inline-block !important;
    padding: 2px 8px !important;
    border-radius: 4px !important;
    font-size: 10px !important;
    font-weight: 700 !important;
  }
  .badge-paid { background: #d1fae5 !important; color: #065f46 !important; border: 1px solid #a7f3d0 !important; }
  .badge-partial { background: #fef3c7 !important; color: #92400e !important; border: 1px solid #fde68a !important; }
  .badge-due { background: #fee2e2 !important; color: #991b1b !important; border: 1px solid #fecaca !important; }

  /* ID Cards Grid Print Specification */
  #id-cards-container {
    display: grid !important;
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 16px !important;
    width: 100% !important;
  }

  .id-card-print-item {
    page-break-inside: avoid !important;
    break-inside: avoid !important;
    margin-bottom: 16px !important;
    max-width: 100% !important;
  }

  /* Printable Sheets */
  #printable-payslip,
  #printable-invoice,
  #printable-report,
  #printable-attendance-sheet,
  #printable-attendance-table,
  #printable-worker-register,
  #printable-worker-profile,
  #printable-gatepass,
  #printable-dashboard-content,
  #printable-sms-logs {
    border: none !important;
    box-shadow: none !important;
    width: 100% !important;
    max-width: 100% !important;
    max-height: none !important;
    height: auto !important;
    padding: 0 !important;
    margin: 0 !important;
    overflow: visible !important;
    display: block !important;
  }

  /* Official Signatures Grid */
  .signature-grid {
    display: grid !important;
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 40px !important;
    margin-top: 36px !important;
    padding-top: 8px !important;
    text-align: center !important;
    page-break-inside: avoid !important;
    break-inside: avoid !important;
  }

  .signature-grid.cols-4 {
    grid-template-columns: repeat(4, 1fr) !important;
    gap: 16px !important;
  }

  .signature-line {
    border-top: 1px dashed #64748b !important;
    padding-top: 4px !important;
    font-size: 11px !important;
    font-weight: 600 !important;
    color: #334155 !important;
  }

  /* Hide UI elements and print controls */
  .no-print,
  .print\\:hidden,
  button,
  nav,
  aside,
  header {
    display: none !important;
  }

  /* Display elements that are print only */
  .print\\:block,
  .print-only {
    display: block !important;
  }
  .print\\:grid {
    display: grid !important;
  }
  .print\\:flex {
    display: flex !important;
  }
`;

/**
 * Universal print handler that works smoothly across all browsers & views
 */
export function printHtml(htmlContent: string, options: PrintOptions = {}) {
  const { title = 'কারখানা_ডকুমেন্ট_প্রিন্ট', landscape = false } = options;

  let mount = document.getElementById('garments-print-mount');
  if (!mount) {
    mount = document.createElement('div');
    mount.id = 'garments-print-mount';
    document.body.appendChild(mount);
  }

  const prevTitle = document.title;
  document.title = title;

  mount.innerHTML = `
    <style>
      @page {
        size: ${landscape ? 'A4 landscape' : 'A4 portrait'};
        margin: 8mm 10mm;
      }
      ${COMMON_PRINT_CSS}
    </style>
    <div class="garments-print-wrapper">
      ${htmlContent}
    </div>
  `;

  document.body.classList.add('garments-printing-active');

  const cleanup = () => {
    document.title = prevTitle;
    document.body.classList.remove('garments-printing-active');
    if (mount) {
      mount.innerHTML = '';
    }
  };

  try {
    window.addEventListener('afterprint', cleanup, { once: true });
    setTimeout(cleanup, 12000);
    window.print();
    return true;
  } catch (printErr) {
    console.warn('Direct window.print encountered issue, using fallback tab', printErr);
    cleanup();
    return openReportInNewTab(htmlContent, title);
  }
}

/**
 * Open report in a standalone new window/tab with instant print button and preview
 */
export function openReportInNewTab(htmlContent: string, title: string = 'ডকুমেন্ট প্রিন্ট') {
  const fullHtml = `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    @page { size: A4 portrait; margin: 8mm 10mm; }
    ${COMMON_PRINT_CSS}
    body { font-family: 'Hind Siliguri', sans-serif; margin: 0; padding: 20px; background: #f8fafc; color: #0f172a; }
    .print-actions {
      display: flex; gap: 12px; align-items: center; justify-content: space-between;
      margin-bottom: 20px; padding: 12px 20px; background: #0f172a; color: white;
      border-radius: 10px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
    }
    .print-btn {
      background: #059669; color: white; border: none; padding: 8px 18px;
      font-size: 13px; font-weight: bold; border-radius: 6px; cursor: pointer;
    }
    .print-btn:hover { background: #047857; }
    .close-btn {
      background: #475569; color: white; border: none; padding: 8px 14px;
      font-size: 13px; border-radius: 6px; cursor: pointer;
    }
    .sheet {
      background: #ffffff; padding: 30px; border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05); max-width: 960px; margin: 0 auto;
    }
    @media print {
      body { background: #ffffff !important; padding: 0 !important; }
      .no-print, .print-actions { display: none !important; }
      .sheet { box-shadow: none !important; padding: 0 !important; max-width: 100% !important; }
    }
  </style>
</head>
<body>
  <div class="print-actions no-print">
    <div style="font-weight: bold; font-size: 14px;">🖨️ ${title} • টেক্স ওয়্যার অ্যাপারেলস</div>
    <div style="display: flex; gap: 10px;">
      <button class="print-btn" onclick="window.print()">🖨️ এখনই প্রিন্ট করুন / Save PDF</button>
      <button class="close-btn" onclick="window.close()">✖ বন্ধ করুন</button>
    </div>
  </div>
  <div class="sheet">
    ${htmlContent}
  </div>
</body>
</html>`;

  try {
    const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
    const blobUrl = URL.createObjectURL(blob);
    const win = window.open(blobUrl, '_blank');
    if (win) {
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
      return true;
    }
  } catch (err) {
    console.warn('Failed to open window', err);
  }
  return false;
}

/**
 * Print an element on the page by its DOM ID, preserving container ID, classes and styling
 */
export function printElementById(elementId: string, title: string = 'ডকুমেন্ট প্রিন্ট', landscape: boolean = false) {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with id ${elementId} not found, falling back to full page print`);
    window.print();
    return;
  }
  // Use outerHTML so container IDs (#id-cards-container, #printable-worker-register, etc.) and attributes remain intact
  printHtml(element.outerHTML, { title, landscape });
}
