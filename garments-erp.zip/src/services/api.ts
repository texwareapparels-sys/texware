const API_BASE = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('garments_erp_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || 'অনুরোধটি সম্পন্ন করা যায়নি');
  }
  return data as T;
}

function toQueryString(params?: Record<string, any>): string {
  if (!params) return '';
  const clean: Record<string, string> = {};
  Object.entries(params).forEach(([key, val]) => {
    if (val !== undefined && val !== null && val !== '' && val !== 'all' && val !== 'সব বিভাগ' && val !== 'undefined') {
      clean[key] = String(val);
    }
  });
  const q = new URLSearchParams(clean).toString();
  return q ? `?${q}` : '';
}

export const api = {
  // Auth
  login: (credentials: { username: string; password: string }) =>
    request<{ success: boolean; token: string; user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),
  changePassword: (data: { currentPassword?: string; newPassword: string }) =>
    request<{ success: boolean; message: string }>('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  getMe: () => request<{ user: any }>('/auth/me'),
  logout: () => request<{ success: boolean }>('/auth/logout', { method: 'POST' }),

  // Dashboard
  getDashboardStats: () => request<any>('/dashboard/stats'),
  getDashboardSummary: () => request<any>('/dashboard/stats'),

  // Settings
  getSettings: () => request<any>('/settings'),
  updateSettings: (data: any) =>
    request<{ success: boolean; message: string }>('/settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  // Users & Audit
  getUsers: () => request<any[]>('/users'),
  createUser: (data: any) => request<{ success: boolean; id: number }>('/users', { method: 'POST', body: JSON.stringify(data) }),
  updateUser: (id: number, data: any) => request<{ success: boolean }>(`/users/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  getAuditLogs: () => request<any[]>('/audit-logs'),

  // Employees
  getEmployees: (params?: { department?: string; status?: string; search?: string; employee_type?: string }) => {
    return request<any[]>(`/employees${toQueryString(params)}`);
  },
  getEmployeeDetail: (id: number) => request<any>(`/employees/${id}`),
  createEmployee: (data: any) => request<any>('/employees', { method: 'POST', body: JSON.stringify(data) }),
  updateEmployee: (id: number, data: any) => request<any>(`/employees/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteEmployee: (id: number) => request<{ success: boolean; message: string }>(`/employees/${id}`, { method: 'DELETE' }),
  seedSampleEmployees: () => request<{ success: boolean; count: number }>('/employees/seed-samples', { method: 'POST' }),
  clearDemoEmployees: () => request<{ success: boolean; count: number; message: string }>('/employees/clear-demo', { method: 'POST' }),

  // Attendance & Leaves & Gatepass
  getAttendance: (date: string, department?: string) =>
    request<any[]>(`/attendance?date=${encodeURIComponent(date)}${department ? '&department=' + encodeURIComponent(department) : ''}`),
  markAttendance: (data: any) => request<any>('/attendance', { method: 'POST', body: JSON.stringify(data) }),
  markBulkAttendance: (data: { date: string; items: any[] }) =>
    request<any>('/attendance/bulk', { method: 'POST', body: JSON.stringify(data) }),
  deleteAttendanceRecord: (id: number) => request<any>(`/attendance/${id}`, { method: 'DELETE' }),
  clearAttendanceDay: (date: string, employeeId?: number) =>
    request<any>(`/attendance/clear-day/${encodeURIComponent(date)}${employeeId ? '?employee_id=' + employeeId : ''}`, { method: 'DELETE' }),
  
  getLeaves: () => request<any[]>('/leaves'),
  createLeave: (data: any) => request<any>('/leaves', { method: 'POST', body: JSON.stringify(data) }),

  getGatePasses: () => request<any[]>('/gate-passes'),
  createGatePass: (data: any) => request<any>('/gate-passes', { method: 'POST', body: JSON.stringify(data) }),
  returnGatePass: (id: number, data: any) => request<any>(`/gate-passes/${id}/return`, { method: 'PUT', body: JSON.stringify(data) }),

  // Payroll
  getPayrollPeriods: () => request<any[]>('/payroll/periods'),
  getPayrollPeriodDetail: (id: number) => request<any>(`/payroll/periods/${id}`),
  generatePayroll: (month_year: string) =>
    request<any>('/payroll/generate', { method: 'POST', body: JSON.stringify({ month_year }) }),
  updatePayrollItem: (id: number, data: any) =>
    request<any>(`/payroll/items/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deletePayrollItem: (id: number) =>
    request<any>(`/payroll/items/${id}`, { method: 'DELETE' }),
  deletePayrollPeriod: (id: number) =>
    request<any>(`/payroll/periods/${id}`, { method: 'DELETE' }),
  updatePayrollStatus: (id: number, status: string) =>
    request<any>(`/payroll/periods/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }),
  paySalary: (itemId: number, data: any) =>
    request<any>(`/payroll/items/${itemId}/pay`, { method: 'POST', body: JSON.stringify(data) }),

  // Products & Inventory & Production
  getProducts: () => request<any[]>('/products'),
  createProduct: (data: any) => request<any>('/products', { method: 'POST', body: JSON.stringify(data) }),
  updateProduct: (id: number, data: any) => request<any>(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteProduct: (id: number) => request<any>(`/products/${id}`, { method: 'DELETE' }),
  addVariant: (productId: number, data: any) => request<any>(`/products/${productId}/variants`, { method: 'POST', body: JSON.stringify(data) }),
  getProduction: () => request<any[]>('/production'),
  recordProduction: (data: any) => request<any>('/production', { method: 'POST', body: JSON.stringify(data) }),
  garmentsStockEntry: (data: any) => request<any>('/garments/stock-entry', { method: 'POST', body: JSON.stringify(data) }),
  deleteProduction: (id: number) => request<any>(`/production/${id}`, { method: 'DELETE' }),
  deleteProductionBatch: (batchNo: string) => request<any>(`/production/batch/${encodeURIComponent(batchNo)}`, { method: 'DELETE' }),
  deleteColorStock: (data: { category?: string; color: string; product_id?: number }) =>
    request<any>('/inventory/color-stock', { method: 'DELETE', body: JSON.stringify(data) }),
  adjustInventory: (data: any) => request<any>('/inventory/adjust', { method: 'POST', body: JSON.stringify(data) }),

  // Wholesale Shops & Sales
  getShops: () => request<any[]>('/shops'),
  createShop: (data: any) => request<any>('/shops', { method: 'POST', body: JSON.stringify(data) }),
  updateShop: (id: number, data: any) => request<any>(`/shops/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteShop: (id: number) => request<any>(`/shops/${id}`, { method: 'DELETE' }),
  getSales: () => request<any[]>('/sales'),
  getSaleDetail: (id: number) => request<any>(`/sales/${id}`),
  createSale: (data: any) => request<any>('/sales', { method: 'POST', body: JSON.stringify(data) }),
  updateSale: (id: number, data: any) => request<any>(`/sales/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSale: (id: number) => request<any>(`/sales/${id}`, { method: 'DELETE' }),

  // Expenses & Collections & Accounts
  getExpenses: (params?: { category?: string; start?: string; end?: string }) => {
    return request<any[]>(`/expenses${toQueryString(params)}`);
  },
  createExpense: (data: any) => request<any>('/expenses', { method: 'POST', body: JSON.stringify(data) }),
  deleteExpense: (id: number) => request<any>(`/expenses/${id}`, { method: 'DELETE' }),
  clearAllExpenses: () => request<any>('/expenses/clear-all', { method: 'POST' }),
  getCollections: () => request<any[]>('/collections'),
  recordCollection: (data: any) => request<any>('/collections', { method: 'POST', body: JSON.stringify(data) }),
  createCollection: (data: any) => request<any>('/collections', { method: 'POST', body: JSON.stringify(data) }),
  recordShopCollection: (data: any) => request<any>('/collections', { method: 'POST', body: JSON.stringify(data) }),
  deleteCollection: (id: number) => request<any>(`/collections/${id}`, { method: 'DELETE' }),
  clearAllCollections: () => request<any>('/collections/clear-all', { method: 'POST' }),
  clearAccountingData: (target: 'expenses' | 'collections' | 'sales' | 'all') =>
    request<any>('/accounting/clear', { method: 'POST', body: JSON.stringify({ target }) }),
  getAccountingSummary: () => request<any>('/accounting/summary'),
  getFinancialStats: () => request<any>('/accounting/summary'),
  getAnalyticsReport: (params?: { month?: string }) => request<any>(`/reports/analytics${toQueryString(params)}`),
  deleteReportPeriod: (month: string, delete_type: string = 'all') =>
    request<any>(`/reports/period/${encodeURIComponent(month)}`, { method: 'DELETE', body: JSON.stringify({ delete_type }) }),

  // SMS
  getSmsLogs: () => request<any[]>('/sms/logs'),
  deleteSmsLog: (id: number) => request<any>(`/sms/logs/${id}`, { method: 'DELETE' }),
  clearSmsLogs: () => request<any>('/sms/logs', { method: 'DELETE' }),
  sendSms: (data: { recipients: { phone: string; name?: string }[]; message: string; template_type: string }) =>
    request<any>('/sms/send', { method: 'POST', body: JSON.stringify(data) }),
  sendTestSms: (data: { mobile: string; message: string }) =>
    request<any>('/sms/send', {
      method: 'POST',
      body: JSON.stringify({
        recipients: [{ phone: data.mobile, name: 'Test' }],
        message: data.message,
        template_type: 'custom',
      }),
    }),

  // Backup & Google Sheets
  getBackupStatus: () => request<any>('/backup/status'),
  syncBackup: (sync_type: string = 'all') =>
    request<any>('/backup/sync', { method: 'POST', body: JSON.stringify({ sync_type }) }),
  syncGoogleSheets: (sheet_id?: string) =>
    request<any>('/backup/sync', { method: 'POST', body: JSON.stringify({ sync_type: 'sheets', sheet_id }) }),

  // Data Reset
  clearAllData: () => request<{ success: boolean; message: string }>('/admin/clear-all-data', { method: 'POST' }),
};
