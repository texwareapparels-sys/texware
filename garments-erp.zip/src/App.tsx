import React, { useState } from 'react';
import { ToastProvider } from './components/common/Toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginView } from './components/auth/LoginView';
import { ChangePasswordModal } from './components/auth/ChangePasswordModal';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';

import { DashboardView } from './components/dashboard/DashboardView';
import { EmployeesView } from './components/employees/EmployeesView';
import { AttendanceView } from './components/attendance/AttendanceView';
import { PayrollView } from './components/payroll/PayrollView';
import { IdCardView } from './components/idcards/IdCardView';
import { SettingsView } from './components/settings/SettingsView';
import { SmsNotificationView } from './components/sms/SmsNotificationView';
import { QuickActionType } from './components/layout/Header';

const MainLayout: React.FC = () => {
  const { user, loading } = useAuth();
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [desktopSidebarOpen, setDesktopSidebarOpen] = useState(true);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

  const handleToggleMenu = () => {
    if (window.innerWidth < 1024) {
      setMobileMenuOpen((prev) => !prev);
    } else {
      setDesktopSidebarOpen((prev) => !prev);
    }
  };

  const handleQuickAction = (action: QuickActionType) => {
    if (action === 'add_employee') {
      setCurrentView('employees');
    } else if (action === 'mark_attendance') {
      setCurrentView('attendance');
    } else if (action === 'payroll') {
      setCurrentView('payroll');
    } else if (action === 'issue_gatepass') {
      setCurrentView('attendance');
    } else if (action === 'send_sms') {
      setCurrentView('sms');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center text-slate-800">
        <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-600 rounded-full animate-spin mb-4" />
        <p className="text-sm font-medium text-slate-600">গার্মেন্টস ইআরপি সিস্টেম লোড হচ্ছে...</p>
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <DashboardView
            onNavigate={(view) => setCurrentView(view)}
            onQuickAction={handleQuickAction}
          />
        );
      case 'employees':
        return <EmployeesView />;
      case 'attendance':
        return <AttendanceView />;
      case 'payroll':
        return <PayrollView />;
      case 'idcards':
        return <IdCardView />;
      case 'settings':
        return <SettingsView />;
      case 'sms':
        return <SmsNotificationView />;
      case 'backup':
        return <SettingsView initialTab="integrations" />;
      default:
        return (
          <DashboardView
            onNavigate={(view) => setCurrentView(view)}
            onQuickAction={handleQuickAction}
          />
        );
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-100/70 font-['Hind_Siliguri',sans-serif]">
      {/* Responsive Sidebar */}
      <Sidebar
        currentTab={currentView}
        currentView={currentView}
        setCurrentTab={(tab) => {
          setCurrentView(tab);
          setMobileMenuOpen(false);
        }}
        onNavigate={(view) => {
          setCurrentView(view);
          setMobileMenuOpen(false);
        }}
        isOpen={mobileMenuOpen}
        mobileOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        onCloseMobile={() => setMobileMenuOpen(false)}
        isDesktopOpen={desktopSidebarOpen}
      />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-300 print:pl-0 ${
          desktopSidebarOpen ? 'lg:pl-72' : 'lg:pl-0'
        }`}
      >
        <Header
          currentTab={currentView}
          currentView={currentView}
          onOpenSidebar={handleToggleMenu}
          onToggleSidebar={handleToggleMenu}
          onToggleMobileMenu={handleToggleMenu}
          onChangePassword={() => setIsPasswordModalOpen(true)}
          onOpenChangePassword={() => setIsPasswordModalOpen(true)}
          onQuickAction={handleQuickAction}
          onNavigate={(view) => setCurrentView(view)}
          isSidebarOpen={desktopSidebarOpen}
        />

        <main className="flex-1 p-3 sm:p-5 lg:p-6 overflow-y-auto max-w-7xl w-full mx-auto print:overflow-visible print:max-w-none print:p-0 print:m-0">
          {renderView()}
        </main>
      </div>

      {/* Change Password Modal */}
      <ChangePasswordModal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <MainLayout />
      </AuthProvider>
    </ToastProvider>
  );
}
