import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  hasPermission: (permission: string) => boolean;
  mustChangePassword: boolean;
  setMustChangePassword: (val: boolean) => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('garments_erp_token'));
  const [loading, setLoading] = useState<boolean>(true);
  const [mustChangePassword, setMustChangePassword] = useState<boolean>(false);

  const refreshUser = async () => {
    try {
      if (!localStorage.getItem('garments_erp_token')) {
        setUser(null);
        setLoading(false);
        return;
      }
      const data = await api.getMe();
      if (data.user) {
        setUser(data.user);
        setMustChangePassword(Boolean(data.user.must_change_password));
      } else {
        localStorage.removeItem('garments_erp_token');
        setUser(null);
      }
    } catch {
      localStorage.removeItem('garments_erp_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const login = async (username: string, password: string) => {
    const res = await api.login({ username, password });
    if (res.token && res.user) {
      localStorage.setItem('garments_erp_token', res.token);
      setToken(res.token);
      setUser(res.user);
      setMustChangePassword(Boolean(res.user.must_change_password));
    }
  };

  const logout = async () => {
    try {
      await api.logout();
    } catch {
      // Ignore network errors on logout
    } finally {
      localStorage.removeItem('garments_erp_token');
      setToken(null);
      setUser(null);
      setMustChangePassword(false);
    }
  };

  const hasPermission = (permission: string) => {
    if (!user) return false;
    if (user.role === 'admin') return true;
    return user.permissions?.includes(permission) ?? false;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        isAuthenticated: Boolean(user),
        login,
        logout,
        hasPermission,
        mustChangePassword,
        setMustChangePassword,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
