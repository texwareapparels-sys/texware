import React, { useState } from 'react';
import { Lock, ShieldCheck, AlertCircle } from 'lucide-react';
import { Modal } from '../common/Modal';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { api } from '../../services/api';

interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  isMandatory?: boolean;
}

export const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({
  isOpen,
  onClose,
  isMandatory = false,
}) => {
  const { setMustChangePassword, refreshUser } = useAuth();
  const { showToast } = useToast();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 4) {
      setError('নতুন পাসওয়ার্ড ন্যূনতম ৪ অক্ষরের হতে হবে');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('নতুন পাসওয়ার্ড এবং নিশ্চিতকরণ পাসওয়ার্ড মিলছে না');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const res = await api.changePassword({
        currentPassword: currentPassword || undefined,
        newPassword,
      });

      if (res.success) {
        showToast('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!', 'success');
        setMustChangePassword(false);
        await refreshUser();
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'পাসওয়ার্ড পরিবর্তন করা সম্ভব হয়নি');
      showToast(err.message || 'ব্যর্থ হয়েছে', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={isMandatory ? () => {} : onClose}
      title={isMandatory ? 'জরুরি: অস্থায়ী পাসওয়ার্ড পরিবর্তন করুন' : 'পাসওয়ার্ড পরিবর্তন'}
      subtitle={
        isMandatory
          ? 'নিরাপত্তা নিশ্চিত করতে ডেমো পাসওয়ার্ড পরিবর্তন করা বাধ্যতামূলক'
          : 'আপনার অ্যাকাউন্টের নিরাপত্তা হালনাগাদ করুন'
      }
      maxWidth="md"
    >
      {isMandatory && (
        <div className="mb-4 p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-start gap-2.5">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">অস্থায়ী ডেমো ক্রেডেনশিয়াল পরিবর্তন আবশ্যক</p>
            <p className="mt-0.5 text-amber-700">
              অ্যাপ্লিকেশনের সংবেদনশীল আর্থিক ও বেতন ডেটার সুরক্ষার জন্য আপনার নিজস্ব একটি নতুন পাসওয়ার্ড সেট করুন।
            </p>
          </div>
        </div>
      )}

      {error && (
        <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {!isMandatory && (
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1" htmlFor="current-pw">
              বর্তমান পাসওয়ার্ড
            </label>
            <input
              id="current-pw"
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
              required
            />
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1" htmlFor="new-pw">
            নতুন শক্তিশালী পাসওয়ার্ড
          </label>
          <input
            id="new-pw"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="ন্যূনতম ৪ অক্ষরের পাসওয়ার্ড"
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            required
            minLength={4}
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1" htmlFor="confirm-pw">
            নতুন পাসওয়ার্ড নিশ্চিত করুন
          </label>
          <input
            id="confirm-pw"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="পুনরায় নতুন পাসওয়ার্ড লিখুন"
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            required
            minLength={4}
          />
        </div>

        <div className="pt-2 flex justify-end gap-2.5">
          {!isMandatory && (
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              বাতিল
            </button>
          )}
          <button
            id="save-new-password-btn"
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-semibold rounded-xl transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{loading ? 'সংরক্ষণ হচ্ছে...' : 'পাসওয়ার্ড পরিবর্তন সংরক্ষণ করুন'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
