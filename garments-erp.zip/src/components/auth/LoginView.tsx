import React, { useState } from 'react';
import { Shirt, Lock, User, KeyRound, ShieldAlert, ArrowRight, Check } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';

export const LoginView: React.FC = () => {
  const { login } = useAuth();
  const { showToast } = useToast();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('1234');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('ব্যবহারকারীর নাম ও পাসওয়ার্ড দিন');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await login(username, password);
      showToast('লগইন সফল হয়েছে!', 'success');
    } catch (err: any) {
      setError(err.message || 'লগইন ব্যর্থ হয়েছে। ব্যবহারকারীর নাম বা পাসওয়ার্ড সঠিক নয়।');
      showToast(err.message || 'লগইন ব্যর্থ হয়েছে', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemo = () => {
    setUsername('admin');
    setPassword('1234');
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-100/90 flex items-center justify-center p-4 font-['Hind_Siliguri',sans-serif]">
      <div className="w-full max-w-md">
        {/* Brand Card */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-600 text-white mb-3 shadow-md shadow-emerald-600/30">
            <Shirt className="w-8 h-8" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            গার্মেন্টস ইআরপি (Garments ERP)
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-1">
            Smart Garments Management & Business Control System
          </p>
          <div className="inline-block mt-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200/80 text-xs text-emerald-800 font-medium">
            বাংলাদেশি নিট গার্মেন্টস ও পাইকারি গেঞ্জি ব্যবসা সংস্করণ
          </div>
        </div>

        {/* Login Container */}
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200/80 p-6 sm:p-8">
          <div className="mb-5">
            <h2 className="text-xl font-bold text-slate-800">অ্যাডমিন প্রবেশদ্বার (Admin Login)</h2>
            <p className="text-xs text-slate-500 mt-1">
              ব্যবসায়িক তথ্য ও কারখানার সম্পূর্ণ নিয়ন্ত্রণ প্যানেলে প্রবেশ করুন
            </p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="login-username">
                ব্যবহারকারীর নাম (Username)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="login-username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="যেমন: Demo"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all text-slate-800"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="login-password">
                পাসওয়ার্ড (Password)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="login-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all text-slate-800"
                  required
                />
              </div>
            </div>

            <button
              id="login-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold rounded-xl text-sm transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 mt-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>লগইন করুন</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Admin Credentials Box */}
          <div className="mt-6 pt-5 border-t border-slate-100">
            <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3.5">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
                  ডিফল্ট অ্যাডমিন লগইন
                </span>
                <button
                  type="button"
                  onClick={handleFillDemo}
                  className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 underline cursor-pointer"
                >
                  ক্লিক করে বসান
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 mt-2">
                <div className="bg-white p-2 rounded-lg border border-emerald-100 font-mono">
                  ইউজারনেম: <span className="font-bold text-slate-800">admin</span>
                </div>
                <div className="bg-white p-2 rounded-lg border border-emerald-100 font-mono">
                  পাসওয়ার্ড: <span className="font-bold text-slate-800">1234</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
                * সিস্টেমে প্রবেশ করে পাসওয়ার্ড ও সেটিংস প্রয়োজনমতো পরিবর্তন করে নিতে পারবেন।
              </p>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="text-center mt-6 text-xs text-slate-400">
          টেক্স ওয়্যার অ্যাপারেলস লিমিটেড • ইআরপি ম্যানেজমেন্ট সিস্টেম v2.4
        </div>
      </div>
    </div>
  );
};
