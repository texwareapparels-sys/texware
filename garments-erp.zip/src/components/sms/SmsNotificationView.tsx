import React, { useState, useEffect, useMemo } from 'react';
import {
  Send,
  MessageSquare,
  Users,
  CheckCircle2,
  AlertCircle,
  Trash2,
  RefreshCw,
  Search,
  Filter,
  Phone,
  Clock,
  Sparkles,
  Settings,
  DollarSign,
  Printer
} from 'lucide-react';
import { Employee } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { printElementById } from '../../utils/printDocument';

interface SmsLog {
  id: number;
  recipient_phone: string;
  recipient_name: string;
  message: string;
  template_type: string;
  status: string;
  response_id: string;
  sent_at: string;
  cost: number;
}

const TEMPLATES = [
  {
    id: 'salary',
    title: 'মাসিক বেতন পরিশোধের বার্তা',
    text: 'শ্রদ্ধেয় {নাম}, টেক্স ওয়্যার অ্যাপারেলস এ আপনার চলতি মাসের বেতন একাউন্টে পরিশোধ করা হয়েছে। বিস্তারিত স্লিপ হিসাব শাখা থেকে সংগ্রহ করুন। ধন্যবাদ।',
  },
  {
    id: 'overtime',
    title: 'জরুরি ওভারটাইম নোটিশ',
    text: 'জরুরি নোটিশ: সম্মানিত কর্মী {নাম}, জরুরি শিপমেন্ট অর্ডারের কারণে আজ কারখানায় অতিরিক্ত ওভারটাইম ডিউটি চলবে। সকলের আন্তরিক সহযোগিতা কাম্য - টেক্স ওয়্যার অ্যাপারেলস।',
  },
  {
    id: 'holiday',
    title: 'ছুটি ও কারখানা বন্ধের নোটিশ',
    text: 'বিশেষ বিজ্ঞপ্তি: সম্মানিত {নাম}, আগামী {তারিখ} তারিখে কারখানা সাধারণ ছুটি উপলক্ষে বন্ধ থাকবে। পরবর্তী কর্মদিবসে যথাসময়ে উপস্থিত থাকার অনুরোধ করা হলো - টেক্স ওয়্যার অ্যাপারেলস।',
  },
  {
    id: 'festival',
    title: 'ঈদ / উৎসব শুভেচ্ছা ও বোনাস',
    text: 'ঈদ মোবারক! সম্মানিত {নাম}, টেক্স ওয়্যার অ্যাপারেলস পরিবারের পক্ষ থেকে আপনাকে ও আপনার পরিবারকে আন্তরিক শুভেচ্ছা। আপনার উৎসব বোনাস প্রদান করা হয়েছে।',
  },
  {
    id: 'general',
    title: 'সাধারণ বার্তা (কাস্টম)',
    text: 'শ্রদ্ধেয় {নাম}, টেক্স ওয়্যার অ্যাপারেলস এর পক্ষ থেকে আপনাকে অবহিত করা যাচ্ছে যে...',
  },
];

export const SmsNotificationView: React.FC = () => {
  const { showToast } = useToast();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [smsLogs, setSmsLogs] = useState<SmsLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  // Selection & Filters
  const [selectedDept, setSelectedDept] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEmpIds, setSelectedEmpIds] = useState<number[]>([]);

  // Message Form
  const [selectedTemplateId, setSelectedTemplateId] = useState('salary');
  const [messageText, setMessageText] = useState(TEMPLATES[0].text);
  const [activeTab, setActiveTab] = useState<'compose' | 'logs'>('compose');

  // Single test modal
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [testMobile, setTestMobile] = useState('');
  const [testMessage, setTestMessage] = useState('টেক্স ওয়্যার অ্যাপারেলস: টেস্ট এসএমএস সফলভাবে প্রাপ্ত হয়েছে।');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [empData, logsData] = await Promise.all([
        api.getEmployees(),
        api.getSmsLogs().catch(() => []),
      ]);
      // Filter out inactive or resigned employees for SMS
      const activeEmps = (empData || []).filter((e) => e.status !== 'resigned');
      setEmployees(activeEmps);
      setSmsLogs(logsData || []);
    } catch (err: any) {
      showToast(err.message || 'ডাটা লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Filtered employee list
  const filteredEmployees = useMemo(() => {
    return employees.filter((e) => {
      const matchesDept = selectedDept === 'all' || e.department === selectedDept;
      const q = searchTerm.toLowerCase();
      const matchesSearch =
        !searchTerm ||
        e.name_bn.toLowerCase().includes(q) ||
        (e.name_en || '').toLowerCase().includes(q) ||
        e.employee_code.toLowerCase().includes(q) ||
        (e.phone || '').includes(q);
      return matchesDept && matchesSearch && Boolean(e.phone);
    });
  }, [employees, selectedDept, searchTerm]);

  // Select all visible
  const handleToggleSelectAll = () => {
    if (selectedEmpIds.length === filteredEmployees.length && filteredEmployees.length > 0) {
      setSelectedEmpIds([]);
    } else {
      setSelectedEmpIds(filteredEmployees.map((e) => e.id));
    }
  };

  const handleToggleEmp = (id: number) => {
    setSelectedEmpIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleTemplateChange = (tmplId: string) => {
    setSelectedTemplateId(tmplId);
    const tmpl = TEMPLATES.find((t) => t.id === tmplId);
    if (tmpl) {
      setMessageText(tmpl.text);
    }
  };

  const handleSendBulkSms = async () => {
    if (selectedEmpIds.length === 0) {
      showToast('অনুগ্রহ করে কমপক্ষে একজন কর্মী নির্বাচন করুন', 'error');
      return;
    }
    if (!messageText.trim()) {
      showToast('বার্তা লিখুন', 'error');
      return;
    }

    const selectedList = employees.filter((e) => selectedEmpIds.includes(e.id));
    const recipients = selectedList.map((e) => ({
      phone: e.phone,
      name: e.name_bn || e.name_en || 'কর্মী',
    }));

    setSending(true);
    try {
      const res = await api.sendSms({
        recipients,
        message: messageText,
        template_type: selectedTemplateId,
      });

      showToast(res.message || `${recipients.length} টি এসএমএস সফলভাবে পাঠানো হয়েছে`, 'success');
      setSelectedEmpIds([]);
      fetchData();
      setActiveTab('logs');
    } catch (err: any) {
      showToast(err.message || 'এসএমএস পাঠাতে সমস্যা হয়েছে', 'error');
    } finally {
      setSending(false);
    }
  };

  const handleSendTestSms = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testMobile.trim()) {
      showToast('মোবাইল নম্বর লিখুন', 'error');
      return;
    }
    setSending(true);
    try {
      await api.sendSms({
        recipients: [{ phone: testMobile.trim(), name: 'টেস্ট প্রাপক' }],
        message: testMessage,
        template_type: 'test',
      });
      showToast('টেস্ট এসএমএস সফলভাবে প্রেরণ করা হয়েছে', 'success');
      setIsTestModalOpen(false);
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'এসএমএস প্রেরণ ব্যর্থ', 'error');
    } finally {
      setSending(false);
    }
  };

  const handleDeleteLog = async (id: number) => {
    try {
      await api.deleteSmsLog(id);
      showToast('এসএমএস লগ মুছে ফেলা হয়েছে', 'success');
      setSmsLogs((prev) => prev.filter((l) => l.id !== id));
    } catch (err: any) {
      showToast(err.message || 'লগ মুছতে সমস্যা হয়েছে', 'error');
    }
  };

  const handleClearAllLogs = async () => {
    if (!confirm('আপনি কি নিশ্চিত যে সকল এসএমএস হিস্ট্রি মুছে ফেলতে চান?')) return;
    try {
      await api.clearSmsLogs();
      showToast('সকল এসএমএস লগ মুছে ফেলা হয়েছে', 'success');
      setSmsLogs([]);
    } catch (err: any) {
      showToast(err.message || 'লগ মুছতে সমস্যা হয়েছে', 'error');
    }
  };

  // Departments
  const departments = useMemo(() => {
    const set = new Set<string>();
    employees.forEach((e) => {
      if (e.department) set.add(e.department);
    });
    return Array.from(set);
  }, [employees]);

  return (
    <div className="space-y-5 pb-12 font-['Hind_Siliguri',sans-serif]">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <MessageSquare className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              বাংলা এসএমএস নোটিফিকেশন সেন্টার (SMS Broadcasting)
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            টেক্স ওয়্যার অ্যাপারেলস • কারখানা শ্রমিক ও কর্মচারীদের মোবাইল নম্বরে একক অথবা একযোগে বাল্ক বার্তা প্রেরণ
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsTestModalOpen(true)}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Phone className="w-4 h-4 text-emerald-600" />
            <span>টেস্ট এসএমএস পাঠান</span>
          </button>

          <button
            onClick={() => fetchData()}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            title="রিফ্রেশ"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tabs: Compose vs History */}
      <div className="flex border-b border-slate-200 text-xs font-semibold gap-2">
        <button
          onClick={() => setActiveTab('compose')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors flex items-center gap-2 ${
            activeTab === 'compose'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Send className="w-4 h-4" />
          <span>বার্তা তৈরি ও একযোগে প্রেরণ</span>
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors flex items-center gap-2 ${
            activeTab === 'logs'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>প্রেরিত এসএমএস হিস্ট্রি ও লগ ({smsLogs.length} টি)</span>
        </button>
      </div>

      {/* TAB 1: COMPOSE & SEND */}
      {activeTab === 'compose' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Column: Worker Selection (7 cols) */}
          <div className="lg:col-span-7 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>কর্মী নির্বাচন ({selectedEmpIds.length} জন নির্বাচিত)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  যাদের মোবাইল নম্বরে এসএমএস পৌঁছাবে তাদের টিক দিন
                </p>
              </div>

              <button
                onClick={handleToggleSelectAll}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer transition-colors"
              >
                {selectedEmpIds.length === filteredEmployees.length && filteredEmployees.length > 0
                  ? 'সিলেক্ট বাতিল'
                  : 'সবাইকে সিলেক্ট করুন'}
              </button>
            </div>

            {/* Department & Search Filters */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="নাম, কোড বা ফোন খুঁজুন..."
                  className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:border-emerald-500"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
              </div>

              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:border-emerald-500 font-medium"
              >
                <option value="all">সকল সেকশন ({employees.length} জন)</option>
                {departments.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            {/* Employee Selection List */}
            <div className="border border-slate-200 rounded-xl overflow-y-auto max-h-[420px] divide-y divide-slate-100">
              {loading ? (
                <div className="p-8 text-center text-slate-400 text-xs">কর্মী তালিকা লোড হচ্ছে...</div>
              ) : filteredEmployees.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  কোনো কর্মী পাওয়া যায়নি বা বৈধ ফোন নম্বর নেই
                </div>
              ) : (
                filteredEmployees.map((emp) => {
                  const isChecked = selectedEmpIds.includes(emp.id);
                  return (
                    <div
                      key={emp.id}
                      onClick={() => handleToggleEmp(emp.id)}
                      className={`p-2.5 flex items-center justify-between cursor-pointer text-xs transition-colors ${
                        isChecked ? 'bg-emerald-50/70' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-slate-800 truncate">
                            {emp.name_bn}{' '}
                            <span className="font-normal text-slate-400 font-mono text-[11px]">
                              ({emp.employee_code})
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {emp.department} • {emp.designation}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="font-mono font-semibold text-slate-700 text-[11px] flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{emp.phone}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
              <span>মোট দৃশ্যমান কর্মী: {filteredEmployees.length} জন</span>
              <span>
                নির্বাচিত: <strong className="text-emerald-700">{selectedEmpIds.length} জন</strong>
              </span>
            </div>
          </div>

          {/* Right Column: Template & Message Form (5 cols) */}
          <div className="lg:col-span-5 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>বার্তা টেমপ্লেট ও টেক্সট</span>
              </h3>
              <p className="text-xs text-slate-400">
                টেমপ্লেট নির্বাচন করুন অথবা নিজে বার্তা কাস্টমাইজ করুন
              </p>
            </div>

            {/* Template Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">প্রিমেড টেমপ্লেট:</label>
              <select
                value={selectedTemplateId}
                onChange={(e) => handleTemplateChange(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-hidden focus:border-emerald-500"
              >
                {TEMPLATES.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.title}
                  </option>
                ))}
              </select>
            </div>

            {/* Message Body */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                এসএমএস বার্তা (বাংলা ইউনিকোড):
              </label>
              <textarea
                rows={6}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="আপনার বার্তা লিখুন..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 leading-relaxed focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
              <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                <span>
                  ক্যারেক্টার: {messageText.length} | এসএমএস পার্ট:{' '}
                  {Math.ceil(messageText.length / 70) || 1} টি
                </span>
                <span>স্বয়ংক্রিয় ট্যাগ: {'{নাম}'}, {'{তারিখ}'}</span>
              </div>
            </div>

            {/* Send Summary Box */}
            <div className="p-3 bg-emerald-50/60 border border-emerald-100 rounded-xl text-xs space-y-1 text-slate-700">
              <div className="flex justify-between">
                <span>মোট নির্বাচিত প্রাপক:</span>
                <strong className="font-bold text-slate-900">{selectedEmpIds.length} জন</strong>
              </div>
              <div className="flex justify-between">
                <span>অনুমানিত খরচ (@ ৳ ০.৪০ / এসএমএস):</span>
                <strong className="font-bold text-emerald-800 font-mono">
                  ৳ {(selectedEmpIds.length * 0.4).toFixed(2)}
                </strong>
              </div>
              <div className="flex justify-between">
                <span>কারখানার নাম প্রেরক:</span>
                <span className="font-semibold text-slate-800">টেক্স ওয়্যার অ্যাপারেলস</span>
              </div>
            </div>

            {/* Send Button */}
            <button
              onClick={handleSendBulkSms}
              disabled={sending || selectedEmpIds.length === 0}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 transition-all"
            >
              <Send className="w-4 h-4" />
              <span>
                {sending
                  ? 'এসএমএস পাঠানো হচ্ছে...'
                  : `${selectedEmpIds.length} জন কর্মীকে এসএমএস পাঠান`}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: SMS LOGS */}
      {activeTab === 'logs' && (
        <div id="printable-sms-logs" className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          {/* Print-only Factory Header */}
          <div className="hidden print:block p-4 mb-2 border-b-2 border-emerald-800 text-center">
            <h1 className="text-2xl font-black text-emerald-950">টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p className="text-xs text-slate-600">Texware Apparels • প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর | ফোন: +880 1711-234567</p>
            <div className="inline-block mt-2 px-4 py-1 bg-emerald-800 text-white text-xs font-bold rounded-md">
              শ্রমিক এসএমএস নোটিফিকেশন ডেলিভারি লগ ও অডিট রেজিস্টার
            </div>
            <div className="mt-2 text-xs text-slate-500 font-mono">
              মোট রেকর্ড: {smsLogs.length} টি • প্রিন্ট তারিখ: {new Date().toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>

          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-800">এসএমএস প্রেরণের ইতিহাস ও রিপোর্ট</h3>
              <p className="text-xs text-slate-400">সর্বশেষ প্রেরিত এসএমএস এর স্ট্যাটাস ও ডেলিভারি লগ</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => printElementById('printable-sms-logs', 'এসএমএস_প্রেরণের_রিপোর্ট')}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-200 cursor-pointer flex items-center gap-1.5 transition-colors"
                title="এসএমএস লগ প্রিন্ট করুন"
              >
                <Printer className="w-3.5 h-3.5 text-slate-500" />
                <span>রিপোর্ট প্রিন্ট</span>
              </button>

              {smsLogs.length > 0 && (
                <button
                  onClick={handleClearAllLogs}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 cursor-pointer flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>সকল লগ মুছুন</span>
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                <tr>
                  <th className="py-3 px-4">প্রাপকের নাম ও ফোন</th>
                  <th className="py-3 px-4">বার্তার ধরন</th>
                  <th className="py-3 px-4">বার্তা বিবরণী</th>
                  <th className="py-3 px-4">সময় ও তারিখ</th>
                  <th className="py-3 px-4 text-center">স্ট্যাটাস</th>
                  <th className="py-3 px-4 text-center print:hidden">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {smsLogs.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      কোনো এসএমএস প্রেরণের রেকর্ড নেই
                    </td>
                  </tr>
                ) : (
                  smsLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-800">{log.recipient_name}</div>
                        <div className="font-mono text-slate-500 text-[11px]">{log.recipient_phone}</div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700">
                          {log.template_type}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-slate-600 max-w-xs truncate" title={log.message}>
                        {log.message}
                      </td>

                      <td className="py-3 px-4 text-slate-500 text-[11px]">
                        {new Date(log.sent_at).toLocaleString('bn-BD')}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>সফল</span>
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center print:hidden">
                        <button
                          onClick={() => handleDeleteLog(log.id)}
                          className="p-1 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          title="লগ মুছুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Print-only Signatures */}
          <div className="hidden print:grid grid-cols-3 gap-6 p-6 mt-8 text-center text-xs text-slate-700">
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">সিস্টেম অপারেটর (আইটি)</div>
            </div>
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">অ্যাডমিন অফিসার</div>
            </div>
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">কারখানা প্রধান / জিএম</div>
            </div>
          </div>
        </div>
      )}

      {/* Test SMS Modal */}
      <Modal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
        title="টেস্ট এসএমএস প্রেরণ"
        subtitle="যেকোনো একটি মোবাইল নম্বরে তাৎক্ষণিক টেস্ট এসএমএস পাঠিয়ে যাচাই করুন"
        maxWidth="sm"
      >
        <form onSubmit={handleSendTestSms} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">মোবাইল নম্বর</label>
            <input
              type="text"
              value={testMobile}
              onChange={(e) => setTestMobile(e.target.value)}
              placeholder="017XXXXXXXX"
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-800"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">টেস্ট বার্তা</label>
            <textarea
              rows={3}
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              required
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsTestModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={sending}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs disabled:opacity-50"
            >
              {sending ? 'পাঠানো হচ্ছে...' : 'এসএমএস পাঠান'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
