import React, { useState, useEffect } from 'react';
import {
  User,
  Phone,
  MapPin,
  Calendar,
  Briefcase,
  CreditCard,
  Printer,
  Clock,
  FileCheck,
  Building,
  CheckCircle2,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { Modal } from '../common/Modal';
import { Employee } from '../../types';
import { api } from '../../services/api';
import { printElementById } from '../../utils/printDocument';

interface EmployeeProfileModalProps {
  employeeId: number | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (emp: Employee) => void;
}

export const EmployeeProfileModal: React.FC<EmployeeProfileModalProps> = ({
  employeeId,
  isOpen,
  onClose,
  onEdit,
}) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'attendance' | 'salary' | 'gatepass'>('info');

  useEffect(() => {
    if (isOpen && employeeId) {
      setLoading(true);
      api
        .getEmployeeDetail(employeeId)
        .then((res) => setData(res))
        .catch((err) => console.error(err))
        .finally(() => setLoading(false));
    } else {
      setData(null);
    }
  }, [isOpen, employeeId]);

  if (!isOpen) return null;

  const emp: Employee = data?.employee;
  const attendanceList = data?.attendanceHistory || data?.recentAttendance || [];
  const payrollList = data?.payrollHistory || [];
  const gatePassList = data?.gatePassHistory || data?.gatePasses || [];

  const handlePrint = () => {
    printElementById('printable-worker-profile', `কর্মী_প্রোফাইল_${emp.employee_code}_${emp.full_name}`);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={emp ? `${emp.full_name} (${emp.employee_code})` : 'কর্মী প্রোফাইল'}
      subtitle="শ্রমিকের সম্পূর্ণ তথ্য, অতীত হাজিরা, বেতন ও গেট পাস বিবরণী"
      maxWidth="4xl"
    >
      {loading || !emp ? (
        <div className="py-12 text-center text-xs text-slate-500">
          <div className="w-8 h-8 border-2 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin mx-auto mb-2" />
          কর্মী তথ্য প্রস্তুত হচ্ছে...
        </div>
      ) : (
        <div id="printable-worker-profile" className="space-y-5">
          {/* Print-only Factory Header */}
          <div className="hidden print:block p-4 mb-3 border-b-2 border-emerald-800 text-center">
            <h1 className="text-2xl font-black text-emerald-950">টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p className="text-xs text-slate-600">Texware Apparels • প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর | ফোন: +880 1711-234567</p>
            <div className="inline-block mt-2 px-4 py-1 bg-emerald-800 text-white text-xs font-bold rounded-md">
              কর্মী ব্যক্তিগত ও সার্ভিস রেকর্ড নথিপত্র
            </div>
            <div className="mt-2 text-xs text-slate-500 font-mono">
              কর্মী আইডি: {emp.employee_code} • প্রিন্ট তারিখ: {new Date().toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
          {/* Top Profile Card */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200/80">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-700 text-white flex items-center justify-center font-bold text-xl overflow-hidden shadow-sm shrink-0">
                {emp.photo_url ? (
                  <img src={emp.photo_url} alt={emp.full_name} className="w-full h-full object-cover" />
                ) : (
                  emp.full_name.charAt(0)
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-slate-800">{emp.full_name}</h3>
                  {emp.status === 'active' ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      নিয়মিত কর্মরত (Active)
                    </span>
                  ) : emp.status === 'resigned' ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                      পদত্যাগকৃত (Resigned)
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                      নিষ্ক্রিয় (Inactive)
                    </span>
                  )}
                </div>
                {emp.status === 'resigned' && emp.resignation_date && (
                  <div className="mt-1 p-1.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-[11px] font-medium">
                    পদত্যাগের তারিখ: <span className="font-bold">{emp.resignation_date}</span>
                    {emp.resignation_reason && ` • কারণ: ${emp.resignation_reason}`}
                  </div>
                )}
                <p className="text-xs text-slate-600 mt-0.5">
                  {emp.designation} • {emp.department} বিভাগ
                </p>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  আইডি: {emp.employee_code} | যোগদানের তারিখ: {emp.joining_date}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-stretch sm:self-auto">
              <button
                onClick={handlePrint}
                className="flex-1 sm:flex-none px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Printer className="w-4 h-4 text-slate-500" />
                <span>প্রোফাইল প্রিন্ট</span>
              </button>
              <button
                onClick={() => {
                  onClose();
                  onEdit(emp);
                }}
                className="flex-1 sm:flex-none px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>সম্পাদনা</span>
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex border-b border-slate-200 text-xs font-semibold gap-1">
            <button
              onClick={() => setActiveTab('info')}
              className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
                activeTab === 'info'
                  ? 'border-emerald-600 text-emerald-700 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              ব্যক্তিগত ও চাকরির তথ্য
            </button>
            <button
              onClick={() => setActiveTab('attendance')}
              className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
                activeTab === 'attendance'
                  ? 'border-emerald-600 text-emerald-700 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              হাজিরা রেকর্ড ({attendanceList.length})
            </button>
            <button
              onClick={() => setActiveTab('salary')}
              className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
                activeTab === 'salary'
                  ? 'border-emerald-600 text-emerald-700 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              বেতন ও পেমেন্ট রেকর্ড ({payrollList.length})
            </button>
            <button
              onClick={() => setActiveTab('gatepass')}
              className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
                activeTab === 'gatepass'
                  ? 'border-emerald-600 text-emerald-700 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              গেট পাস ইতিহাস ({gatePassList.length})
            </button>
          </div>

          {/* Tab 1: Personal & Employment Info */}
          {activeTab === 'info' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-100 space-y-2.5">
                <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[11px] text-emerald-800">
                  ব্যক্তিগত ও যোগাযোগ তথ্য
                </h4>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">অভিভাবকের নাম:</span>
                  <span className="col-span-2 font-medium text-slate-700">{emp.guardian_name || 'দেওয়া হয়নি'}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">মোবাইল নম্বর:</span>
                  <span className="col-span-2 font-mono font-medium text-slate-800">{emp.mobile}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">জাতীয় পরিচয়পত্র:</span>
                  <span className="col-span-2 font-mono text-slate-700">{emp.nid || 'দেওয়া হয়নি'}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">লিঙ্গ ও জন্মতারিখ:</span>
                  <span className="col-span-2 text-slate-700">{emp.gender} • {emp.dob || '—'}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">জরুরি যোগাযোগ:</span>
                  <span className="col-span-2 text-rose-600 font-medium">{emp.emergency_contact || '—'}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">বর্তমান ঠিকানা:</span>
                  <span className="col-span-2 text-slate-700">{emp.address || '—'}</span>
                </div>
              </div>

              <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-100 space-y-2.5">
                <h4 className="font-bold text-slate-800 uppercase tracking-wide text-[11px] text-emerald-800">
                  কারখানা বেতন ও চাকরি শর্তাবলী
                </h4>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">চাকরির ধরন:</span>
                  <span className="col-span-2 font-medium capitalize text-slate-700">{emp.employee_type}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">বেতন পদ্ধতি:</span>
                  <span className="col-span-2 font-medium capitalize text-slate-700">{emp.salary_type}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">মূল মাসিক বেতন:</span>
                  <span className="col-span-2 text-base font-bold text-emerald-700">৳{emp.basic_salary.toLocaleString('bn-BD')}</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">প্রতি ঘণ্টা ওভারটাইম:</span>
                  <span className="col-span-2 font-medium text-slate-800">৳{emp.overtime_rate}/ঘণ্টা</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <span className="text-slate-400">যোগদান কাল:</span>
                  <span className="col-span-2 text-slate-700">{emp.joining_date}</span>
                </div>
                {emp.notes && (
                  <div className="pt-2 border-t border-slate-200">
                    <span className="text-slate-400 block mb-0.5">মন্তব্য / নোট:</span>
                    <p className="text-slate-600 italic">{emp.notes}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Tab 2: Attendance History */}
          {activeTab === 'attendance' && (
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-600 font-semibold">
                  <tr>
                    <th className="p-3">তারিখ</th>
                    <th className="p-3">স্ট্যাটাস</th>
                    <th className="p-3">প্রবেশ সময়</th>
                    <th className="p-3">প্রস্থান সময়</th>
                    <th className="p-3 text-right">ওভারটাইম</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {attendanceList.length > 0 ? (
                    attendanceList.map((att: any) => (
                      <tr key={att.id} className="hover:bg-slate-50">
                        <td className="p-3 font-medium text-slate-800">{att.date}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              att.status === 'present'
                                ? 'bg-emerald-100 text-emerald-800'
                                : att.status === 'absent'
                                ? 'bg-rose-100 text-rose-800'
                                : att.status === 'leave'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {att.status === 'present'
                              ? 'উপস্থিত'
                              : att.status === 'absent'
                              ? 'অনুপস্থিত'
                              : att.status === 'leave'
                              ? 'ছুটি'
                              : 'দেরি (Late)'}
                          </span>
                        </td>
                        <td className="p-3 text-slate-500 font-mono">{att.in_time || '—'}</td>
                        <td className="p-3 text-slate-500 font-mono">{att.out_time || '—'}</td>
                        <td className="p-3 text-right font-bold text-slate-700">
                          {att.ot_hours ? `${att.ot_hours} ঘণ্টা` : '—'}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400">
                        কোনো সাম্প্রতিক হাজিরা পাওয়া যায়নি
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* Tab 3: Salary History */}
          {activeTab === 'salary' && (
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-600 font-semibold">
                  <tr>
                    <th className="p-3">মাস/বছর</th>
                    <th className="p-3">হাজিরা/ছুটি</th>
                    <th className="p-3">মূল বেতন</th>
                    <th className="p-3">ওভারটাইম</th>
                    <th className="p-3">মোট প্রদেয়</th>
                    <th className="p-3">পরিশোধিত</th>
                    <th className="p-3 text-right">স্ট্যাটাস</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {data?.payrollHistory && data.payrollHistory.length > 0 ? (
                    data.payrollHistory.map((pay: any) => (
                      <tr key={pay.id} className="hover:bg-slate-50">
                        <td className="p-3 font-bold text-slate-800">{pay.month_year}</td>
                        <td className="p-3 text-slate-600">
                          উপস্থিত: {pay.present_days} দিন | ছুটি: {pay.leave_days} দিন
                        </td>
                        <td className="p-3 text-slate-700 font-mono">৳{pay.basic_salary?.toLocaleString('bn-BD')}</td>
                        <td className="p-3 text-slate-700 font-mono">৳{pay.ot_amount?.toLocaleString('bn-BD')} ({pay.ot_hours}h)</td>
                        <td className="p-3 font-bold text-slate-900 font-mono">৳{pay.net_payable?.toLocaleString('bn-BD')}</td>
                        <td className="p-3 font-bold text-emerald-600 font-mono">৳{pay.paid_amount?.toLocaleString('bn-BD')}</td>
                        <td className="p-3 text-right">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              pay.payment_status === 'paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : pay.payment_status === 'partial'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {pay.payment_status === 'paid' ? 'পরিশোধিত' : pay.payment_status === 'partial' ? 'আংশিক' : 'বকেয়া'}
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-slate-400">
                        কোনো বেতন বিবরণী পাওয়া যায়নি
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* Tab 4: Gate Pass History */}
          {activeTab === 'gatepass' && (
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-600 font-semibold">
                  <tr>
                    <th className="p-3">পাস নম্বর</th>
                    <th className="p-3">তারিখ</th>
                    <th className="p-3">প্রস্থান সময়</th>
                    <th className="p-3">ফেরার সময়</th>
                    <th className="p-3">কারণ</th>
                    <th className="p-3 text-right">অবস্থা</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {gatePassList.length > 0 ? (
                    gatePassList.map((gp: any) => (
                      <tr key={gp.id} className="hover:bg-slate-50">
                        <td className="p-3 font-mono font-bold text-slate-800">{gp.pass_no}</td>
                        <td className="p-3 text-slate-600">{gp.date}</td>
                        <td className="p-3 text-slate-600 font-mono">{gp.out_time}</td>
                        <td className="p-3 text-slate-600 font-mono">{gp.actual_return_time || gp.expected_return_time || '—'}</td>
                        <td className="p-3 text-slate-600">{gp.reason}</td>
                        <td className="p-3 text-right font-medium">
                          <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-50 text-emerald-700">
                            {gp.status === 'returned' ? 'ফিরেছেন' : 'অনুমোদিত'}
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400">
                        কোনো গেট পাস এন্ট্রি নেই
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* Print-only Signatures */}
          <div className="hidden print:grid grid-cols-3 gap-6 pt-10 text-center text-xs text-slate-700">
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">শ্রমিক / কর্মচারীর স্বাক্ষর</div>
            </div>
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">এইচআর অ্যাডমিন স্বাক্ষর</div>
            </div>
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">কারখানা ব্যবস্থাপক অনুমোদন</div>
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
};
