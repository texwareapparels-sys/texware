import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Plus,
  Filter,
  Eye,
  Edit2,
  Phone,
  Briefcase,
  Building,
  CheckCircle2,
  XCircle,
  MoreVertical,
  Printer,
  Download,
  ShieldAlert,
  Trash2,
  Banknote,
  Clock,
  AlertTriangle,
  UserX
} from 'lucide-react';
import { Employee } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { EmployeeProfileModal } from './EmployeeProfileModal';
import { printElementById } from '../../utils/printDocument';

interface EmployeesViewProps {
  initialOpenAdd?: boolean;
}

const DEPARTMENTS = [
  'সব বিভাগ',
  'কাটিং (Cutting)',
  'সুইং (Sewing)',
  'ফিনিশিং (Finishing)',
  'কোয়ালিটি কন্ট্রোল (QC)',
  'আয়রনিং (Ironing)',
  'প্যাকেজিং (Packaging)',
  'অ্যাডমিন ও একাউন্টস',
  'রক্ষণাবেক্ষণ (Maintenance)',
];

export const EmployeesView: React.FC<EmployeesViewProps> = ({ initialOpenAdd = false }) => {
  const { showToast } = useToast();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('সব বিভাগ');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'resigned' | 'inactive'>('all');

  // Modals state
  const [profileEmployeeId, setProfileEmployeeId] = useState<number | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(initialOpenAdd);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [deletingEmployee, setDeletingEmployee] = useState<Employee | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Quick Resignation Modal state
  const [resigningEmployee, setResigningEmployee] = useState<Employee | null>(null);
  const [resignationDate, setResignationDate] = useState(new Date().toISOString().split('T')[0]);
  const [resignationReason, setResignationReason] = useState('');
  const [isSubmittingResignation, setIsSubmittingResignation] = useState(false);

  // Form inputs
  const [formData, setFormData] = useState({
    employee_code: '',
    full_name: '',
    guardian_name: '',
    dob: '',
    gender: 'Male',
    mobile: '',
    address: '',
    nid: '',
    joining_date: new Date().toISOString().split('T')[0],
    department: 'সুইং (Sewing)',
    designation: 'সিনিয়র সুইং অপারেটর',
    employee_type: 'worker',
    salary_type: 'monthly',
    basic_salary: 12500,
    overtime_rate: 120,
    status: 'active',
    resignation_date: '',
    resignation_reason: '',
    emergency_contact: '',
    notes: '',
  });

  const fetchEmployees = async () => {
    setLoading(true);
    try {
      const data = await api.getEmployees({
        department: selectedDept !== 'সব বিভাগ' ? selectedDept : undefined,
        status: statusFilter !== 'all' ? statusFilter : undefined,
        search: searchTerm || undefined,
      });
      setEmployees(data);
    } catch (err: any) {
      showToast(err.message || 'কর্মীদের তথ্য লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, [selectedDept, statusFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchEmployees();
  };

  const handleOpenAdd = () => {
    const nextCode = `EMP-${String(employees.length + 101).padStart(3, '0')}`;
    setEditingEmployee(null);
    setFormData({
      employee_code: nextCode,
      full_name: '',
      guardian_name: '',
      dob: '',
      gender: 'Male',
      mobile: '01',
      address: '',
      nid: '',
      joining_date: new Date().toISOString().split('T')[0],
      department: 'সুইং (Sewing)',
      designation: 'সুইং অপারেটর',
      employee_type: 'worker',
      salary_type: 'monthly',
      basic_salary: 12500,
      overtime_rate: 120,
      status: 'active',
      resignation_date: '',
      resignation_reason: '',
      emergency_contact: '',
      notes: '',
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    setEditingEmployee(emp);
    setFormData({
      employee_code: emp.employee_code,
      full_name: emp.full_name,
      guardian_name: emp.guardian_name || '',
      dob: emp.dob || '',
      gender: emp.gender || 'Male',
      mobile: emp.mobile,
      address: emp.address || '',
      nid: emp.nid || '',
      joining_date: emp.joining_date,
      department: emp.department,
      designation: emp.designation,
      employee_type: emp.employee_type,
      salary_type: emp.salary_type,
      basic_salary: emp.basic_salary,
      overtime_rate: emp.overtime_rate,
      status: emp.status,
      resignation_date: emp.resignation_date || '',
      resignation_reason: emp.resignation_reason || '',
      emergency_contact: emp.emergency_contact || '',
      notes: emp.notes || '',
    });
    setIsFormOpen(true);
  };

  // Manual OT rate: does not overwrite user's manual overtime rate when basic salary changes
  const handleSalaryChange = (val: number) => {
    setFormData((prev) => ({
      ...prev,
      basic_salary: val,
    }));
  };

  const handleConfirmResignation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resigningEmployee) return;
    setIsSubmittingResignation(true);
    try {
      await api.updateEmployee(resigningEmployee.id, {
        status: 'resigned',
        resignation_date: resignationDate,
        resignation_reason: resignationReason,
      });
      showToast(`${resigningEmployee.full_name} কে সফলভাবে পদত্যাগকৃত হিসেবে আপডেট করা হয়েছে। হাজিরা ও সেলারি শিট থেকে স্বয়ংক্রিয়ভাবে বাদ রাখা হবে।`, 'success');
      setResigningEmployee(null);
      fetchEmployees();
    } catch (err: any) {
      showToast(err.message || 'পদত্যাগ আপডেট করা যায়নি', 'error');
    } finally {
      setIsSubmittingResignation(false);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingEmployee) {
        await api.updateEmployee(editingEmployee.id, formData);
        showToast('কর্মীর তথ্য সফলভাবে হালনাগাদ করা হয়েছে', 'success');
      } else {
        await api.createEmployee(formData);
        showToast('নতুন কর্মী সফলভাবে যুক্ত করা হয়েছে', 'success');
        setSelectedDept('সব বিভাগ');
        setStatusFilter('all');
        setSearchTerm('');
      }
      setIsFormOpen(false);
      fetchEmployees();
    } catch (err: any) {
      showToast(err.message || 'কর্মীর তথ্য সংরক্ষণ করা যায়নি', 'error');
    }
  };

  const handleDeleteEmployee = async () => {
    if (!deletingEmployee) return;
    setIsDeleting(true);
    try {
      await api.deleteEmployee(deletingEmployee.id);
      showToast(`কর্মী ${deletingEmployee.full_name} (${deletingEmployee.employee_code}) সফলভাবে মুছে ফেলা হয়েছে`, 'success');
      setDeletingEmployee(null);
      fetchEmployees();
    } catch (err: any) {
      showToast(err.message || 'কর্মী মুছে ফেলা সম্ভব হয়নি', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleExportCsv = () => {
    const headers = ['আইডি', 'নাম', 'মোবাইল', 'বিভাগ', 'পদবী', 'মূল বেতন', 'ওভারটাইম রেট', 'স্ট্যাটাস'];
    const rows = employees.map((e) => [
      e.employee_code,
      e.full_name,
      e.mobile,
      e.department,
      e.designation,
      e.basic_salary,
      e.overtime_rate,
      e.status === 'active' ? 'Active' : 'Inactive',
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers, ...rows].map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `employees_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const activeCount = employees.filter((e) => e.status === 'active').length;
  const resignedCount = employees.filter((e) => e.status === 'resigned').length;
  const totalSalary = employees.filter((e) => e.status === 'active').reduce((acc, e) => acc + (Number(e.basic_salary) || 0), 0);
  const avgOt = employees.length > 0 ? Math.round(employees.reduce((acc, e) => acc + (Number(e.overtime_rate) || 0), 0) / employees.length) : 0;

  return (
    <div className="space-y-5 pb-12">
      {/* Top Header & Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <Users className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              শ্রমিক ও কর্মচারী ব্যবস্থাপনা
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            কারখানার সকল কর্মী, পদবী, মোবাইল নম্বর ও বেসিক বেতনের তালিকা এবং সম্পূর্ণ প্রোফাইল নিয়ন্ত্রণ
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => printElementById('printable-worker-register', 'শ্রমিক ও কর্মচারী মাস্টার তালিকা')}
            className="px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            title="কর্মী তালিকা প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span className="hidden sm:inline">রেজিস্টার প্রিন্ট</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>এক্সেল CSV</span>
          </button>

          <button
            id="add-employee-btn"
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs shadow-emerald-600/20 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন কর্মী যুক্ত করুন</span>
          </button>
        </div>
      </div>

      {/* Quick Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-slate-500 font-medium">মোট কর্মী</div>
            <div className="text-base sm:text-lg font-bold text-slate-800 font-mono">{employees.length} জন</div>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-slate-500 font-medium">সক্রিয় কর্মী</div>
            <div className="text-base sm:text-lg font-bold text-emerald-700 font-mono">{activeCount} জন</div>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
            <Banknote className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-slate-500 font-medium">মাসিক মূল বেতন</div>
            <div className="text-base sm:text-lg font-bold text-slate-800 font-mono truncate">৳{totalSalary.toLocaleString('bn-BD')}</div>
          </div>
        </div>

        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
            <UserX className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-slate-500 font-medium">পদত্যাগকৃত (Resigned)</div>
            <div className="text-base sm:text-lg font-bold text-rose-700 font-mono">{resignedCount} জন</div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search */}
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            id="employee-search-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="নাম, আইডি (EMP-101) বা ফোন খুঁজুন..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
          />
        </form>

        {/* Department Filter */}
        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
          >
            {DEPARTMENTS.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <div className="inline-flex bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600 shrink-0">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                statusFilter === 'all' ? 'bg-white text-slate-800 shadow-xs' : 'hover:text-slate-800'
              }`}
            >
              সকল
            </button>
            <button
              onClick={() => setStatusFilter('active')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                statusFilter === 'active' ? 'bg-white text-emerald-800 shadow-xs' : 'hover:text-slate-800'
              }`}
            >
              সক্রিয় ({activeCount})
            </button>
            <button
              onClick={() => setStatusFilter('resigned')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                statusFilter === 'resigned' ? 'bg-white text-rose-800 shadow-xs' : 'hover:text-slate-800'
              }`}
            >
              পদত্যাগকৃত ({resignedCount})
            </button>
            <button
              onClick={() => setStatusFilter('inactive')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                statusFilter === 'inactive' ? 'bg-white text-slate-800 shadow-xs' : 'hover:text-slate-800'
              }`}
            >
              নিষ্ক্রিয়
            </button>
          </div>
        </div>
      </div>

      {/* Employees Table */}
      <div id="printable-worker-register" className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {/* Print-only Factory Header */}
        <div className="hidden print:block p-4 mb-2 border-b-2 border-emerald-800 text-center">
          <h1 className="text-2xl font-black text-emerald-950">টেক্স ওয়্যার অ্যাপারেলস</h1>
          <p className="text-xs text-slate-600">Texware Apparels • প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর | ফোন: +880 1711-234567</p>
          <div className="inline-block mt-2 px-4 py-1 bg-emerald-800 text-white text-xs font-bold rounded-md">
            কারখানা শ্রমিক ও কর্মচারী মাস্টার রেজিস্টার
          </div>
          <div className="mt-2 text-xs text-slate-500 font-mono">
            মোট সক্রিয় কর্মী: {employees.length} জন • প্রিন্ট তারিখ: {new Date().toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3.5 px-4">আইডি ও কর্মী নাম</th>
                <th className="py-3.5 px-4">বিভাগ ও পদবী</th>
                <th className="py-3.5 px-4">মোবাইল নম্বর</th>
                <th className="py-3.5 px-4">বেতন পদ্ধতি</th>
                <th className="py-3.5 px-4 text-right">মূল বেতন</th>
                <th className="py-3.5 px-4 text-center">স্ট্যাটাস</th>
                <th className="py-3.5 px-4 text-right print:hidden">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <div className="w-8 h-8 border-2 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto mb-2" />
                    তথ্য লোড হচ্ছে...
                  </td>
                </tr>
              ) : employees.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    কোনো কর্মী খুঁজে পাওয়া যায়নি
                  </td>
                </tr>
              ) : (
                employees.map((emp) => (
                  <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Employee Info */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs shrink-0 border border-slate-200/60 overflow-hidden">
                          {emp.photo_url ? (
                            <img src={emp.photo_url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            emp.full_name.charAt(0)
                          )}
                        </div>
                        <div>
                          <div
                            className="font-bold text-slate-800 hover:text-emerald-700 cursor-pointer"
                            onClick={() => {
                              setProfileEmployeeId(emp.id);
                              setIsProfileOpen(true);
                            }}
                          >
                            {emp.full_name}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            {emp.employee_code}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Department & Designation */}
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-700">{emp.designation}</div>
                      <div className="text-[11px] text-slate-400">{emp.department}</div>
                    </td>

                    {/* Phone */}
                    <td className="py-3 px-4 font-mono text-slate-600">
                      <a
                        href={`tel:${emp.mobile}`}
                        className="flex items-center gap-1.5 hover:text-emerald-700 transition-colors"
                        title="কল করুন"
                      >
                        <Phone className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{emp.mobile}</span>
                      </a>
                    </td>

                    {/* Salary Type */}
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-semibold capitalize">
                        {emp.salary_type === 'monthly' ? 'মাসিক' : emp.salary_type === 'daily' ? 'দৈনিক' : 'পিস-রেট'}
                      </span>
                    </td>

                    {/* Salary & OT */}
                    <td className="py-3 px-4 text-right">
                      <div className="font-bold text-slate-800 font-mono">
                        ৳{emp.basic_salary.toLocaleString('bn-BD')}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        ওটি: ৳{emp.overtime_rate}/ঘণ্টা
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4 text-center">
                      {emp.status === 'active' ? (
                        <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                          সক্রিয়
                        </span>
                      ) : emp.status === 'resigned' ? (
                        <div className="inline-flex flex-col items-center">
                          <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                            পদত্যাগকৃত
                          </span>
                          {emp.resignation_date && (
                            <span className="text-[9px] text-rose-600 font-mono font-bold mt-0.5">
                              {emp.resignation_date}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                          নিষ্ক্রিয়
                        </span>
                      )}
                    </td>

                    {/* Action buttons */}
                    <td className="py-3 px-4 text-right print:hidden">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setProfileEmployeeId(emp.id);
                            setIsProfileOpen(true);
                          }}
                          className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          title="সম্পূর্ণ প্রোফাইল দেখুন"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(emp)}
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                          title="তথ্য সম্পাদনা করুন"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {emp.status !== 'resigned' && (
                          <button
                            onClick={() => {
                              setResigningEmployee(emp);
                              setResignationDate(emp.resignation_date || new Date().toISOString().split('T')[0]);
                              setResignationReason(emp.resignation_reason || '');
                            }}
                            className="p-1.5 text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                            title="কর্মীর পদত্যাগ (Resignation) আপডেট করুন"
                          >
                            <UserX className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => setDeletingEmployee(emp)}
                          className="p-1.5 text-slate-400 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          title="কর্মী মুছে ফেলুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Print-only Signatures */}
        <div className="hidden print:grid grid-cols-4 gap-6 p-6 mt-8 text-center text-xs text-slate-700">
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">প্রস্তুতকারক (অ্যাডমিন)</div>
          </div>
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">এইচআর এক্সিকিউটিভ</div>
          </div>
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">হিসাব কর্মকর্তা</div>
          </div>
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1 font-semibold">ব্যবস্থাপনা পরিচালক / জিএম</div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={Boolean(deletingEmployee)}
        onClose={() => setDeletingEmployee(null)}
        title="কর্মী মুছে ফেলার নিশ্চিতকরণ"
        subtitle="সতর্কতা: এই পদক্ষেপটি প্রত্যাহার করা যাবে না"
        maxWidth="md"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="text-rose-900 leading-relaxed">
              আপনি কি নিশ্চিতভাবে কর্মী{' '}
              <strong className="font-bold text-slate-900">
                {deletingEmployee?.full_name} ({deletingEmployee?.employee_code})
              </strong>{' '}
              কে সিস্টেম থেকে সম্পূর্ণ মুছে ফেলতে চান? এর সাথে সংশ্লিষ্ট হাজিরা, বেতন ও গেট পাস রেকর্ডও মুছে যাবে।
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setDeletingEmployee(null)}
              disabled={isDeleting}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="button"
              onClick={handleDeleteEmployee}
              disabled={isDeleting}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              {isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, নিশ্চিত মুছে ফেলুন'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Quick Resignation Modal */}
      <Modal
        isOpen={Boolean(resigningEmployee)}
        onClose={() => setResigningEmployee(null)}
        title="কর্মীর পদত্যাগ (Resignation) আপডেট"
        subtitle={`${resigningEmployee?.full_name} (${resigningEmployee?.employee_code})`}
        maxWidth="md"
      >
        <form onSubmit={handleConfirmResignation} className="space-y-4 text-xs">
          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 leading-relaxed">
            <span className="font-bold">সতর্কতা:</span> কোন শ্রমিক পদত্যাগ (Resigned) করলে, তার তথ্য পরবর্তী কোনো হাজিরা, ওভারটাইম বা বেতন শিটে আর শো করবে না।
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              পদত্যাগের তারিখ (Resignation Date) <span className="text-rose-500">*</span>
            </label>
            <input
              type="date"
              value={resignationDate}
              onChange={(e) => setResignationDate(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">পদত্যাগের কারণ (Resignation Reason)</label>
            <textarea
              rows={3}
              value={resignationReason}
              onChange={(e) => setResignationReason(e.target.value)}
              placeholder="যেমন: ব্যক্তিগত কারণ, শারীরিক অসুস্থতা, নিজ জেলায় স্থানান্তর ইত্যাদি..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/30"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setResigningEmployee(null)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={isSubmittingResignation}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
            >
              <UserX className="w-4 h-4" />
              <span>{isSubmittingResignation ? 'সংরক্ষণ হচ্ছে...' : 'পদত্যাগ নিশ্চিত করুন'}</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* Profile Modal */}
      <EmployeeProfileModal
        employeeId={profileEmployeeId}
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onEdit={(emp) => handleOpenEdit(emp)}
      />

      {/* Add / Edit Employee Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        title={editingEmployee ? 'কর্মী তথ্য সম্পাদনা' : 'নতুন কর্মী এন্ট্রি ফরম'}
        subtitle="শ্রমিক বা কর্মচারীর ব্যক্তিগত, চাকরি ও বেতনের সম্পূর্ণ তথ্য প্রদান করুন"
        maxWidth="2xl"
      >
        <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">কর্মী আইডি কোড (EMP Code)</label>
              <input
                type="text"
                value={formData.employee_code}
                onChange={(e) => setFormData({ ...formData, employee_code: e.target.value })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">পূর্ণ নাম (বাংলায় বা ইংরেজিতে)</label>
              <input
                type="text"
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                required
                placeholder="যেমন: রফিকুল ইসলাম"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">পিতা / স্বামীর নাম</label>
              <input
                type="text"
                value={formData.guardian_name}
                onChange={(e) => setFormData({ ...formData, guardian_name: e.target.value })}
                placeholder="যেমন: মোঃ জহিরুল ইসলাম"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">মোবাইল নম্বর</label>
              <input
                type="text"
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                required
                placeholder="01XXXXXXXXX"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">জাতীয় পরিচয়পত্র (NID) নম্বর</label>
              <input
                type="text"
                value={formData.nid}
                onChange={(e) => setFormData({ ...formData, nid: e.target.value })}
                placeholder="যেমন: 19922695501001"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">যোগদানের তারিখ</label>
              <input
                type="date"
                value={formData.joining_date}
                onChange={(e) => setFormData({ ...formData, joining_date: e.target.value })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">কারখানা বিভাগ</label>
              <select
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              >
                {DEPARTMENTS.filter((d) => d !== 'সব বিভাগ').map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">পদবী (Designation)</label>
              <input
                type="text"
                value={formData.designation}
                onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                required
                placeholder="যেমন: সিনিয়র সুইং অপারেটর"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">মূল মাসিক বেতন (Basic Salary)</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  ৳
                </span>
                <input
                  type="number"
                  value={formData.basic_salary}
                  onChange={(e) => handleSalaryChange(Number(e.target.value))}
                  required
                  min={0}
                  className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">প্রতি ঘণ্টা ওভারটাইম রেট (ম্যানুয়ালি রেট লিখুন)</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  ৳
                </span>
                <input
                  type="number"
                  value={formData.overtime_rate}
                  onChange={(e) => setFormData({ ...formData, overtime_rate: Number(e.target.value) })}
                  required
                  min={0}
                  className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-bold"
                />
              </div>
              <span className="text-[10px] text-slate-500 font-medium">ম্যানুয়াল এন্ট্রি (৳ / ঘণ্টা)</span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">কর্মীর অবস্থা (Status)</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-semibold"
              >
                <option value="active">সক্রিয় (Active)</option>
                <option value="inactive">নিষ্ক্রিয় (Inactive)</option>
                <option value="resigned">চাকরি ছেড়েছেন (Resigned)</option>
              </select>
            </div>

            {formData.status === 'resigned' && (
              <>
                <div>
                  <label className="block font-semibold text-rose-700 mb-1">
                    পদত্যাগের তারিখ (Resignation Date) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={formData.resignation_date}
                    onChange={(e) => setFormData({ ...formData, resignation_date: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-rose-50/70 border border-rose-200 rounded-xl font-bold text-rose-900 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-rose-700 mb-1">পদত্যাগের কারণ (Reason)</label>
                  <input
                    type="text"
                    value={formData.resignation_reason}
                    onChange={(e) => setFormData({ ...formData, resignation_reason: e.target.value })}
                    placeholder="যেমন: অন্য চাকরিতে যোগদান / ব্যক্তিগত কারণ"
                    className="w-full px-3 py-2 bg-rose-50/70 border border-rose-200 rounded-xl text-rose-900 focus:outline-none focus:ring-2 focus:ring-rose-500/30"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block font-semibold text-slate-700 mb-1">জরুরি যোগাযোগ (নাম ও ফোন)</label>
              <input
                type="text"
                value={formData.emergency_contact}
                onChange={(e) => setFormData({ ...formData, emergency_contact: e.target.value })}
                placeholder="যেমন: ভাই - 01700000000"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">বর্তমান ঠিকানা</label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              placeholder="গ্রাম/রোড, পোস্ট, থানা, জেলা"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">অতিরিক্ত নোট বা মন্তব্য</label>
            <textarea
              rows={2}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="দক্ষতা, মেশিনের অভিজ্ঞতা, ইত্যাদি"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl shadow-xs shadow-emerald-600/20 cursor-pointer"
            >
              {editingEmployee ? 'হালনাগাদ সংরক্ষণ করুন' : 'কর্মী সংরক্ষণ করুন'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      {deletingEmployee && (
        <Modal
          isOpen={Boolean(deletingEmployee)}
          onClose={() => setDeletingEmployee(null)}
          title="কর্মী মুছে ফেলার নিশ্চিতকরণ"
          maxWidth="md"
        >
          <div className="space-y-4 text-slate-700">
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-800">
              <AlertTriangle className="w-5 h-5 shrink-0 text-rose-600 mt-0.5" />
              <div className="text-xs space-y-1">
                <p className="font-bold text-sm text-rose-900">
                  আপনি কি নিশ্চিতভাবে এই কর্মীকে মুছে ফেলতে চান?
                </p>
                <p>
                  কর্মী মুছে ফেললে তার সাথে সম্পর্কিত অতীত হাজিরা, বেতন ও গেট পাস রেকর্ডসমূহ ডাটাবেজ থেকে স্থায়ীভাবে মুছে যাবে। এই কাজটি আর পূর্বাবস্থায় ফেরানো যাবে না।
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">কর্মী কোড:</span>
                <span className="font-mono font-bold text-slate-800">{deletingEmployee.employee_code}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">পূর্ণ নাম:</span>
                <span className="font-bold text-slate-800">{deletingEmployee.full_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">বিভাগ ও পদবী:</span>
                <span className="text-slate-800">{deletingEmployee.department} — {deletingEmployee.designation}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">মোবাইল:</span>
                <span className="font-mono text-slate-800">{deletingEmployee.mobile}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeletingEmployee(null)}
                disabled={isDeleting}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                বাতিল করুন
              </button>
              <button
                type="button"
                onClick={handleDeleteEmployee}
                disabled={isDeleting}
                className="px-4 py-2 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs shadow-rose-600/30 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, স্থায়ীভাবে মুছে ফেলুন'}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

