import React, { useState, useEffect } from 'react';
import {
  ShoppingCart,
  Plus,
  Search,
  Printer,
  Eye,
  Store,
  CreditCard,
  Building,
  CheckCircle2,
  Trash2,
  Edit2,
  AlertCircle,
  FileText,
  UserPlus,
  RefreshCw,
  Phone,
  MapPin,
  Calendar,
  HandCoins,
  PackageCheck
} from 'lucide-react';
import { Sale, Shop, Product, ProductVariant } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { InvoicePrintModal, generateInvoiceHtml } from './InvoicePrintModal';
import { printHtml } from '../../utils/printDocument';

interface SalesViewProps {
  initialOpenAdd?: boolean;
}

export const SalesView: React.FC<SalesViewProps> = ({ initialOpenAdd = false }) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'sales' | 'shops'>('sales');
  const [sales, setSales] = useState<Sale[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'due' | 'cash' | 'given' | 'taken'>('all');
  const [collectDueSale, setCollectDueSale] = useState<Sale | null>(null);
  const [collectAmount, setCollectAmount] = useState<number>(0);

  // Modals
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(initialOpenAdd);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isShopModalOpen, setIsShopModalOpen] = useState(false);
  const [editingShop, setEditingShop] = useState<Shop | null>(null);
  const [editingSale, setEditingSale] = useState<any | null>(null);
  const [selectedSaleDetail, setSelectedSaleDetail] = useState<any | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [deletingSale, setDeletingSale] = useState<Sale | null>(null);
  const [deletingShop, setDeletingShop] = useState<Shop | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Available variant flat list for quick selection
  const availableVariants = React.useMemo(() => {
    const list: Array<{
      product_id: number;
      variant_id: number;
      product_name: string;
      category: string;
      color: string;
      size: string;
      sku: string;
      stock: number;
      unit_price: number;
    }> = [];

    products.forEach((p) => {
      (p.variants || []).forEach((v) => {
        list.push({
          product_id: p.id,
          variant_id: v.id,
          product_name: p.name_bn || p.name_en || 'গেঞ্জি',
          category: p.category || 'গেঞ্জি',
          color: v.color || 'সাধারণ',
          size: v.size || 'M',
          sku: v.sku || '',
          stock: v.stock_quantity || 0,
          unit_price: p.selling_price || 280,
        });
      });
    });

    return list;
  }, [products]);

  // New Invoice Form State
  const [invoiceForm, setInvoiceForm] = useState({
    shop_id: '',
    customer_name: '',
    customer_phone: '',
    sale_date: new Date().toISOString().split('T')[0],
    payment_method: 'নগদ ক্যাশ (Cash)',
    discount_amount: 0,
    paid_amount: 0,
    notes: '',
    items: [
      {
        variant_id: 0,
        product_id: 0,
        product_name: '',
        color: '',
        size: '',
        quantity: 20,
        unit_price: 280,
      },
    ],
  });

  // Shop Form State (Add / Edit)
  const [shopForm, setShopForm] = useState({
    name: '',
    owner_name: '',
    phone: '',
    address: '',
    credit_limit: 100000,
    opening_due: 0,
    notes: '',
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [salesData, shopsData, prodData] = await Promise.all([
        api.getSales(),
        api.getShops(),
        api.getProducts(),
      ]);
      setSales(salesData || []);
      setShops(shopsData || []);
      setProducts(prodData || []);
    } catch (err: any) {
      showToast(err.message || 'বিক্রয় তথ্য লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAddInvoice = () => {
    const firstShop = shops[0];
    const firstVar = availableVariants[0];

    setInvoiceForm({
      shop_id: firstShop ? String(firstShop.id) : '',
      customer_name: firstShop?.owner_name || '',
      customer_phone: firstShop?.phone || '',
      sale_date: new Date().toISOString().split('T')[0],
      payment_method: 'নগদ ক্যাশ (Cash)',
      discount_amount: 0,
      paid_amount: 0,
      notes: '',
      items: [
        {
          variant_id: firstVar?.variant_id || 0,
          product_id: firstVar?.product_id || 0,
          product_name: firstVar?.product_name || 'গেঞ্জি',
          color: firstVar?.color || 'কালো',
          size: firstVar?.size || 'L',
          quantity: 20,
          unit_price: firstVar?.unit_price || 280,
        },
      ],
    });
    setIsInvoiceModalOpen(true);
  };

  const handleOpenAddShop = () => {
    setEditingShop(null);
    setShopForm({
      name: '',
      owner_name: '',
      phone: '01',
      address: '',
      credit_limit: 100000,
      opening_due: 0,
      notes: '',
    });
    setIsShopModalOpen(true);
  };

  const handleOpenEditShop = (shop: Shop) => {
    setEditingShop(shop);
    setShopForm({
      name: shop.name,
      owner_name: shop.owner_name || '',
      phone: shop.phone || '',
      address: shop.address || '',
      credit_limit: shop.credit_limit || 100000,
      opening_due: shop.opening_due || 0,
      notes: shop.notes || '',
    });
    setIsShopModalOpen(true);
  };

  const handleSaveShop = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shopForm.name.trim() || !shopForm.phone.trim()) {
      showToast('দোকানের নাম ও ফোন নম্বর দিন', 'error');
      return;
    }

    try {
      if (editingShop) {
        await api.updateShop(editingShop.id, shopForm);
        showToast('দোকানের তথ্য সফলভাবে আপডেট করা হয়েছে', 'success');
      } else {
        const res = await api.createShop(shopForm);
        showToast('নতুন পাইকারি দোকান/ক্রেতা সফলভাবে নিবন্ধিত হয়েছে', 'success');
        // If creating during invoice entry, select this shop immediately
        if (isInvoiceModalOpen && res.id) {
          setInvoiceForm((prev) => ({
            ...prev,
            shop_id: String(res.id),
            customer_name: shopForm.owner_name,
            customer_phone: shopForm.phone,
          }));
        }
      }
      setIsShopModalOpen(false);
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'দোকান সংরক্ষণ ব্যর্থ হয়েছে', 'error');
    }
  };

  const handleDeleteShop = (shop: Shop) => {
    setDeletingShop(shop);
  };

  const handleConfirmDeleteShop = async () => {
    if (!deletingShop) return;
    setIsDeleting(true);
    try {
      await api.deleteShop(deletingShop.id);
      showToast('দোকান সফলভাবে মুছে ফেলা হয়েছে', 'success');
      setDeletingShop(null);
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'দোকান মুছতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Line item handlers
  const handleAddItemRow = () => {
    const firstVar = availableVariants[0];
    setInvoiceForm((prev) => ({
      ...prev,
      items: [
        ...prev.items,
        {
          variant_id: firstVar?.variant_id || 0,
          product_id: firstVar?.product_id || 0,
          product_name: firstVar?.product_name || 'গেঞ্জি',
          color: firstVar?.color || 'কালো',
          size: firstVar?.size || 'L',
          quantity: 20,
          unit_price: firstVar?.unit_price || 280,
        },
      ],
    }));
  };

  const handleRemoveItemRow = (index: number) => {
    if (invoiceForm.items.length <= 1) {
      showToast('কমপক্ষে একটি পণ্য আইটেম থাকতে হবে', 'error');
      return;
    }
    setInvoiceForm((prev) => ({
      ...prev,
      items: prev.items.filter((_, idx) => idx !== index),
    }));
  };

  const handleVariantSelectChange = (index: number, variantIdStr: string) => {
    const vId = Number(variantIdStr);
    const selectedVar = availableVariants.find((v) => v.variant_id === vId);
    if (!selectedVar) return;

    setInvoiceForm((prev) => {
      const newItems = [...prev.items];
      newItems[index] = {
        ...newItems[index],
        variant_id: selectedVar.variant_id,
        product_id: selectedVar.product_id,
        product_name: selectedVar.product_name,
        color: selectedVar.color,
        size: selectedVar.size,
        unit_price: selectedVar.unit_price,
      };
      return { ...prev, items: newItems };
    });
  };

  const handleItemFieldChange = (index: number, field: string, value: any) => {
    setInvoiceForm((prev) => {
      const newItems = [...prev.items];
      newItems[index] = { ...newItems[index], [field]: value };
      return { ...prev, items: newItems };
    });
  };

  // Calculate gross, discount, net, paid, due
  const invoiceGross = invoiceForm.items.reduce(
    (sum, it) => sum + (Number(it.quantity) || 0) * (Number(it.unit_price) || 0),
    0
  );
  const invoiceTotalPieces = invoiceForm.items.reduce(
    (sum, it) => sum + (Number(it.quantity) || 0),
    0
  );
  const invoiceNet = Math.max(0, invoiceGross - (Number(invoiceForm.discount_amount) || 0));
  const invoiceDue = Math.max(0, invoiceNet - (Number(invoiceForm.paid_amount) || 0));

  // Save new sale invoice
  const handleSaveInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (invoiceForm.items.length === 0) {
      showToast('কমপক্ষে একটি পণ্য যুক্ত করুন', 'error');
      return;
    }

    try {
      const payload = {
        sale_date: invoiceForm.sale_date,
        shop_id: invoiceForm.shop_id ? Number(invoiceForm.shop_id) : null,
        customer_name: invoiceForm.customer_name,
        customer_phone: invoiceForm.customer_phone,
        discount_amount: Number(invoiceForm.discount_amount) || 0,
        paid_amount: Number(invoiceForm.paid_amount) || 0,
        payment_method: invoiceForm.payment_method,
        notes: invoiceForm.notes,
        items: invoiceForm.items.map((it) => ({
          product_id: it.product_id,
          variant_id: it.variant_id,
          product_name: it.product_name,
          size: it.size,
          color: it.color,
          quantity: Number(it.quantity) || 1,
          unit_price: Number(it.unit_price) || 0,
        })),
      };

      if (editingSale) {
        await api.updateSale(editingSale.id, payload);
        showToast('চালান সফলভাবে সংশোধন ও আপডেট করা হয়েছে!', 'success');
        setIsEditModalOpen(false);
      } else {
        await api.createSale(payload);
        showToast('নতুন পাইকারি বিক্রয় চালান সফলভাবে তৈরি হয়েছে!', 'success');
        setIsInvoiceModalOpen(false);
      }

      fetchData();
    } catch (err: any) {
      showToast(err.message || 'চালান সংরক্ষণ ব্যর্থ হয়েছে', 'error');
    }
  };

  // Open Edit Sale Modal
  const handleOpenEditSale = async (sale: Sale) => {
    setLoading(true);
    try {
      const detail = await api.getSaleDetail(sale.id);
      setEditingSale(detail.sale);

      setInvoiceForm({
        shop_id: detail.sale.shop_id ? String(detail.sale.shop_id) : '',
        customer_name: detail.sale.customer_name || '',
        customer_phone: detail.sale.customer_phone || '',
        sale_date: detail.sale.sale_date,
        payment_method: detail.sale.payment_method || 'নগদ ক্যাশ (Cash)',
        discount_amount: detail.sale.discount_amount || 0,
        paid_amount: detail.sale.paid_amount || 0,
        notes: detail.sale.notes || '',
        items: (detail.items || []).map((it: any) => ({
          variant_id: it.variant_id,
          product_id: it.product_id,
          product_name: it.product_name,
          color: it.color,
          size: it.size,
          quantity: it.quantity,
          unit_price: it.unit_price,
        })),
      });

      setIsEditModalOpen(true);
    } catch (err: any) {
      showToast(err.message || 'চালানের তথ্য লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Delete Sale with confirmation modal
  const handleDeleteSale = (sale: Sale) => {
    setDeletingSale(sale);
  };

  const handleConfirmDeleteSale = async () => {
    if (!deletingSale) return;
    setIsDeleting(true);
    try {
      await api.deleteSale(deletingSale.id);
      showToast(`চালান ${deletingSale.invoice_no} সফলভাবে মুছে ফেলা হয়েছে এবং স্টক ফেরত দেওয়া হয়েছে`, 'success');
      setDeletingSale(null);
      await fetchData();
    } catch (err: any) {
      showToast(err.message || 'চালান মুছতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Quick Print Invoice Directly
  const handleQuickPrintInvoice = async (saleId: number) => {
    setLoading(true);
    try {
      const res = await api.getSaleDetail(saleId);
      const invoiceData = { ...res.sale, items: res.items };
      const html = generateInvoiceHtml(invoiceData);
      printHtml(html, { title: `চালান_${res.sale.invoice_no}` });
    } catch (err: any) {
      showToast(err.message || 'চালান প্রিন্ট করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  // View & Print Invoice in Modal
  const handleViewInvoice = async (saleId: number) => {
    setLoading(true);
    try {
      const res = await api.getSaleDetail(saleId);
      setSelectedSaleDetail({ ...res.sale, items: res.items });
      setIsPrintModalOpen(true);
    } catch (err: any) {
      showToast(err.message || 'চালানের বিবরণ লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Universal Printing: Print Full Sales Ledger
  const handlePrintSalesLedger = () => {
    const dateStr = new Date().toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    let totalSoldPcs = 0;
    let totalGross = 0;
    let totalPaid = 0;
    let totalDue = 0;

    let rows = '';
    if (filteredSales.length === 0) {
      rows = `
        <tr>
          <td colspan="8" style="text-align: center; padding: 25px; color: #64748b;">
            কোনো বিক্রয় চালান পাওয়া যায়নি
          </td>
        </tr>
      `;
    } else {
      filteredSales.forEach((s, idx) => {
        totalSoldPcs += s.total_pieces || 0;
        totalGross += s.net_amount || 0;
        totalPaid += s.paid_amount || 0;
        totalDue += s.due_amount || 0;

        rows += `
          <tr>
            <td style="text-align: center;">${idx + 1}</td>
            <td style="font-family: monospace; font-weight: bold;">${s.invoice_no}<br><span style="font-size: 10px; color: #64748b;">${s.sale_date}</span></td>
            <td><strong>${s.shop_name}</strong><br><span style="font-size: 10px; color: #64748b;">${s.customer_name || ''} (${s.customer_phone || ''})</span></td>
            <td style="font-size: 10px;">${(s as any).items_summary || `${s.total_pieces || 0} পিস`}</td>
            <td style="text-align: right; font-weight: bold; font-family: monospace;">৳${Math.round(s.net_amount).toLocaleString('bn-BD')}</td>
            <td style="text-align: right; font-weight: bold; font-family: monospace; color: #064e3b;">৳${Math.round(s.paid_amount).toLocaleString('bn-BD')}</td>
            <td style="text-align: right; font-weight: bold; font-family: monospace; color: #e11d48;">৳${Math.round(s.due_amount).toLocaleString('bn-BD')}</td>
            <td style="text-align: center;">
              <span style="font-size: 10px; font-weight: bold; padding: 2px 6px; border-radius: 4px; background: ${
                s.payment_status === 'paid' ? '#dcfce7; color: #166534' : s.payment_status === 'partial' ? '#fef3c7; color: #92400e' : '#ffe4e6; color: #9f1239'
              };">
                ${s.payment_status === 'paid' ? 'পরিশোধিত' : s.payment_status === 'partial' ? 'আংশিক বাকি' : 'বকেয়া'}
              </span>
            </td>
          </tr>
        `;
      });
    }

    const html = `
      <div class="print-header">
        <h1 class="company-title">টেক্স ওয়্যার অ্যাপারেলস</h1>
        <p class="company-sub">প্লট #১২, কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর • পাইকারি গেঞ্জি বিক্রয় বিভাগ</p>
        <div class="doc-title">পাইকারি গেঞ্জি বিক্রয়, কালেকশন ও বকেয়া খাতা রিপোর্ট</div>
      </div>

      <div class="summary-strip">
        <div class="summary-item"><strong>রিপোর্ট তৈরির তারিখ:</strong> ${dateStr}</div>
        <div class="summary-item"><strong>মোট বিক্রয় চালান:</strong> ${filteredSales.length} টি</div>
        <div class="summary-item"><strong>সর্বমোট বিক্রিত গেঞ্জি:</strong> <strong>${totalSoldPcs} পিস</strong></div>
        <div class="summary-item"><strong>মোট বিক্রয় মূল্য:</strong> <strong>৳${Math.round(totalGross).toLocaleString('bn-BD')}</strong></div>
        <div class="summary-item"><strong>মোট কালেকশন:</strong> <strong style="color: #064e3b;">৳${Math.round(totalPaid).toLocaleString('bn-BD')}</strong></div>
        <div class="summary-item"><strong>মোট বাকি পাওনা:</strong> <strong style="color: #e11d48;">৳${Math.round(totalDue).toLocaleString('bn-BD')}</strong></div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 30px; text-align: center;">#</th>
            <th>চালান নং ও তারিখ</th>
            <th>দোকান / ক্রেতা</th>
            <th>বিক্রিত গেঞ্জি বিবরণ (সাইজ, কালার, পিস)</th>
            <th style="text-align: right;">মোট টাকা</th>
            <th style="text-align: right;">কালেকশন (জমা)</th>
            <th style="text-align: right;">বাকি পাওনা</th>
            <th style="text-align: center;">অবস্থা</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
        <tfoot>
          <tr style="background: #f1f5f9; font-weight: bold;">
            <td colspan="4" style="text-align: right; padding: 6px 10px;">সর্বমোট হিসাব:</td>
            <td style="text-align: right; font-family: monospace; font-size: 12px;">৳${Math.round(totalGross).toLocaleString('bn-BD')}</td>
            <td style="text-align: right; font-family: monospace; font-size: 12px; color: #064e3b;">৳${Math.round(totalPaid).toLocaleString('bn-BD')}</td>
            <td style="text-align: right; font-family: monospace; font-size: 12px; color: #e11d48;">৳${Math.round(totalDue).toLocaleString('bn-BD')}</td>
            <td></td>
          </tr>
        </tfoot>
      </table>

      <div class="signature-grid">
        <div><div class="signature-line">হিসাবরক্ষক</div></div>
        <div><div class="signature-line">বিক্রয় ব্যবস্থাপক</div></div>
        <div><div class="signature-line">অডিট ইনচার্জ</div></div>
        <div><div class="signature-line">ব্যবস্থাপনা পরিচালক</div></div>
      </div>
    `;

    printHtml(html, { title: `বিক্রয়_খাতা_${new Date().toISOString().split('T')[0]}` });
  };

  const formatTk = (n: number = 0) => '৳' + Math.round(n).toLocaleString('bn-BD');

  const handleCollectPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectDueSale) return;
    if (collectAmount <= 0) {
      showToast('আদায়কৃত টাকার সঠিক পরিমাণ দিন', 'error');
      return;
    }
    try {
      const detail = await api.getSaleDetail(collectDueSale.id);
      const newPaid = (detail.sale.paid_amount || 0) + collectAmount;
      const payload = {
        sale_date: detail.sale.sale_date,
        shop_id: detail.sale.shop_id,
        customer_name: detail.sale.customer_name,
        customer_phone: detail.sale.customer_phone,
        discount_amount: detail.sale.discount_amount,
        paid_amount: newPaid,
        payment_method: 'নগদ ক্যাশ (Cash)',
        notes: (detail.sale.notes ? detail.sale.notes + ' | ' : '') + `নগদ আদায়/নেওয়া: ৳${collectAmount}`,
        items: detail.items,
      };
      await api.updateSale(collectDueSale.id, payload);
      showToast(`চালান ${collectDueSale.invoice_no}: ৳${collectAmount} সফলভাবে আদায়/নেওয়া হয়েছে!`, 'success');
      setCollectDueSale(null);
      setCollectAmount(0);
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'টাকা আদায় সংরক্ষণ ব্যর্থ হয়েছে', 'error');
    }
  };

  const filteredSales = sales.filter((s) => {
    const q = searchTerm.toLowerCase();
    const matchesSearch =
      s.invoice_no.toLowerCase().includes(q) ||
      s.shop_name.toLowerCase().includes(q) ||
      (s.customer_name && s.customer_name.toLowerCase().includes(q)) ||
      (s.customer_phone && s.customer_phone.includes(q));

    if (!matchesSearch) return false;

    if (statusFilter === 'due') {
      return (s.due_amount || 0) > 0;
    }
    if (statusFilter === 'cash') {
      return (s.due_amount || 0) <= 0 && (s.paid_amount || 0) > 0;
    }
    if (statusFilter === 'given') {
      // All orders where items have been given/dispatched
      return (s.total_pieces || 0) > 0;
    }
    if (statusFilter === 'taken') {
      // All orders where payment has been taken/collected
      return (s.paid_amount || 0) > 0;
    }
    return true;
  });

  const dueCount = sales.filter((s) => (s.due_amount || 0) > 0).length;
  const cashCount = sales.filter((s) => (s.due_amount || 0) <= 0 && (s.paid_amount || 0) > 0).length;
  const givenCount = sales.filter((s) => (s.total_pieces || 0) > 0).length;
  const takenCount = sales.filter((s) => (s.paid_amount || 0) > 0).length;

  return (
    <div className="space-y-6 pb-14 font-['Hind_Siliguri',sans-serif]">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <ShoppingCart className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              পাইকারি বিক্রয়, ক্রেতা ও চালান খাতা
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            গেঞ্জির সাইজ ও কালারভিত্তিক বিক্রিত পিস, মোট মূল্য, কালেকশন ও বকেয়া হিসাব (এডিট ও ডিলিট সুবিধাসহ)
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handlePrintSalesLedger}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            title="সম্পূর্ণ বিক্রয় খাতা প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>বিক্রয় খাতা প্রিন্ট</span>
          </button>

          <button
            onClick={fetchData}
            title="রিফ্রেশ করুন"
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl border border-slate-200 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={handleOpenAddShop}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <UserPlus className="w-4 h-4 text-emerald-600" />
            <span>+ নতুন ক্রেতা / দোকান যোগ</span>
          </button>

          <button
            onClick={handleOpenAddInvoice}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs shadow-emerald-600/20 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ নতুন বিক্রয় চালান</span>
          </button>
        </div>
      </div>

      {/* Main Tabs */}
      <div className="flex border-b border-slate-200 text-xs font-semibold gap-2">
        <button
          onClick={() => setActiveTab('sales')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors flex items-center gap-2 ${
            activeTab === 'sales'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>বিক্রয় চালান তালিকা ({sales.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('shops')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors flex items-center gap-2 ${
            activeTab === 'shops'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>পাইকারি দোকান ও ক্রেতা খাতা ({shops.length})</span>
        </button>
      </div>

      {/* TAB 1: SALES INVOICES LIST */}
      {activeTab === 'sales' && (
        <div className="space-y-4">
          {/* Search bar & Status Filter Buttons */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs space-y-2.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="চালান নং, দোকানের নাম বা ফোন নম্বর দিয়ে খুঁজুন..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                />
              </div>
              <div className="text-xs text-slate-500 font-medium">
                মোট প্রদর্শিত চালান: <span className="font-bold text-slate-800">{filteredSales.length}</span> টি
              </div>
            </div>

            {/* Quick Status Filter Tabs (সকল, বাকি, নগদ, দেওয়া, নেওয়া) */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-400 mr-1">ফিল্টার:</span>

              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                সব চালান ({sales.length})
              </button>

              <button
                type="button"
                onClick={() => setStatusFilter('due')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  statusFilter === 'due'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200/60'
                }`}
              >
                <span>বাকি (Due)</span>
                <span className="px-1.5 py-0.2 rounded-full bg-rose-200/60 text-[10px] font-mono">
                  {dueCount}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setStatusFilter('cash')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  statusFilter === 'cash'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200/60'
                }`}
              >
                <span>নগদ (Cash)</span>
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-200/60 text-[10px] font-mono">
                  {cashCount}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setStatusFilter('given')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  statusFilter === 'given'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200/60'
                }`}
              >
                <PackageCheck className="w-3.5 h-3.5" />
                <span>দেওয়া (Given / ডেলিভারি)</span>
                <span className="px-1.5 py-0.2 rounded-full bg-blue-200/60 text-[10px] font-mono">
                  {givenCount}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setStatusFilter('taken')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  statusFilter === 'taken'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200/60'
                }`}
              >
                <HandCoins className="w-3.5 h-3.5" />
                <span>নেওয়া (Taken / আদায়)</span>
                <span className="px-1.5 py-0.2 rounded-full bg-amber-200/60 text-[10px] font-mono">
                  {takenCount}
                </span>
              </button>
            </div>
          </div>

          {/* Sales Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                  <tr>
                    <th className="py-3.5 px-4">চালান নং ও তারিখ</th>
                    <th className="py-3.5 px-4">দোকান / ক্রেতা</th>
                    <th className="py-3.5 px-4">বিক্রিত পণ্যের বিবরণ (সাইজ ও কালার)</th>
                    <th className="py-3.5 px-4 text-center">মোট পরিমাণ</th>
                    <th className="py-3.5 px-4 text-right">মোট টাকা</th>
                    <th className="py-3.5 px-4 text-right">কালেকশন (জমা)</th>
                    <th className="py-3.5 px-4 text-right">বাকি পাওনা</th>
                    <th className="py-3.5 px-4 text-center">অবস্থা</th>
                    <th className="py-3.5 px-4 text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loading ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-400">
                        <div className="w-8 h-8 border-2 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto mb-2" />
                        বিক্রয় তথ্য লোড হচ্ছে...
                      </td>
                    </tr>
                  ) : filteredSales.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-400">
                        কোনো বিক্রয় চালান পাওয়া যায়নি
                      </td>
                    </tr>
                  ) : (
                    filteredSales.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50/80">
                        {/* Invoice & Date */}
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-800 font-mono">{s.invoice_no}</div>
                          <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                            <Calendar className="w-3 h-3" />
                            {s.sale_date}
                          </div>
                        </td>

                        {/* Customer / Shop */}
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-800">{s.shop_name}</div>
                          <div className="text-[11px] text-slate-500">
                            {s.customer_name || 'মালিক'} {s.customer_phone ? `• ${s.customer_phone}` : ''}
                          </div>
                        </td>

                        {/* Item Details: Color, Size, Pieces */}
                        <td className="py-3 px-4 max-w-xs">
                          <div className="text-slate-700 font-medium line-clamp-2">
                            {(s as any).items_summary || 'গেঞ্জি লট'}
                          </div>
                        </td>

                        {/* Quantity */}
                        <td className="py-3 px-4 text-center font-bold text-slate-800 font-mono">
                          {s.total_pieces || 0} পিস
                        </td>

                        {/* Net Amount */}
                        <td className="py-3 px-4 text-right font-bold font-mono text-slate-900 text-sm">
                          {formatTk(s.net_amount)}
                        </td>

                        {/* Paid Amount (Collection) */}
                        <td className="py-3 px-4 text-right font-bold font-mono text-emerald-700">
                          {formatTk(s.paid_amount)}
                        </td>

                        {/* Due Amount */}
                        <td className="py-3 px-4 text-right font-bold font-mono text-rose-600">
                          {formatTk(s.due_amount)}
                        </td>

                        {/* Payment Status */}
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              s.payment_status === 'paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : s.payment_status === 'partial'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {s.payment_status === 'paid'
                              ? 'পরিশোধিত'
                              : s.payment_status === 'partial'
                              ? 'আংশিক বাকি'
                              : 'বকেয়া'}
                          </span>
                        </td>

                        {/* Actions: Quick Taken, Print, Edit, Delete */}
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {(s.due_amount || 0) > 0 && (
                              <button
                                onClick={() => {
                                  setCollectDueSale(s);
                                  setCollectAmount(s.due_amount || 0);
                                }}
                                className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                                title="বাকি টাকা আদায় / নেওয়া (Taken)"
                              >
                                <HandCoins className="w-3.5 h-3.5" />
                                <span>নেওয়া</span>
                              </button>
                            )}

                            <button
                              onClick={() => handleQuickPrintInvoice(s.id)}
                              className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg cursor-pointer transition-colors"
                              title="সরাসরি চালান প্রিন্ট করুন"
                            >
                              <Printer className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleViewInvoice(s.id)}
                              className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg cursor-pointer transition-colors"
                              title="চালান প্রিভিউ ও প্রিন্ট দেখুন"
                            >
                              <Eye className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleOpenEditSale(s)}
                              className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                              title="চালান এডিট / সংশোধন করুন"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleDeleteSale(s)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                              title="চালান ডিলিট করুন (স্টক ফেরত যাবে)"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SHOPS & CUSTOMERS DIRECTORY */}
      {activeTab === 'shops' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200/80 flex items-center justify-between gap-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                পাইকারি দোকান ও গ্রাহক তালিকা
              </h3>
              <p className="text-[11px] text-slate-400">
                সকল নিয়মিত পাইকারি পার্টি, তাদের প্রোপাইটার, ক্রেডিট লিমিট ও বর্তমান বকেয়া খাতা
              </p>
            </div>
            <button
              onClick={handleOpenAddShop}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>নতুন দোকান যোগ</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/60 border-b border-slate-200 text-slate-500 font-bold uppercase text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">দোকানের নাম ও কোড</th>
                  <th className="py-3.5 px-4">প্রোপাইটার ও মোবাইল</th>
                  <th className="py-3.5 px-4">মার্কেট ও ঠিকানা</th>
                  <th className="py-3.5 px-4 text-right">ক্রেডিট লিমিট</th>
                  <th className="py-3.5 px-4 text-right">সর্বমোট ক্রয়</th>
                  <th className="py-3.5 px-4 text-right">বর্তমান মোট বাকি (Due)</th>
                  <th className="py-3.5 px-4 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {shops.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      কোনো পাইকারি দোকান বা পার্টি নিবন্ধিত নেই
                    </td>
                  </tr>
                ) : (
                  shops.map((shop) => (
                    <tr key={shop.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-800">{shop.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{shop.shop_code}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-700">{shop.owner_name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{shop.phone}</div>
                      </td>

                      <td className="py-3 px-4 text-slate-600">{shop.address || '—'}</td>

                      <td className="py-3 px-4 text-right font-mono text-slate-600">
                        {formatTk(shop.credit_limit)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-800">
                        {formatTk(shop.total_purchased)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-rose-600 text-sm">
                        {formatTk(shop.current_due)}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleOpenEditShop(shop)}
                            className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                            title="দোকান তথ্য এডিট করুন"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteShop(shop)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                            title="দোকান মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: ADD / EDIT SALE INVOICE */}
      <Modal
        isOpen={isInvoiceModalOpen || isEditModalOpen}
        onClose={() => {
          setIsInvoiceModalOpen(false);
          setIsEditModalOpen(false);
          setEditingSale(null);
        }}
        title={editingSale ? `চালান সংশোধন: ${editingSale.invoice_no}` : 'নতুন পাইকারি বিক্রয় চালান'}
        subtitle="গেঞ্জির সাইজ, কালার, পরিমাণ ও কালেকশন এন্ট্রি"
        maxWidth="max-w-3xl"
      >
        <form onSubmit={handleSaveInvoice} className="space-y-4 text-xs font-['Hind_Siliguri',sans-serif]">
          {/* Row 1: Shop Selection & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Shop select */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">দোকান / ক্রেতা *</label>
                <button
                  type="button"
                  onClick={handleOpenAddShop}
                  className="text-[10px] text-emerald-700 font-bold hover:underline cursor-pointer"
                >
                  + নতুন দোকান
                </button>
              </div>
              <select
                value={invoiceForm.shop_id}
                onChange={(e) => {
                  const sId = e.target.value;
                  const found = shops.find((s) => String(s.id) === sId);
                  setInvoiceForm({
                    ...invoiceForm,
                    shop_id: sId,
                    customer_name: found ? found.owner_name : invoiceForm.customer_name,
                    customer_phone: found ? found.phone : invoiceForm.customer_phone,
                  });
                }}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              >
                <option value="">সাধারণ পাইকারি ক্রেতা (বিনা দোকান)</option>
                {shops.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.owner_name} - {s.phone})
                  </option>
                ))}
              </select>
            </div>

            {/* Customer Name & Phone */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ক্রেতা / প্রোপাইটার নাম</label>
              <input
                type="text"
                value={invoiceForm.customer_name}
                onChange={(e) => setInvoiceForm({ ...invoiceForm, customer_name: e.target.value })}
                placeholder="নাম লিখুন"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">মোবাইল নম্বর ও তারিখ</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={invoiceForm.customer_phone}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, customer_phone: e.target.value })}
                  placeholder="017XXXXXXXX"
                  className="w-1/2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
                <input
                  type="date"
                  value={invoiceForm.sale_date}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, sale_date: e.target.value })}
                  className="w-1/2 px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                  required
                />
              </div>
            </div>
          </div>

          {/* Line Items Table (Products, Color, Size, Quantity, Unit Price) */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <span>বিক্রিত গেঞ্জি আইটেমসমূহ</span>
                <span className="text-[11px] text-slate-500 font-normal">
                  (মোট {invoiceTotalPieces} পিস)
                </span>
              </h4>
              <button
                type="button"
                onClick={handleAddItemRow}
                className="px-2.5 py-1 bg-white hover:bg-slate-100 text-emerald-700 border border-emerald-300 rounded-lg text-xs font-bold cursor-pointer transition-colors"
              >
                + আরও আইটেম যোগ করুন
              </button>
            </div>

            <div className="space-y-2">
              {invoiceForm.items.map((row, idx) => (
                <div
                  key={idx}
                  className="bg-white p-2.5 rounded-xl border border-slate-200 grid grid-cols-12 gap-2 items-center text-xs"
                >
                  {/* Select product variant */}
                  <div className="col-span-12 sm:col-span-5">
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">
                      পণ্য, কালার ও সাইজ *
                    </label>
                    <select
                      value={row.variant_id}
                      onChange={(e) => handleVariantSelectChange(idx, e.target.value)}
                      className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold"
                    >
                      {availableVariants.map((v) => (
                        <option key={v.variant_id} value={v.variant_id}>
                          {v.product_name} • {v.color} • সাইজ {v.size} (মজুদ: {v.stock} পিস)
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Quantity */}
                  <div className="col-span-4 sm:col-span-2">
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">
                      পরিমাণ (পিস) *
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={row.quantity}
                      onChange={(e) =>
                        handleItemFieldChange(idx, 'quantity', Math.max(1, parseInt(e.target.value, 10) || 0))
                      }
                      className="w-full px-2 py-1.5 text-center font-mono font-bold border border-slate-200 rounded-lg"
                      required
                    />
                  </div>

                  {/* Unit price */}
                  <div className="col-span-4 sm:col-span-2">
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">
                      দর (৳) *
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={row.unit_price}
                      onChange={(e) =>
                        handleItemFieldChange(idx, 'unit_price', Number(e.target.value) || 0)
                      }
                      className="w-full px-2 py-1.5 text-right font-mono font-bold border border-slate-200 rounded-lg"
                      required
                    />
                  </div>

                  {/* Line Total */}
                  <div className="col-span-3 sm:col-span-2 text-right">
                    <span className="block text-[10px] text-slate-400 font-bold mb-0.5">মোট মূল্য</span>
                    <span className="font-mono font-bold text-slate-900">
                      {formatTk(row.quantity * row.unit_price)}
                    </span>
                  </div>

                  {/* Remove */}
                  <div className="col-span-1 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveItemRow(idx)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                      title="আইটেম বাদ দিন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pricing & Collection Summary Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
            {/* Left: Payment info */}
            <div className="space-y-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                <select
                  value={invoiceForm.payment_method}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, payment_method: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                >
                  <option value="নগদ ক্যাশ (Cash)">নগদ ক্যাশ (Cash)</option>
                  <option value="বিকাশ / নগদ (bKash/Nagad)">বিকাশ / নগদ (bKash/Nagad)</option>
                  <option value="ব্যাংক চেক (Cheque)">ব্যাংক চেক (Cheque)</option>
                  <option value="ব্যাংক ট্রান্সফার (Bank)">ব্যাংক ট্রান্সফার (Bank)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">নোট / মন্তব্য</label>
                <input
                  type="text"
                  value={invoiceForm.notes}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, notes: e.target.value })}
                  placeholder="যেমন: কার্টুন #০২, বাবুবাজার ডেলিভারি"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                />
              </div>
            </div>

            {/* Right: Calculations (Gross, Discount, Net, Paid, Due) */}
            <div className="space-y-2 bg-white p-3 rounded-xl border border-slate-200">
              <div className="flex justify-between items-center text-slate-600">
                <span>মোট পণ্যের মূল্য (Gross):</span>
                <span className="font-mono font-bold">{formatTk(invoiceGross)}</span>
              </div>

              <div className="flex justify-between items-center text-slate-700">
                <span>বিশেষ ছাড় (Discount):</span>
                <div className="flex items-center gap-1">
                  <span>৳</span>
                  <input
                    type="number"
                    min={0}
                    value={invoiceForm.discount_amount}
                    onChange={(e) =>
                      setInvoiceForm({ ...invoiceForm, discount_amount: Number(e.target.value) || 0 })
                    }
                    className="w-24 px-2 py-1 text-right font-mono font-bold border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center text-slate-900 font-bold border-t border-slate-200 pt-1.5 text-sm">
                <span>সর্বমোট প্রদেয় (Net):</span>
                <span className="font-mono text-base">{formatTk(invoiceNet)}</span>
              </div>

              {/* Quick Settlement Action Buttons (বাকি, নগদ, দেওয়া, নেওয়া) */}
              <div className="pt-2 border-t border-slate-100">
                <span className="block text-[10px] text-slate-400 font-bold mb-1.5 uppercase tracking-wider">
                  দ্রুত সেটেলমেন্ট বাটন:
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setInvoiceForm((prev) => ({
                        ...prev,
                        paid_amount: invoiceNet,
                        payment_method: 'নগদ ক্যাশ (Cash)',
                      }));
                      showToast('নগদ পরিশোধ নির্বাচন করা হয়েছে (বাকি ৳০)', 'info');
                    }}
                    className="px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold text-center cursor-pointer transition-colors"
                  >
                    নগদ (Cash)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setInvoiceForm((prev) => ({
                        ...prev,
                        paid_amount: 0,
                      }));
                      showToast('সম্পূর্ণ বাকি চালান নির্ধারণ করা হয়েছে', 'info');
                    }}
                    className="px-2 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 rounded-lg text-xs font-bold text-center cursor-pointer transition-colors"
                  >
                    বাকি (Due)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setInvoiceForm((prev) => ({
                        ...prev,
                        notes: prev.notes ? `${prev.notes} | মাল ডেলিভারি সম্পন্ন (Given)` : 'মাল ডেলিভারি সম্পন্ন (Given)',
                      }));
                      showToast('গেঞ্জি মাল ডেলিভারি দেওয়া চিহ্নিত করা হয়েছে', 'info');
                    }}
                    className="px-2 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-300 rounded-lg text-xs font-bold text-center cursor-pointer transition-colors"
                  >
                    দেওয়া (Given)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const half = Math.round(invoiceNet / 2);
                      setInvoiceForm((prev) => ({
                        ...prev,
                        paid_amount: half,
                        payment_method: 'নগদ ক্যাশ (Cash)',
                      }));
                      showToast(`৫০% অগ্রিম নেওয়া হয়েছে: ৳${half}`, 'info');
                    }}
                    className="px-2 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-lg text-xs font-bold text-center cursor-pointer transition-colors"
                  >
                    নেওয়া (Taken)
                  </button>
                </div>
              </div>

              {/* Paid Amount (কালেকশন) */}
              <div className="flex justify-between items-center text-emerald-700 font-bold">
                <span>কালেকশন / জমা প্রদান (Paid):</span>
                <div className="flex items-center gap-1">
                  <span>৳</span>
                  <input
                    type="number"
                    min={0}
                    value={invoiceForm.paid_amount}
                    onChange={(e) =>
                      setInvoiceForm({ ...invoiceForm, paid_amount: Number(e.target.value) || 0 })
                    }
                    className="w-28 px-2 py-1 text-right font-mono font-bold border border-emerald-300 rounded-lg text-xs bg-emerald-50/50"
                  />
                </div>
              </div>

              {/* Due Balance */}
              <div className="flex justify-between items-center text-rose-600 font-bold border-t border-slate-200 pt-1">
                <span>বাকি পাওনা (Due):</span>
                <span className="font-mono text-sm">{formatTk(invoiceDue)}</span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setIsInvoiceModalOpen(false);
                setIsEditModalOpen(false);
                setEditingSale(null);
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-xs cursor-pointer"
            >
              {editingSale ? 'চালান আপডেট করুন' : 'চালান সংরক্ষণ করুন'}
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL 2: ADD / EDIT SHOP */}
      <Modal
        isOpen={isShopModalOpen}
        onClose={() => setIsShopModalOpen(false)}
        title={editingShop ? `দোকান তথ্য এডিট: ${editingShop.name}` : 'নতুন পাইকারি দোকান ও ক্রেতা নিবন্ধন'}
        subtitle="পাইকারি গ্রাহক প্রোফাইল ও খাতা খুলুন"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSaveShop} className="space-y-3.5 text-xs font-['Hind_Siliguri',sans-serif]">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              দোকান বা ব্যবসা প্রতিষ্ঠানের নাম *
            </label>
            <input
              type="text"
              value={shopForm.name}
              onChange={(e) => setShopForm({ ...shopForm, name: e.target.value })}
              placeholder="যেমন: হাজী ট্রেডার্স, নিউ ফ্যাশন পয়েন্ট"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              required
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                মালিক / ক্রেতার নাম
              </label>
              <input
                type="text"
                value={shopForm.owner_name}
                onChange={(e) => setShopForm({ ...shopForm, owner_name: e.target.value })}
                placeholder="প্রোপাইটার নাম"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                মোবাইল নম্বর *
              </label>
              <input
                type="text"
                value={shopForm.phone}
                onChange={(e) => setShopForm({ ...shopForm, phone: e.target.value })}
                placeholder="017XXXXXXXX"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              মার্কেট ও ঠিকানা
            </label>
            <input
              type="text"
              value={shopForm.address}
              onChange={(e) => setShopForm({ ...shopForm, address: e.target.value })}
              placeholder="যেমন: বাবুবাজার মার্কেট, দোকান নং #১২, ঢাকা"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ক্রেডিট লিমিট (৳)
              </label>
              <input
                type="number"
                min={0}
                value={shopForm.credit_limit}
                onChange={(e) => setShopForm({ ...shopForm, credit_limit: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
            </div>

            {!editingShop && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  প্রারম্ভিক বকেয়া (৳)
                </label>
                <input
                  type="number"
                  min={0}
                  value={shopForm.opening_due}
                  onChange={(e) => setShopForm({ ...shopForm, opening_due: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-rose-600 font-bold"
                />
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              নোট বা মন্তব্য (ঐচ্ছিক)
            </label>
            <input
              type="text"
              value={shopForm.notes}
              onChange={(e) => setShopForm({ ...shopForm, notes: e.target.value })}
              placeholder="নিয়মিত কাস্টমার, ক্যাশ পার্টি ইত্যাদি"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsShopModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-xs cursor-pointer"
            >
              {editingShop ? 'আপডেট করুন' : 'দোকান যোগ করুন'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Quick Payment Collection / Taken Modal */}
      {collectDueSale && (
        <Modal
          isOpen={!!collectDueSale}
          onClose={() => setCollectDueSale(null)}
          title={`বাকি টাকা আদায় / নেওয়া (Taken): ${collectDueSale.invoice_no}`}
          subtitle={`দোকান: ${collectDueSale.shop_name} • মোট বকেয়া পাওনা: ${formatTk(collectDueSale.due_amount)}`}
          maxWidth="max-w-md"
        >
          <form onSubmit={handleCollectPayment} className="space-y-4 text-xs font-['Hind_Siliguri',sans-serif]">
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1">
              <div className="flex justify-between text-slate-700">
                <span>চালানের মোট মূল্য:</span>
                <span className="font-mono font-bold">{formatTk(collectDueSale.net_amount)}</span>
              </div>
              <div className="flex justify-between text-emerald-700">
                <span>পূর্বে জমা/নেওয়া:</span>
                <span className="font-mono font-bold">{formatTk(collectDueSale.paid_amount)}</span>
              </div>
              <div className="flex justify-between text-rose-600 font-bold text-sm border-t border-amber-200/60 pt-1">
                <span>বর্তমান বকেয়া বাকি:</span>
                <span className="font-mono">{formatTk(collectDueSale.due_amount)}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                এখন কত টাকা আদায়/নেওয়া হলো? (৳) *
              </label>
              <input
                type="number"
                min={1}
                max={collectDueSale.due_amount || undefined}
                value={collectAmount}
                onChange={(e) => setCollectAmount(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-base font-bold text-emerald-700"
                required
                autoFocus
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCollectAmount(collectDueSale.due_amount || 0)}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                পুরো বাকি পরিশোধ ({formatTk(collectDueSale.due_amount)})
              </button>
              {(collectDueSale.due_amount || 0) > 100 && (
                <button
                  type="button"
                  onClick={() => setCollectAmount(Math.round((collectDueSale.due_amount || 0) / 2))}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  ৫০% পরিশোধ
                </button>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCollectDueSale(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <HandCoins className="w-4 h-4" />
                <span>টাকা জমা ও রিসিট আপডেট</span>
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Invoice Print & Cash Memo Modal */}
      <InvoicePrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        sale={selectedSaleDetail}
      />

      {/* Delete Sale Confirmation Modal */}
      {deletingSale && (
        <Modal
          isOpen={Boolean(deletingSale)}
          onClose={() => !isDeleting && setDeletingSale(null)}
          title={`বিক্রয় চালান ডিলিট: ${deletingSale.invoice_no}`}
          subtitle="চালান মুছে ফেলা ও স্টক সমন্বয়"
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 space-y-1.5">
              <p className="font-bold flex items-center gap-1.5 text-rose-900 text-sm">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                সতর্কবার্তা: চালান ডিলিট নিশ্চিতকরণ
              </p>
              <p>
                আপনি কি নিশ্চিত যে চালান <strong>{deletingSale.invoice_no}</strong> ({deletingSale.shop_name}) মুছে ফেলতে চান?
              </p>
              <ul className="list-disc list-inside space-y-0.5 text-rose-700 text-[11px] pt-1">
                <li>বিক্রিত পণ্যগুলো স্বয়ংক্রিয়ভাবে তৈরি পোশাক স্টকে (ইনভেন্টরি) ফেরত যাবে</li>
                <li>ক্রেতার দোকান থেকে এই চালানের বকেয়া সমন্বয় হবে</li>
                <li>জমা দেওয়া কোনো পেমেন্ট রেকর্ড থাকলে তা বাতিল হবে</li>
              </ul>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setDeletingSale(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-medium cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDeleteSale}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, চালান ডিলিট করুন'}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete Shop Confirmation Modal */}
      {deletingShop && (
        <Modal
          isOpen={Boolean(deletingShop)}
          onClose={() => !isDeleting && setDeletingShop(null)}
          title="দোকান / পাইকারি ক্রেতা ডিলিট"
          subtitle={deletingShop.name}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <p className="text-slate-600">
              আপনি কি নিশ্চিত যে <strong>{deletingShop.name}</strong> (প্রোপাইটার: {deletingShop.owner_name}) এর খাতা ডিলিট করতে চান?
            </p>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setDeletingShop(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-medium cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDeleteShop}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, দোকান মুছুন'}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
