import React from 'react';
import { Printer, Shirt, CheckCircle2, Building2 } from 'lucide-react';
import { Modal } from '../common/Modal';
import { printHtml } from '../../utils/printDocument';

interface InvoicePrintModalProps {
  sale: any | null;
  isOpen: boolean;
  onClose: () => void;
}

export function generateInvoiceHtml(sale: any): string {
  const formatTk = (n: number = 0) => '৳' + Math.round(n).toLocaleString('bn-BD');

  const statusText =
    sale.payment_status === 'paid'
      ? 'পরিশোধিত (PAID)'
      : sale.payment_status === 'partial'
      ? 'আংশিক বাকি (PARTIAL)'
      : 'বাকি (DUE)';

  const statusBadgeClass =
    sale.payment_status === 'paid'
      ? 'badge badge-paid'
      : sale.payment_status === 'partial'
      ? 'badge badge-partial'
      : 'badge badge-due';

  const itemsRows =
    sale.items && sale.items.length > 0
      ? sale.items
          .map(
            (it: any, idx: number) => `
          <tr>
            <td style="text-align: center; width: 35px;">${idx + 1}</td>
            <td style="font-weight: bold; color: #0f172a;">${it.product_name || 'গেঞ্জি'}</td>
            <td style="text-align: center;"><strong>${it.size || '—'}</strong> (${it.color || 'সকল কালার'})</td>
            <td style="text-align: right; font-family: monospace; font-weight: bold;">${it.quantity} পিস</td>
            <td style="text-align: right; font-family: monospace;">${formatTk(it.unit_price)}</td>
            <td style="text-align: right; font-family: monospace; font-weight: bold;">${formatTk(it.total_price)}</td>
          </tr>
        `
          )
          .join('')
      : `
        <tr>
          <td colspan="6" style="text-align: center; padding: 15px; color: #64748b;">
            কোনো পণ্য আইটেম রেকর্ড নেই
          </td>
        </tr>
      `;

  return `
    <div class="print-header">
      <h1 class="company-title">টেক্স ওয়্যার অ্যাপারেলস</h1>
      <p class="company-sub">Texware Apparels Ltd. • পাইকারি গেঞ্জি ম্যানুফ্যাকচারিং ও সাপ্লাই</p>
      <p class="company-sub">প্লট #১২, কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর | ফোন: +880 1711-000000 | ইমেইল: texwareapparels@gmail.com</p>
      <div class="doc-title">পাইকারি বিক্রয় চালান ও ক্যাশ মেমো (INVOICE)</div>
    </div>

    <div class="summary-strip">
      <div class="summary-item"><strong>চালান নং:</strong> <span style="font-family: monospace; font-weight: bold;">${sale.invoice_no}</span></div>
      <div class="summary-item"><strong>তারিখ:</strong> ${sale.sale_date || new Date().toISOString().split('T')[0]}</div>
      <div class="summary-item"><strong>ক্রেতার দোকান:</strong> <span style="font-weight: bold; color: #064e3b;">${sale.shop_name}</span></div>
      <div class="summary-item"><strong>প্রোপাইটার:</strong> ${sale.customer_name || 'ম্যানেজার'}</div>
      <div class="summary-item"><strong>মোবাইল:</strong> <span style="font-family: monospace;">${sale.customer_phone || '—'}</span></div>
      <div class="summary-item"><strong>পেমেন্ট অবস্থা:</strong> <span class="${statusBadgeClass}">${statusText}</span></div>
    </div>

    <table>
      <thead>
        <tr>
          <th style="width: 35px; text-align: center;">ক্র নং</th>
          <th>গেঞ্জির বিবরণ / পণ্য</th>
          <th style="text-align: center;">সাইজ ও রঙ</th>
          <th style="text-align: right;">পরিমাণ (Pcs)</th>
          <th style="text-align: right;">দর (টাকা)</th>
          <th style="text-align: right;">মোট মূল্য (টাকা)</th>
        </tr>
      </thead>
      <tbody>
        ${itemsRows}
      </tbody>
      <tfoot>
        <tr>
          <td colspan="5" style="text-align: right; font-weight: bold; padding: 6px 10px;">মোট মূল্য (Gross Total):</td>
          <td style="text-align: right; font-weight: bold; font-family: monospace; padding: 6px 10px;">${formatTk(sale.gross_amount)}</td>
        </tr>
        ${
          sale.discount_amount > 0
            ? `
        <tr>
          <td colspan="5" style="text-align: right; color: #047857; padding: 4px 10px;">বিশেষ ছাড় (Discount):</td>
          <td style="text-align: right; font-family: monospace; color: #047857; padding: 4px 10px;">-${formatTk(sale.discount_amount)}</td>
        </tr>`
            : ''
        }
        <tr style="background: #f1f5f9; font-weight: bold; font-size: 12px;">
          <td colspan="5" style="text-align: right; padding: 7px 10px; color: #0f172a;">সর্বমোট প্রদেয় (Net Amount):</td>
          <td style="text-align: right; font-family: monospace; color: #0f172a; padding: 7px 10px;">${formatTk(sale.net_amount)}</td>
        </tr>
        <tr style="color: #065f46; font-weight: bold;">
          <td colspan="5" style="text-align: right; padding: 5px 10px;">জমা প্রদান (Paid Amount):</td>
          <td style="text-align: right; font-family: monospace; padding: 5px 10px;">${formatTk(sale.paid_amount)}</td>
        </tr>
        <tr style="color: #991b1b; font-weight: bold; background: #fff1f2;">
          <td colspan="5" style="text-align: right; padding: 6px 10px;">বর্তমান বকেয়া (Due Amount):</td>
          <td style="text-align: right; font-family: monospace; padding: 6px 10px;">${formatTk(sale.due_amount)}</td>
        </tr>
      </tfoot>
    </table>

    <div style="margin-top: 12px; font-size: 10px; color: #475569; border: 1px dashed #cbd5e1; padding: 8px; border-radius: 6px; background: #fafafa;">
      <strong>শর্তাবলী:</strong> ১. ডেলিভারির সময় কার্টুন বা বান্ডিল মিলিয়ে বুঝে নিন। ২. কোনো প্রকার প্রস্তুত ত্রুটি থাকলে বিক্রির ৩ দিনের মধ্যে ফ্যাক্টরিতে পরিবর্তনযোগ্য। ৩. এটি কম্পিউটার জেনারেটেড আসল চালান।
    </div>

    <div class="signature-grid">
      <div>
        <div class="signature-line">ক্রেতার স্বাক্ষর ও সীলমোহর</div>
      </div>
      <div>
        <div class="signature-line">টেক্স ওয়্যার অ্যাপারেলস পক্ষে অনুমোদিত</div>
      </div>
    </div>
  `;
}

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({ sale, isOpen, onClose }) => {
  if (!isOpen || !sale) return null;

  const handlePrint = () => {
    const html = generateInvoiceHtml(sale);
    printHtml(html, { title: `চালান_${sale.invoice_no}` });
  };

  const formatTk = (n: number = 0) => '৳' + Math.round(n).toLocaleString('bn-BD');

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`পাইকারি বিক্রয় চালান: ${sale.invoice_no}`}
      subtitle="চালান ও ক্যাশ মেমো প্রিন্ট করুন"
      maxWidth="3xl"
    >
      <div className="space-y-4">
        {/* Invoice Container */}
        <div id="printable-invoice" className="bg-white p-5 sm:p-6 border border-slate-300 rounded-xl space-y-5 text-xs text-slate-800">
          {/* Invoice Header */}
          <div className="flex items-start justify-between border-b pb-4 border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold">
                <Shirt className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900 tracking-tight">টেক্স ওয়্যার অ্যাপারেলস</h2>
                <p className="text-[11px] text-slate-500">Texware Apparels Ltd. • হোলসেল ও নিটওয়্যার ফ্যাক্টরি</p>
                <p className="text-[11px] text-slate-400">প্লট #১২, কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর • ফোন: +880 1711-000000</p>
              </div>
            </div>
            <div className="text-right">
              <span className="inline-block px-3 py-1 bg-emerald-100 text-emerald-800 rounded font-bold text-xs uppercase tracking-wider">
                পাইকারি চালান ও ক্যাশ মেমো
              </span>
              <div className="text-[11px] font-mono font-bold text-slate-800 mt-1">চালান নং: {sale.invoice_no}</div>
              <div className="text-[11px] text-slate-500">তারিখ: {sale.sale_date}</div>
            </div>
          </div>

          {/* Customer & Shop Details */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 flex flex-col sm:flex-row justify-between gap-3 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">ক্রেতা / পাইকারি দোকান:</span>
              <h4 className="font-bold text-sm text-slate-800">{sale.shop_name}</h4>
              <p className="text-slate-600 mt-0.5">প্রোপাইটার: {sale.customer_name || 'ম্যানেজার'}</p>
              <p className="text-slate-500 font-mono">মোবাইল: {sale.customer_phone || '—'}</p>
            </div>
            <div className="sm:text-right">
              <span className="text-[10px] text-slate-400 block uppercase font-bold">পেমেন্ট অবস্থা:</span>
              <span
                className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold mt-1 ${
                  sale.payment_status === 'paid'
                    ? 'bg-emerald-100 text-emerald-800'
                    : sale.payment_status === 'partial'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {sale.payment_status === 'paid'
                  ? 'সম্পূর্ণ পরিশোধিত'
                  : sale.payment_status === 'partial'
                  ? 'আংশিক বকেয়া'
                  : 'সম্পূর্ণ বাকি'}
              </span>
              <div className="text-[11px] text-slate-500 mt-1">পদ্ধতি: {sale.payment_method || 'নগদ ক্যাশ'}</div>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">ক্রম</th>
                  <th className="py-2.5 px-3">গেঞ্জির বিবরণ ও স্পেসিফিকেশন</th>
                  <th className="py-2.5 px-3">সাইজ ও রঙ</th>
                  <th className="py-2.5 px-3 text-right">পরিমাণ (Pcs)</th>
                  <th className="py-2.5 px-3 text-right">দর (টাকা)</th>
                  <th className="py-2.5 px-3 text-right">মোট টাকা</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sale.items && sale.items.length > 0 ? (
                  sale.items.map((it: any, idx: number) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-slate-500">{idx + 1}</td>
                      <td className="py-2 px-3 font-semibold text-slate-800">{it.product_name}</td>
                      <td className="py-2 px-3 text-slate-600">
                        <span className="font-bold">{it.size}</span> • {it.color}
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-800">{it.quantity} পিস</td>
                      <td className="py-2 px-3 text-right font-mono text-slate-600">৳{it.unit_price}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                        {formatTk(it.total_price)}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-4 text-center text-slate-400">
                      কোনো আইটেম পাওয়া যায়নি
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Totals & Dues Calculation Block */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pt-2">
            <div className="text-[11px] text-slate-500 max-w-sm space-y-1">
              <p className="font-bold text-slate-700">শর্তাবলী ও নোটিশ:</p>
              <p>১. ডেলিভারির সময় কার্টুন বা বান্ডিল মিলিয়ে বুঝে নিন।</p>
              <p>২. কোনো প্রকার প্রস্তুত ত্রুটি থাকলে বিক্রির ৩ দিনের মধ্যে ফ্যাক্টরিতে পরিবর্তনযোগ্য।</p>
              <p>৩. কম্পিউটার জেনারেটেড আসল চালান।</p>
            </div>

            <div className="w-full sm:w-64 space-y-1.5 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <div className="flex justify-between text-slate-600">
                <span>মোট মূল্য (Gross):</span>
                <span className="font-mono font-semibold">{formatTk(sale.gross_amount)}</span>
              </div>
              {sale.discount_amount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>বিশেষ ছাড় (Discount):</span>
                  <span className="font-mono font-semibold">-{formatTk(sale.discount_amount)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-900 font-bold border-t border-slate-200 pt-1 text-sm">
                <span>সর্বমোট প্রদেয় (Net):</span>
                <span className="font-mono">{formatTk(sale.net_amount)}</span>
              </div>
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>জমা প্রদান (Paid):</span>
                <span className="font-mono">{formatTk(sale.paid_amount)}</span>
              </div>
              <div className="flex justify-between text-rose-700 font-bold border-t border-slate-200 pt-1">
                <span>বকেয়া পাওনা (Due):</span>
                <span className="font-mono">{formatTk(sale.due_amount)}</span>
              </div>
            </div>
          </div>

          {/* Dual Signature Lines */}
          <div className="pt-10 grid grid-cols-2 gap-8 text-center text-[11px] text-slate-500">
            <div>
              <div className="border-t border-slate-400 w-36 mx-auto mb-1" />
              ক্রেতার স্বাক্ষর ও সীলমোহর
            </div>
            <div>
              <div className="border-t border-slate-400 w-36 mx-auto mb-1" />
              টেক্স ওয়্যার অ্যাপারেলস পক্ষে অনুমোদিত
            </div>
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="flex justify-end gap-2.5 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl text-xs font-semibold cursor-pointer"
          >
            বন্ধ করুন
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>চালান প্রিন্ট করুন</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
