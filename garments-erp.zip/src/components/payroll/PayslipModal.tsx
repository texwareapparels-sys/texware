import React from 'react';
import { Printer, Shirt, CheckCircle2 } from 'lucide-react';
import { Modal } from '../common/Modal';
import { PayrollItem } from '../../types';
import { printHtml } from '../../utils/printDocument';

interface PayslipModalProps {
  item: PayrollItem | null;
  monthYear: string;
  isOpen: boolean;
  onClose: () => void;
}

export const PayslipModal: React.FC<PayslipModalProps> = ({ item, monthYear, isOpen, onClose }) => {
  if (!isOpen || !item) return null;

  const handlePrint = () => {
    const el = document.getElementById('printable-payslip');
    if (el) {
      printHtml(el.innerHTML, { title: `বেতন_স্লিপ_${item.employee_code}_${monthYear}` });
    } else {
      window.print();
    }
  };

  const formatTk = (n: number = 0) => '৳' + Math.round(n).toLocaleString('bn-BD');

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`বেতন স্লিপ (Payslip) - ${item.employee_name}`}
      subtitle={`মাস: ${monthYear} • পে-স্লিপ প্রিন্ট ও ভাউচার`}
      maxWidth="2xl"
    >
      <div id="printable-payslip" className="bg-white p-6 border border-slate-300 rounded-xl space-y-5 text-xs text-slate-800">
        {/* Company Header */}
        <div className="flex items-start justify-between border-b pb-4 border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold">
              <Shirt className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">টেক্স ওয়্যার অ্যাপারেলস</h2>
              <p className="text-[11px] text-slate-500">Texware Apparels • প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর</p>
              <p className="text-[11px] text-slate-400">ফোন: +880 1711-234567 • ইমেইল: info@texwareapparels.com</p>
            </div>
          </div>
          <div className="text-right">
            <span className="inline-block px-3 py-1 bg-slate-100 rounded-md font-bold text-xs uppercase tracking-wider text-slate-700">
              বেতন ভাউচার / স্লিপ
            </span>
            <p className="text-[11px] font-mono font-bold text-slate-700 mt-1">মাস: {monthYear}</p>
          </div>
        </div>

        {/* Employee Summary Card */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
          <div>
            <span className="text-[10px] text-slate-400 block">কর্মী আইডি:</span>
            <span className="font-mono font-bold text-slate-800">{item.employee_code}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block">পূর্ণ নাম:</span>
            <span className="font-bold text-slate-800">{item.employee_name}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block">বিভাগ ও পদবী:</span>
            <span className="font-medium text-slate-700">{item.department} • {item.designation}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block">বেতন পদ্ধতি:</span>
            <span className="font-medium text-slate-700 capitalize">{item.salary_type}</span>
          </div>
        </div>

        {/* Attendance Summary with Factory Late & Absence Rules */}
        <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200/80 space-y-2 text-xs text-emerald-950">
          <div className="flex items-center justify-between font-semibold flex-wrap gap-2">
            <span>উপস্থিতি: <strong>{item.present_days} দিন</strong></span>
            <span>লেট (দেরি): <strong>{item.late_days || 0} দিন</strong> {item.late_penalty_days ? <span className="text-rose-700 font-bold">(জরিমানা {item.late_penalty_days} দিন)</span> : ''}</span>
            <span>অনুপস্থিতি: <strong>{item.absent_days} দিন</strong> {item.absent_penalty_days ? <span className="text-rose-700 font-bold">(জরিমানা {item.absent_penalty_days} দিন)</span> : ''}</span>
            <span>ছুটি: <strong>{item.leave_days} দিন</strong></span>
            <span>ওভারটাইম: <strong>{item.ot_hours} ঘণ্টা</strong></span>
          </div>
          <div className="pt-2 border-t border-emerald-200/60 flex items-center justify-between text-[11px] text-slate-700 font-medium">
            <span>কারখানা নিয়মে মোট কর্তিত হাজিরা: <strong className="text-rose-700 font-bold">{(item.absent_days || 0) + (item.total_penalty_days || 0)} দিন</strong> (অনুপস্থিত {item.absent_days}দ + জরিমানা {item.total_penalty_days || 0}দ)</span>
            <span>বেতনযোগ্য কার্যকর দিন: <strong className="text-emerald-800 font-bold">{item.payable_days ?? Math.max(0, 26 - ((item.absent_days || 0) + (item.total_penalty_days || 0)))} দিন</strong></span>
          </div>
        </div>

        {/* Salary Calculation Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Earnings */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <div className="bg-slate-100 px-3 py-2 font-bold text-slate-700 text-xs flex justify-between">
              <span>মূল পাওনা (Earnings)</span>
              <span>টাকা</span>
            </div>
            <div className="p-3 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>মূল বেসিক বেতন:</span>
                <span className="font-mono font-medium">{formatTk(item.basic_salary)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>ওভারটাইম ভাতা ({item.ot_hours} ঘণ্টা):</span>
                <span className="font-mono font-medium">{formatTk(item.ot_amount)}</span>
              </div>
              {item.bonus_amount > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>উৎসব বোনাস / ইনসেন্টিভ:</span>
                  <span className="font-mono font-medium">{formatTk(item.bonus_amount)}</span>
                </div>
              )}
              {item.allowances > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>অন্যান্য ভাতা / অ্যালাউন্স:</span>
                  <span className="font-mono font-medium">{formatTk(item.allowances)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Deductions */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <div className="bg-slate-100 px-3 py-2 font-bold text-slate-700 text-xs flex justify-between">
              <span>কর্তনসমূহ (Deductions)</span>
              <span>টাকা</span>
            </div>
            <div className="p-3 space-y-2 text-xs">
              {(item.absent_days > 0 || (item.total_penalty_days && item.total_penalty_days > 0)) && (
                <div className="flex justify-between text-rose-700">
                  <span>হাজিরা ও জরিমানা কর্তন ({((item.absent_days || 0) + (item.total_penalty_days || 0))} দিন):</span>
                  <span className="font-mono font-bold">-{formatTk(item.attendance_deduction || item.other_deduction)}</span>
                </div>
              )}
              {item.advance_deduction > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>অগ্রিম কর্তন (Advance):</span>
                  <span className="font-mono font-medium text-rose-700">-{formatTk(item.advance_deduction)}</span>
                </div>
              )}
              {item.other_deduction > 0 && !item.attendance_deduction && (
                <div className="flex justify-between text-slate-600">
                  <span>অন্যান্য কর্তন (Other):</span>
                  <span className="font-mono font-medium text-rose-700">-{formatTk(item.other_deduction)}</span>
                </div>
              )}
              {item.notes && (
                <div className="pt-1.5 border-t border-slate-100 text-[10px] text-slate-500 leading-tight">
                  {item.notes}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Net Payable & Paid Amount */}
        <div className="p-4 bg-slate-900 text-white rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] text-emerald-300 block">মোট প্রদেয় বেতন (Net Payable)</span>
            <span className="text-xl font-bold font-mono">{formatTk(item.net_payable)}</span>
          </div>
          <div className="text-right">
            <span className="text-[11px] text-slate-400 block">পরিশোধিত অর্থ (Paid Amount)</span>
            <span className="text-xl font-bold font-mono text-emerald-400">{formatTk(item.paid_amount)}</span>
          </div>
        </div>

        {/* Payment Meta */}
        <div className="text-[11px] text-slate-500 flex justify-between items-center px-1">
          <span>পেমেন্ট মাধ্যম: <strong>{item.payment_method || 'Cash / নগদ'}</strong></span>
          <span>পেমেন্ট তারিখ: <strong>{item.payment_date || '—'}</strong></span>
          <span>পেমেন্ট রেফ: <strong>{item.payment_ref || 'নগদ ক্যাশ গ্রহণ'}</strong></span>
        </div>

        {/* Dual Signatures */}
        <div className="pt-10 grid grid-cols-2 gap-8 text-center text-[11px] text-slate-500">
          <div>
            <div className="border-t border-slate-400 w-36 mx-auto mb-1" />
            শ্রমিক / কর্মচারীর স্বাক্ষর
          </div>
          <div>
            <div className="border-t border-slate-400 w-36 mx-auto mb-1" />
            কর্তৃপক্ষের অনুমোদিত স্বাক্ষর
          </div>
        </div>
      </div>

      <div className="mt-4 flex justify-end gap-2.5">
        <button
          onClick={handlePrint}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
        >
          <Printer className="w-4 h-4" />
          <span>পে-স্লিপ প্রিন্ট করুন</span>
        </button>
      </div>
    </Modal>
  );
};
