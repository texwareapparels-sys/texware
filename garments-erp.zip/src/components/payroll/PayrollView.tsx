import React, { useState, useEffect } from 'react';
import {
  Banknote,
  Calculator,
  Printer,
  Download,
  CheckCircle2,
  Lock,
  Edit2,
  DollarSign,
  AlertCircle,
  FileText,
  Clock,
  Sparkles,
  Search,
  Filter,
  Trash2,
  ShieldAlert,
  Info
} from 'lucide-react';
import { api } from '../../services/api';
import { PayrollPeriod, PayrollItem } from '../../types';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { PayslipModal } from './PayslipModal';
import { printHtml } from '../../utils/printDocument';

export const PayrollView: React.FC = () => {
  const { showToast } = useToast();
  const [monthYear, setMonthYear] = useState<string>('2026-09');
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [currentPeriod, setCurrentPeriod] = useState<PayrollPeriod | null>(null);
  const [items, setItems] = useState<PayrollItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);

  // Modals
  const [selectedPayslipItem, setSelectedPayslipItem] = useState<PayrollItem | null>(null);
  const [isPayslipOpen, setIsPayslipOpen] = useState(false);
  const [isDeletePeriodModalOpen, setIsDeletePeriodModalOpen] = useState(false);
  const [deletingItem, setDeletingItem] = useState<PayrollItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Payment modal
  const [paymentItem, setPaymentItem] = useState<PayrollItem | null>(null);
  const [paymentForm, setPaymentForm] = useState({
    amount: 0,
    payment_method: 'Cash',
    payment_ref: '',
    notes: '',
  });

  // Adjustment modal
  const [adjustmentItem, setAdjustmentItem] = useState<PayrollItem | null>(null);
  const [adjustmentForm, setAdjustmentForm] = useState({
    bonus_amount: 0,
    allowances: 0,
    advance_deduction: 0,
    other_deduction: 0,
    notes: '',
  });

  const fetchPeriods = async () => {
    try {
      const data = await api.getPayrollPeriods();
      setPeriods(data);
      if (data.length > 0 && !currentPeriod) {
        loadPeriodDetail(data[0].id);
      }
    } catch (err: any) {
      console.error(err);
    }
  };

  const loadPeriodDetail = async (periodId: number) => {
    setLoading(true);
    try {
      const data = await api.getPayrollPeriodDetail(periodId);
      setCurrentPeriod(data.period);
      setItems(data.items);
      setMonthYear(data.period.month_year);
    } catch (err: any) {
      showToast(err.message || 'বেতন শিট লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPeriods();
  }, []);

  // Generate / Auto-calculate payroll
  const handleGeneratePayroll = async () => {
    setGenerating(true);
    try {
      const res = await api.generatePayroll(monthYear);
      showToast(res.message || 'বেতন ও ওভারটাইম অটো ক্যালকুলেশন সফল হয়েছে!', 'success');
      await fetchPeriods();
      await loadPeriodDetail(res.periodId);
    } catch (err: any) {
      showToast(err.message || 'বেতন জেনারেট করা সম্ভব হয়নি', 'error');
    } finally {
      setGenerating(false);
    }
  };

  // Status transition (Approve or Finalize)
  const handleUpdateStatus = async (newStatus: 'approved' | 'finalized') => {
    if (!currentPeriod) return;
    try {
      await api.updatePayrollStatus(currentPeriod.id, newStatus);
      showToast(`বেতন শিট সফলভাবে ${newStatus === 'finalized' ? 'লক ও চূড়ান্ত' : 'অনুমোদিত'} করা হয়েছে`, 'success');
      loadPeriodDetail(currentPeriod.id);
    } catch (err: any) {
      showToast(err.message || 'স্ট্যাটাস পরিবর্তন ব্যর্থ হয়েছে', 'error');
    }
  };

  // Open adjustment modal
  const handleOpenAdjustment = (item: PayrollItem) => {
    setAdjustmentItem(item);
    setAdjustmentForm({
      bonus_amount: item.bonus_amount,
      allowances: item.allowances,
      advance_deduction: item.advance_deduction,
      other_deduction: item.other_deduction,
      notes: item.notes || '',
    });
  };

  const handleSaveAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustmentItem) return;
    try {
      await api.updatePayrollItem(adjustmentItem.id, adjustmentForm);
      showToast('ভাতা ও কর্তন সমন্বয় সংরক্ষণ করা হয়েছে', 'success');
      setAdjustmentItem(null);
      if (currentPeriod) loadPeriodDetail(currentPeriod.id);
    } catch (err: any) {
      showToast(err.message || 'সমন্বয় ব্যর্থ হয়েছে', 'error');
    }
  };

  // Open payment modal
  const handleOpenPayment = (item: PayrollItem) => {
    setPaymentItem(item);
    setPaymentForm({
      amount: item.due_amount,
      payment_method: 'Cash',
      payment_ref: '',
      notes: '',
    });
  };

  const handleSavePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentItem) return;
    try {
      await api.paySalary(paymentItem.id, paymentForm);
      showToast('বেতন পরিশোধ রেকর্ড সংরক্ষণ করা হয়েছে', 'success');
      setPaymentItem(null);
      if (currentPeriod) loadPeriodDetail(currentPeriod.id);
    } catch (err: any) {
      showToast(err.message || 'পেমেন্ট ব্যর্থ হয়েছে', 'error');
    }
  };

  const formatTk = (n: number = 0) => '৳' + Math.round(n).toLocaleString('bn-BD');

  const handleExportCsv = () => {
    if (!items.length) return;
    const headers = [
      'কর্মী কোড',
      'নাম',
      'বিভাগ',
      'মূল বেতন',
      'উপস্থিতি',
      'অনুপস্থিতি',
      'ওভারটাইম ঘণ্টা',
      'ওভারটাইম টাকা',
      'বোনাস',
      'ভাতা',
      'অগ্রিম কর্তন',
      'অন্যান্য কর্তন',
      'মোট প্রদেয়',
      'পরিশোধিত',
      'বকেয়া',
      'অবস্থা',
    ];
    const rows = items.map((i) => [
      i.employee_code,
      i.employee_name,
      i.department,
      i.basic_salary,
      i.present_days,
      i.absent_days,
      i.ot_hours,
      i.ot_amount,
      i.bonus_amount,
      i.allowances,
      i.advance_deduction,
      i.other_deduction,
      i.net_payable,
      i.paid_amount,
      i.due_amount,
      i.payment_status,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers, ...rows].map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `payroll_${monthYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleConfirmDeleteItem = async () => {
    if (!deletingItem) return;
    setIsDeleting(true);
    try {
      await api.deletePayrollItem(deletingItem.id);
      showToast(`${deletingItem.employee_name} কে বেতন শিট থেকে মুছে ফেলা হয়েছে`, 'success');
      setDeletingItem(null);
      if (currentPeriod) {
        await loadPeriodDetail(currentPeriod.id);
      }
    } catch (err: any) {
      showToast(err.message || 'কর্মী মুছতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleConfirmDeletePeriod = async () => {
    if (!currentPeriod) return;
    setIsDeleting(true);
    try {
      await api.deletePayrollPeriod(currentPeriod.id);
      showToast(`${monthYear} মাসের বেতন শিট সফলভাবে মুছে ফেলা হয়েছে`, 'success');
      setIsDeletePeriodModalOpen(false);
      setCurrentPeriod(null);
      setItems([]);
      const updatedPeriods = await api.getPayrollPeriods();
      setPeriods(updatedPeriods);
      if (updatedPeriods.length > 0) {
        await loadPeriodDetail(updatedPeriods[0].id);
      }
    } catch (err: any) {
      showToast(err.message || 'বেতন শিট মুছতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handlePrintPayrollSheet = () => {
    if (!items.length) {
      showToast('প্রিন্ট করার মতো কোনো কর্মীর বেতন ডাটা নেই', 'error');
      return;
    }

    const totalBasic = items.reduce((sum, i) => sum + (i.basic_salary || 0), 0);
    const totalOT = items.reduce((sum, i) => sum + (i.ot_amount || 0), 0);
    const totalNet = items.reduce((sum, i) => sum + (i.net_payable || 0), 0);
    const totalPaid = items.reduce((sum, i) => sum + (i.paid_amount || 0), 0);
    const totalDue = items.reduce((sum, i) => sum + (i.due_amount || 0), 0);

    const rowsHtml = items
      .map(
        (i, idx) => {
          const totalCutDays = (i.absent_days || 0) + (i.total_penalty_days || 0);
          return `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 6px 8px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px 8px; font-weight: bold; font-family: monospace;">${i.employee_code}</td>
          <td style="padding: 6px 8px; font-weight: 600;">${i.employee_name}</td>
          <td style="padding: 6px 8px;">${i.department}</td>
          <td style="padding: 6px 8px; text-align: right;">${formatTk(i.basic_salary)}</td>
          <td style="padding: 6px 8px; text-align: center;">${i.present_days}দ</td>
          <td style="padding: 6px 8px; text-align: center;">${i.absent_days}দ ${i.absent_penalty_days ? `(+${i.absent_penalty_days})` : ''}</td>
          <td style="padding: 6px 8px; text-align: center;">${i.late_days || 0}দ ${i.late_penalty_days ? `(+${i.late_penalty_days})` : ''}</td>
          <td style="padding: 6px 8px; text-align: center; font-weight: bold; color: #b91c1c;">${totalCutDays} দিন</td>
          <td style="padding: 6px 8px; text-align: right; color: #b91c1c;">-${formatTk(i.attendance_deduction || i.other_deduction)}</td>
          <td style="padding: 6px 8px; text-align: right;">${formatTk(i.ot_amount)}</td>
          <td style="padding: 6px 8px; text-align: right; font-weight: bold; color: #1e293b;">${formatTk(i.net_payable)}</td>
          <td style="padding: 6px 8px; text-align: right; color: #047857;">${formatTk(i.paid_amount)}</td>
          <td style="padding: 6px 8px; text-align: right; font-weight: bold; color: #b91c1c;">${formatTk(i.due_amount)}</td>
          <td style="padding: 6px 8px; text-align: center;">
            <span style="display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: bold; background-color: ${
              i.payment_status === 'paid' ? '#d1fae5; color: #065f46;' : i.payment_status === 'partial' ? '#fef3c7; color: #92400e;' : '#fee2e2; color: #991b1b;'
            }">
              ${i.payment_status === 'paid' ? 'পরিশোধিত' : i.payment_status === 'partial' ? 'আংশিক' : 'বকেয়া'}
            </span>
          </td>
        </tr>
      `;
        }
      )
      .join('');

    const htmlContent = `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 15px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 12px;">
          <div>
            <h1 style="font-size: 20px; font-weight: bold; margin: 0; color: #0f172a;">মেসার্স টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p style="font-size: 12px; margin: 2px 0 0 0; color: #64748b;">প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর • ফোন: ০১৭১১-২৩৪৫৬৭</p>
            <p style="font-size: 13px; font-weight: bold; margin-top: 4px; color: #047857;">মাসিক বেতন ও ওভারটাইম শিট (Payroll Sheet)</p>
            <p style="font-size: 11px; margin-top: 2px; color: #475569; font-weight: 500;">
              কারখানা হাজিরা বিধি: ৩ দিন লেট = ১ দিন কর্তন | ৩ দিন অনুপস্থিত = ৩ দিন + ১ দিন অতিরিক্ত জরিমানা (মোট ৪ দিন কর্তন)
            </p>
          </div>
          <div style="text-align: right;">
            <div style="display: inline-block; background-color: #f1f5f9; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold;">
              মাস: ${monthYear}
            </div>
            <div style="font-size: 11px; color: #64748b; margin-top: 4px;">প্রিন্ট তারিখ: ${new Date().toLocaleDateString('bn-BD')}</div>
            <div style="font-size: 11px; color: #64748b;">অবস্থা: ${currentPeriod?.status === 'finalized' ? 'চূড়ান্ত লকড' : 'অনুমোদিত / খসড়া'}</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #cbd5e1; font-size: 11px; text-align: left;">
              <th style="padding: 7px 8px; text-align: center;">#</th>
              <th style="padding: 7px 8px;">আইডি</th>
              <th style="padding: 7px 8px;">নাম</th>
              <th style="padding: 7px 8px;">বিভাগ</th>
              <th style="padding: 7px 8px; text-align: right;">মূল বেতন</th>
              <th style="padding: 7px 8px; text-align: center;">উপস্থিত</th>
              <th style="padding: 7px 8px; text-align: center;">অনুপস্থিত</th>
              <th style="padding: 7px 8px; text-align: center;">লেট</th>
              <th style="padding: 7px 8px; text-align: center; color: #b91c1c;">মোট কর্তন দিন</th>
              <th style="padding: 7px 8px; text-align: right; color: #b91c1c;">হাজিরা কর্তন</th>
              <th style="padding: 7px 8px; text-align: right;">ওটি টাকা</th>
              <th style="padding: 7px 8px; text-align: right;">মোট প্রদেয়</th>
              <th style="padding: 7px 8px; text-align: right;">পরিশোধ</th>
              <th style="padding: 7px 8px; text-align: right;">বকেয়া</th>
              <th style="padding: 7px 8px; text-align: center;">স্ট্যাটাস</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
            <tr style="background-color: #f1f5f9; font-weight: bold; border-top: 2px solid #94a3b8; font-size: 11px;">
              <td colspan="4" style="padding: 8px; text-align: right;">সর্বমোট: (${items.length} জন)</td>
              <td style="padding: 8px; text-align: right;">${formatTk(totalBasic)}</td>
              <td colspan="5"></td>
              <td style="padding: 8px; text-align: right;">${formatTk(totalOT)}</td>
              <td style="padding: 8px; text-align: right; color: #0f172a;">${formatTk(totalNet)}</td>
              <td style="padding: 8px; text-align: right; color: #047857;">${formatTk(totalPaid)}</td>
              <td style="padding: 8px; text-align: right; color: #b91c1c;">${formatTk(totalDue)}</td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; margin-top: 50px; padding-top: 15px; font-size: 11px;">
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">প্রস্তুতকারকের স্বাক্ষর</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">অ্যাকাউন্ট্যান্ট স্বাক্ষর</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">এইচআর ম্যানেজার</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">ব্যবস্থাপনা পরিচালক</div>
        </div>
      </div>
    `;

    printHtml(htmlContent, { title: `বেতন_শিট_${monthYear}` });
  };

  return (
    <div className="space-y-5 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-100 text-indigo-800">
              <Banknote className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              মাসিক বেতন ও ওভারটাইম শিট
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            হাজিরা থেকে অটোমেটিক বেতন ক্যালকুলেশন, বোনাস, অগ্রিম কর্তন ও পে-স্লিপ প্রিন্ট
          </p>
        </div>

        {/* Month Selector & Auto Calculate Action */}
        <div className="flex items-center gap-2 flex-wrap">
          <input
            type="month"
            value={monthYear}
            onChange={(e) => setMonthYear(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
          />

          <button
            id="calculate-payroll-btn"
            onClick={handleGeneratePayroll}
            disabled={generating}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs shadow-emerald-600/20 disabled:opacity-60 transition-colors"
          >
            <Calculator className="w-4 h-4" />
            <span>{generating ? 'হিসাব হচ্ছে...' : 'অটো ক্যালকুলেশন করুন'}</span>
          </button>
        </div>
      </div>

      {/* Period Summary & Status Controls */}
      {currentPeriod && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-3">
              <span className="text-sm font-bold text-slate-800">
                মাস: <span className="font-mono text-emerald-800">{currentPeriod.month_year}</span>
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                  currentPeriod.status === 'finalized'
                    ? 'bg-slate-900 text-white'
                    : currentPeriod.status === 'approved'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {currentPeriod.status === 'finalized' ? '🔒 চূড়ান্ত লকড' : currentPeriod.status === 'approved' ? 'অনুমোদিত' : 'খসড়া (Draft)'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {currentPeriod.status === 'draft' && (
                <button
                  onClick={() => handleUpdateStatus('approved')}
                  className="px-3 py-1.5 bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 rounded-lg text-xs font-bold cursor-pointer transition-colors"
                >
                  অনুমোদন করুন
                </button>
              )}
              {currentPeriod.status !== 'finalized' && (
                <button
                  onClick={() => handleUpdateStatus('finalized')}
                  className="px-3 py-1.5 bg-slate-800 text-white hover:bg-slate-900 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>লক ও ফাইনাল করুন</span>
                </button>
              )}

              <button
                onClick={handlePrintPayrollSheet}
                className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>শিট প্রিন্ট</span>
              </button>

              <button
                onClick={handleExportCsv}
                className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>CSV</span>
              </button>

              <button
                onClick={() => setIsDeletePeriodModalOpen(true)}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                title="এই মাসের সম্পূর্ণ বেতন শিট মুছুন"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>শীট মুছুন</span>
              </button>
            </div>
          </div>

          {/* KPI Counters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-500 block">মোট কর্মী সংখ্যা</span>
              <span className="text-lg font-bold text-slate-800">{items.length} জন</span>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-500 block">মোট প্রদেয় বেতন</span>
              <span className="text-lg font-bold text-slate-900 font-mono">{formatTk(currentPeriod.total_payable)}</span>
            </div>
            <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-100">
              <span className="text-emerald-700 block font-medium">পরিশোধিত অর্থ</span>
              <span className="text-lg font-bold text-emerald-800 font-mono">{formatTk(currentPeriod.total_paid)}</span>
            </div>
            <div className="bg-rose-50/70 p-3 rounded-xl border border-rose-100">
              <span className="text-rose-700 block font-medium">বকেয়া অর্থ</span>
              <span className="text-lg font-bold text-rose-800 font-mono">{formatTk(currentPeriod.total_due)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Factory Attendance & Penalty Rules Banner */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-slate-50 border border-emerald-200/90 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-emerald-950 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0 shadow-xs">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <span>কারখানা স্বয়ংক্রিয় হাজিরা ও জরিমানা হিসাব বিধি</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">অটো-হিসাব সক্রিয়</span>
            </h4>
            <p className="text-slate-600 mt-0.5 text-xs">
              • <strong>৩ দিন লেট</strong> = ১ দিনের হাজিরা কাটা | • <strong>৩ দিন না বলে অনুপস্থিত</strong> = মূল ৩ দিন + অতিরিক্ত ১ দিন জরিমানা (মোট ৪ দিনের হাজিরা কাটা)।
            </p>
          </div>
        </div>
        <div className="text-[11px] font-medium text-emerald-800 bg-white/90 px-3 py-1.5 rounded-xl border border-emerald-200/80 shadow-2xs shrink-0">
          ২৬ কর্মদিবস ভিত্তিক নিখুঁত হিসাব
        </div>
      </div>

      {/* Payroll Items Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
              <tr>
                <th className="py-3.5 px-4">কর্মী বিবরণ</th>
                <th className="py-3.5 px-4">মূল বেতন</th>
                <th className="py-3.5 px-4 text-center">হাজিরা ও লেট</th>
                <th className="py-3.5 px-4 text-center">কর্তন দিন (জরিমানাসহ)</th>
                <th className="py-3.5 px-4 text-center">ওভারটাইম</th>
                <th className="py-3.5 px-4 text-right">বোনাস/ভাতা</th>
                <th className="py-3.5 px-4 text-right">হাজিরা/অগ্রিম কর্তন</th>
                <th className="py-3.5 px-4 text-right">নিট প্রদেয়</th>
                <th className="py-3.5 px-4 text-right">পরিশোধিত</th>
                <th className="py-3.5 px-4 text-center">অবস্থা</th>
                <th className="py-3.5 px-4 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-400">
                    <div className="w-8 h-8 border-2 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto mb-2" />
                    বেতন বিবরণী লোড হচ্ছে...
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-400">
                    এই মাসের জন্য বেতন হিসাব তৈরি করা হয়নি। উপরে "অটো ক্যালকুলেশন করুন" বাটনে ক্লিক করুন।
                  </td>
                </tr>
              ) : (
                items.map((item) => {
                  const totalCutDays = (item.absent_days || 0) + (item.total_penalty_days || 0);
                  return (
                  <tr key={item.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-800">{item.employee_name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {item.employee_code} • {item.department}
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono font-medium text-slate-700">
                      {formatTk(item.basic_salary)}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <div className="text-slate-800 font-bold">{item.present_days} দিন উপস্থিত</div>
                      <div className="text-[11px] text-slate-500 font-medium mt-0.5">
                        লেট: <strong className={item.late_days ? 'text-amber-700' : 'text-slate-600'}>{item.late_days || 0} দিন</strong>
                        {item.leave_days ? ` | ছুটি: ${item.leave_days} দিন` : ''}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <div className={`font-bold font-mono ${totalCutDays > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
                        {totalCutDays > 0 ? `${totalCutDays} দিন কর্তন` : '০ দিন কর্তন'}
                      </div>
                      <div className="text-[10px] text-slate-500" title={item.notes}>
                        {item.absent_days > 0 ? `অনু: ${item.absent_days}দ ${item.absent_penalty_days ? `(+জরিমানা ${item.absent_penalty_days}দ)` : ''}` : 'অনু: ০দ'}
                        {item.late_penalty_days ? ` | লেট জরি: ${item.late_penalty_days}দ` : ''}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <div className="font-bold text-slate-800">{formatTk(item.ot_amount)}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{item.ot_hours} ঘণ্টা</div>
                    </td>

                    <td className="py-3 px-4 text-right font-mono text-emerald-700">
                      +{formatTk((item.bonus_amount || 0) + (item.allowances || 0))}
                    </td>

                    <td className="py-3 px-4 text-right font-mono text-rose-600">
                      <div className="font-bold">-{formatTk((item.advance_deduction || 0) + (item.other_deduction || 0))}</div>
                      {totalCutDays > 0 && (
                        <div className="text-[10px] text-rose-500 font-sans">
                          (হাজিরা কর্তন: {formatTk(item.attendance_deduction || item.other_deduction)})
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right font-bold font-mono text-slate-900 text-sm">
                      {formatTk(item.net_payable)}
                    </td>

                    <td className="py-3 px-4 text-right font-bold font-mono text-emerald-600">
                      {formatTk(item.paid_amount)}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.payment_status === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.payment_status === 'partial'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {item.payment_status === 'paid' ? 'পরিশোধিত' : item.payment_status === 'partial' ? 'আংশিক' : 'বকেয়া'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setSelectedPayslipItem(item);
                            setIsPayslipOpen(true);
                          }}
                          className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded cursor-pointer"
                          title="পে-স্লিপ প্রিন্ট"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenAdjustment(item)}
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded cursor-pointer"
                          title="বোনাস/কর্তন সমন্বয়"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {item.payment_status !== 'paid' && (
                          <button
                            onClick={() => handleOpenPayment(item)}
                            className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold cursor-pointer"
                          >
                            পেমেন্ট
                          </button>
                        )}
                        {currentPeriod?.status !== 'finalized' && (
                          <button
                            onClick={() => setDeletingItem(item)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded cursor-pointer transition-colors"
                            title="বেতন শিট থেকে এই কর্মীকে বাদ দিন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payslip Modal */}
      <PayslipModal
        item={selectedPayslipItem}
        monthYear={monthYear}
        isOpen={isPayslipOpen}
        onClose={() => setIsPayslipOpen(false)}
      />

      {/* Salary Payment Modal */}
      {paymentItem && (
        <Modal
          isOpen={Boolean(paymentItem)}
          onClose={() => setPaymentItem(null)}
          title={`বেতন প্রদান - ${paymentItem.employee_name}`}
          subtitle={`বকেয়া বেতন: ${formatTk(paymentItem.due_amount)}`}
          maxWidth="md"
        >
          <form onSubmit={handleSavePayment} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">পরিশোধের পরিমাণ (টাকা)</label>
              <input
                type="number"
                max={paymentItem.due_amount}
                min={1}
                value={paymentForm.amount}
                onChange={(e) => setPaymentForm({ ...paymentForm, amount: Number(e.target.value) })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
              <select
                value={paymentForm.payment_method}
                onChange={(e) => setPaymentForm({ ...paymentForm, payment_method: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
              >
                <option value="Cash">ক্যাশ (Cash / নগদ)</option>
                <option value="bKash">বিকাশ (bKash)</option>
                <option value="Nagad">নগদ (Nagad)</option>
                <option value="Bank">ব্যাংক ট্রান্সফার (Bank Transfer)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">ট্রানজেকশন রেফ / ভাউচার নং</label>
              <input
                type="text"
                value={paymentForm.payment_ref}
                onChange={(e) => setPaymentForm({ ...paymentForm, payment_ref: e.target.value })}
                placeholder="যেমন: TrxID: 9X87KLM বা ক্যাশ মেমো নং"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setPaymentItem(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs"
              >
                পেমেন্ট নিশ্চিত করুন
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Salary Adjustment Modal */}
      {adjustmentItem && (
        <Modal
          isOpen={Boolean(adjustmentItem)}
          onClose={() => setAdjustmentItem(null)}
          title={`ভাতা ও কর্তন সমন্বয় - ${adjustmentItem.employee_name}`}
          subtitle="বোনাস, অগ্রিম কর্তন ও বিশেষ এলাউন্স পরিবর্তন"
          maxWidth="md"
        >
          <form onSubmit={handleSaveAdjustment} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">উৎসব / পারফরম্যান্স বোনাস</label>
                <input
                  type="number"
                  min={0}
                  value={adjustmentForm.bonus_amount}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, bonus_amount: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">অন্যান্য ভাতা (Allowances)</label>
                <input
                  type="number"
                  min={0}
                  value={adjustmentForm.allowances}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, allowances: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">অগ্রিম বেতন কর্তন (Advance)</label>
                <input
                  type="number"
                  min={0}
                  value={adjustmentForm.advance_deduction}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, advance_deduction: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">অন্যান্য জরিমানা / কর্তন</label>
                <input
                  type="number"
                  min={0}
                  value={adjustmentForm.other_deduction}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, other_deduction: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">সমন্বয়ের কারণ / নোট</label>
              <input
                type="text"
                value={adjustmentForm.notes}
                onChange={(e) => setAdjustmentForm({ ...adjustmentForm, notes: e.target.value })}
                placeholder="যেমন: ঈদ বোনাস যোগ এবং গত সপ্তাহের অগ্রিম কর্তন"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setAdjustmentItem(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs"
              >
                সমন্বয় সংরক্ষণ করুন
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete Entire Payroll Period Modal */}
      {isDeletePeriodModalOpen && currentPeriod && (
        <Modal
          isOpen={isDeletePeriodModalOpen}
          onClose={() => !isDeleting && setIsDeletePeriodModalOpen(false)}
          title={`${monthYear} মাসের বেতন শিট মুছুন`}
          subtitle="সম্পূর্ণ বেতন শিট ডিলিট নিশ্চিতকরণ"
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 space-y-1">
              <p className="font-bold flex items-center gap-1.5 text-rose-900 text-sm">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                সতর্কবার্তা: এই কাজটি অপরিবর্তনযোগ্য
              </p>
              <p>
                আপনি কি নিশ্চিত যে সম্পূর্ণ <strong>{monthYear}</strong> মাসের বেতন শিট মুছে ফেলতে চান? এতে এই মাসের সংরক্ষিত সকল কর্মীর ({items.length} জন) বেতন, ওভারটাইম এবং হিসাবের ডাটা সম্পূর্ণ মুছে যাবে।
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setIsDeletePeriodModalOpen(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-medium cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDeletePeriod}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, সম্পূর্ণ শিট মুছুন'}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete Single Worker Item Modal */}
      {deletingItem && (
        <Modal
          isOpen={Boolean(deletingItem)}
          onClose={() => !isDeleting && setDeletingItem(null)}
          title="কর্মী বেতন রেকর্ড বাদ দিন"
          subtitle={`${deletingItem.employee_name} (${deletingItem.employee_code})`}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <p className="text-slate-600 leading-relaxed">
              আপনি কি নিশ্চিত যে <strong>{deletingItem.employee_name}</strong> (আইডি: {deletingItem.employee_code}) কে {monthYear} মাসের বেতন শিট থেকে মুছে ফেলতে চান?
            </p>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setDeletingItem(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-medium cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDeleteItem}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeleting ? 'মুছছে...' : 'হ্যাঁ, কর্মী রেকর্ড মুছুন'}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
