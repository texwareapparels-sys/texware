import React, { useState, useEffect, useCallback } from 'react';
import {
  Contact,
  Printer,
  Search,
  Filter,
  CheckSquare,
  Square,
  QrCode,
  Shirt,
  ShieldCheck,
  Building,
  User,
  RefreshCw,
  Plus,
  Phone,
  Droplet,
  MapPin,
  Calendar,
  Layers,
  Sparkles,
  Award,
  CreditCard,
  FileCheck,
  Trash2,
  Scan
} from 'lucide-react';
import QRCode from 'qrcode';
import { Employee, CompanySettings } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { printElementById } from '../../utils/printDocument';

const DEPARTMENTS = [
  'সব বিভাগ',
  'কাটিং (Cutting)',
  'সুইং (Sewing)',
  'ফিনিশিং (Finishing)',
  'কোয়ালিটি কন্ট্রোল (QC)',
  'আয়রনিং (Ironing)',
  'প্যাকেজিং (Packaging)'
];

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

export const IdCardView: React.FC = () => {
  const { showToast } = useToast();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [selectedDept, setSelectedDept] = useState<string>('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [companySettings, setCompanySettings] = useState<CompanySettings | null>(null);
  const [cardSide, setCardSide] = useState<'front' | 'back' | 'both'>('front');
  const [qrCodeMap, setQrCodeMap] = useState<Record<number, string>>({});
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [submittingWorker, setSubmittingWorker] = useState(false);
  const [scannedWorker, setScannedWorker] = useState<Employee | null>(null);

  // New worker quick-form state
  const [formData, setFormData] = useState({
    employee_code: '',
    full_name: '',
    guardian_name: '',
    mobile: '',
    nid: '',
    blood_group: 'B+',
    joining_date: new Date().toISOString().split('T')[0],
    department: 'সুইং (Sewing)',
    designation: 'সিনিয়র সুইং অপারেটর',
    employee_type: 'worker',
    address: 'কোনাবাড়ী শিল্প এলাকা, গাজীপুর',
    emergency_contact: '',
    basic_salary: 16000,
    overtime_rate: 153.85,
    status: 'active',
    photo_url: ''
  });

  // Fetch company settings
  const fetchSettings = useCallback(async () => {
    try {
      const res = await api.getSettings();
      setCompanySettings(res);
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
  }, []);

  // Fetch real-time employees from database
  const fetchEmployees = useCallback(async (showSyncToast = false) => {
    try {
      if (showSyncToast) setSyncing(true);
      else setLoading(true);

      const data = await api.getEmployees({
        department: selectedDept && selectedDept !== 'সব বিভাগ' ? selectedDept : undefined,
        status: selectedStatus !== 'all' ? selectedStatus : undefined,
        employee_type: selectedType !== 'all' ? selectedType : undefined,
        search: searchTerm.trim() || undefined
      });

      const list = Array.isArray(data) ? data : [];
      setEmployees(list);

      // Default select all loaded employees if none previously selected or if selecting all
      setSelectedIds((prev) => {
        if (prev.length === 0) return list.map((e) => e.id);
        const currentIds = new Set(list.map((e) => e.id));
        const filtered = prev.filter((id) => currentIds.has(id));
        return filtered.length > 0 ? filtered : list.map((e) => e.id);
      });

      // Generate real-time scannable QR codes for each worker
      const qrMap: Record<number, string> = {};
      for (const emp of list) {
        try {
          const qrPayload = JSON.stringify({
            id: emp.employee_code,
            name: emp.full_name,
            dept: emp.department,
            desig: emp.designation,
            phone: emp.mobile,
            factory: companySettings?.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস'
          });
          qrMap[emp.id] = await QRCode.toDataURL(qrPayload, {
            margin: 1,
            width: 140,
            color: { dark: '#064e3b', light: '#ffffff' }
          });
        } catch {
          // fallback ignore
        }
      }
      setQrCodeMap(qrMap);

      if (showSyncToast) {
        showToast(`ডাটাবেজ থেকে মোট ${list.length} জন কর্মীর রিয়েল-টাইম তথ্য সিঙ্ক হয়েছে`, 'success');
      }
    } catch (err: any) {
      showToast(err.message || 'কর্মী তালিকা লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  }, [selectedDept, selectedStatus, selectedType, searchTerm, companySettings, showToast]);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  useEffect(() => {
    fetchEmployees();
  }, [fetchEmployees]);

  // Window focus listener for real-time synchronization
  useEffect(() => {
    const onFocus = () => {
      fetchEmployees();
    };
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [fetchEmployees]);

  const toggleSelect = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    setSelectedIds(employees.map((e) => e.id));
  };

  const deselectAll = () => {
    setSelectedIds([]);
  };

  const handlePrint = () => {
    printElementById('id-cards-container', 'কারখানা_কর্মী_পরিচয়পত্র_প্রিন্ট');
  };

  const handleDeleteCard = async (emp: Employee) => {
    if (!window.confirm(`আপনি কি নিশ্চিত যে ${emp.full_name} (${emp.employee_code})-এর পরিচয়পত্র ও সমস্ত রেকর্ড সম্পূর্ণ মুছে ফেলতে চান?`)) {
      return;
    }
    try {
      setSyncing(true);
      const res = await api.deleteEmployee(emp.id);
      showToast(res.message || 'আইডি কার্ড সফলভাবে মুছে ফেলা হয়েছে', 'success');
      await fetchEmployees(false);
    } catch (err: any) {
      showToast(err.message || 'আইডি কার্ড মুছে ফেলা যায়নি', 'error');
    } finally {
      setSyncing(false);
    }
  };

  const handleCreateWorker = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.full_name || !formData.mobile || !formData.department || !formData.designation) {
      showToast('নাম, মোবাইল নম্বর, বিভাগ ও পদবী পূরণ করুন', 'error');
      return;
    }

    try {
      setSubmittingWorker(true);
      const res = await api.createEmployee({
        ...formData,
        emergency_contact: formData.emergency_contact || formData.mobile
      });
      showToast(`নতুন কর্মী সফলভাবে ডাটাবেজে সংরক্ষিত হয়েছে (আইডি: ${res.employee_code})`, 'success');
      setIsAddModalOpen(false);
      // Reset form
      setFormData({
        employee_code: '',
        full_name: '',
        guardian_name: '',
        mobile: '',
        nid: '',
        blood_group: 'B+',
        joining_date: new Date().toISOString().split('T')[0],
        department: 'সুইং (Sewing)',
        designation: 'সিনিয়র সুইং অপারেটর',
        employee_type: 'worker',
        address: 'কোনাবাড়ী শিল্প এলাকা, গাজীপুর',
        emergency_contact: '',
        basic_salary: 16000,
        overtime_rate: 153.85,
        status: 'active',
        photo_url: ''
      });
      await fetchEmployees(false);
    } catch (err: any) {
      showToast(err.message || 'কর্মী সংরক্ষণ করা যায়নি', 'error');
    } finally {
      setSubmittingWorker(false);
    }
  };

  const selectedEmployees = employees.filter((e) => selectedIds.includes(e.id));

  // Helper for expiry date calculation (valid for 3 years)
  const getExpiryDate = (joiningDate?: string) => {
    if (!joiningDate) return '৩১-১২-২০২৬';
    try {
      const parts = joiningDate.split('-');
      if (parts.length === 3) {
        const year = parseInt(parts[0], 10) + 3;
        return `৩১-১২-${year}`;
      }
    } catch {
      // fallback
    }
    return '৩১-১২-২০২৬';
  };

  return (
    <div className="space-y-5 pb-16">
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-teal-600 text-white shadow-xs">
              <Contact className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-slate-800 tracking-tight">
                  কর্মী পরিচয়পত্র স্টুডিও (Employee ID Card Generator)
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold">
                  রিয়েল-টাইম ডাটাবেজ
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {companySettings?.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস'} • কারখানা শ্রমিক ও কর্মকর্তাদের অফিসিয়াল ডিজিটাল আইডি কার্ড ও ব্যাচ প্রিন্ট
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          {/* Live Sync button */}
          <button
            onClick={() => fetchEmployees(true)}
            disabled={syncing || loading}
            title="ডাটাবেজ থেকে রিয়েল-টাইম ডাটা পুনরায় লোড করুন"
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-slate-600 ${syncing ? 'animate-spin' : ''}`} />
            <span>{syncing ? 'সিঙ্ক...' : 'লাইভ সিঙ্ক'}</span>
          </button>

          {/* Quick Add Worker button */}
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>নতুন কর্মী</span>
          </button>

          {/* Print Cards button */}
          <button
            onClick={handlePrint}
            disabled={selectedEmployees.length === 0}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs shadow-emerald-600/20 disabled:opacity-50 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>কার্ড প্রিন্ট ({selectedEmployees.length})</span>
          </button>
        </div>
      </div>

      {/* Filter and Selection Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 flex-wrap flex-1">
            {/* Search Input */}
            <div className="relative min-w-[220px] flex-1 max-w-sm">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="নাম, আইডি, মোবাইল বা NID দিয়ে খুঁজুন..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-xs"
              />
            </div>

            {/* Department Filter */}
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700"
            >
              {DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept === 'সব বিভাগ' ? '' : dept}>
                  {dept}
                </option>
              ))}
            </select>

            {/* Category / Employee Type Filter */}
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700"
            >
              <option value="all">সকল ধরন (শ্রমিক ও কর্মকর্তা)</option>
              <option value="worker">শুধুমাত্র কারখানা শ্রমিক (Worker)</option>
              <option value="staff">অফিস স্টাফ ও কর্মকর্তা (Staff)</option>
              <option value="supervisor">ফ্লোর সুপারভাইজার (Supervisor)</option>
            </select>

            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700"
            >
              <option value="all">সকল কর্মী (সক্রিয় ও অন্যান্য)</option>
              <option value="active">শুধুমাত্র সক্রিয় (Active)</option>
              <option value="inactive">নিষ্ক্রিয় (Inactive)</option>
            </select>
          </div>

          {/* View Mode Toggle: Front, Back, Both */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setCardSide('front')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                cardSide === 'front' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              সম্মুখ ভাগ (Front)
            </button>
            <button
              onClick={() => setCardSide('both')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                cardSide === 'both' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              উভয় পাশ (Dual Side)
            </button>
            <button
              onClick={() => setCardSide('back')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                cardSide === 'back' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              পিছনের পাতা (Back)
            </button>
          </div>
        </div>

        {/* Action row: Select All / Deselect / Counter */}
        <div className="flex items-center justify-between border-t border-slate-100 pt-2.5 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={selectAll}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium cursor-pointer flex items-center gap-1"
            >
              <CheckSquare className="w-3.5 h-3.5 text-slate-500" />
              <span>সব নির্বাচন ({employees.length})</span>
            </button>
            <button
              onClick={deselectAll}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium cursor-pointer flex items-center gap-1"
            >
              <Square className="w-3.5 h-3.5 text-slate-400" />
              <span>নির্বাচন বাতিল</span>
            </button>
            <span className="text-slate-500 ml-2 font-medium">
              নির্বাচিত: <strong className="text-slate-800">{selectedEmployees.length}</strong> / {employees.length} জন
            </span>
          </div>

          <div className="flex items-center gap-3 text-slate-500 text-[11px]">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              বিইপিজেএ ও শ্রম আইন মানদণ্ড অনুযায়ী প্রস্তুত
            </span>
            <span className="flex items-center gap-1">
              <QrCode className="w-3.5 h-3.5 text-teal-600" />
              ডিজিটাল কিউআর কোড সংযুক্ত
            </span>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {loading ? (
        <div className="bg-white rounded-2xl p-16 text-center text-slate-400 border border-slate-200/80 shadow-xs">
          <div className="w-10 h-10 border-3 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto mb-3" />
          <p className="font-semibold text-slate-700">ডাটাবেজ থেকে কর্মীদের রিয়েল-টাইম তথ্য লোড হচ্ছে...</p>
          <p className="text-xs text-slate-400 mt-1">কার্ড ও ডিজিটাল স্ক্যান কোড প্রস্তুত করা হচ্ছে</p>
        </div>
      ) : employees.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs max-w-xl mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4 border border-emerald-100">
            <Contact className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">
            ডাটাবেজে কোনো কর্মীর তথ্য পাওয়া যায়নি
          </h3>
          <p className="text-xs text-slate-500 mt-2 max-w-md mx-auto leading-relaxed">
            ডাটাবেজে বর্তমানে কোনো শ্রমিক বা কর্মচারীর রেকর্ড নেই। নতুন কর্মী নিবন্ধন করে পরিচয়পত্র প্রিন্ট ও ডিজিটাল ব্যাজ তৈরি করতে পারেন।
          </p>
          <div className="mt-6 flex items-center justify-center gap-3 flex-wrap">
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-2 shadow-sm shadow-emerald-600/20"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন কর্মী যুক্ত করুন</span>
            </button>
          </div>
        </div>
      ) : selectedEmployees.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs max-w-md mx-auto">
          <p className="text-sm text-slate-700 font-semibold mb-3">
            প্রিন্ট বা প্রিভিউ করার জন্য কর্মী কার্ড নির্বাচন করুন
          </p>
          <button
            onClick={selectAll}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shadow-xs shadow-emerald-600/20"
          >
            সকল কর্মীর কার্ড নির্বাচন করুন ({employees.length})
          </button>
        </div>
      ) : (
        /* Printable Grid Container */
        <div
          id="id-cards-container"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6"
        >
          {selectedEmployees.map((emp) => {
            const isSelected = selectedIds.includes(emp.id);
            const qrDataUrl = qrCodeMap[emp.id];
            const issueDate = emp.joining_date || '২০২৩-০১-১৫';
            const expiryDate = getExpiryDate(emp.joining_date);
            const bloodGroup = emp.blood_group || (emp.gender === 'Female' ? 'A(+ve)' : 'B(+ve)');
            const guardianText = emp.guardian_name || (emp.gender === 'Female' ? 'মোঃ আব্দুর রহমান (স্বামী)' : 'মোঃ জহিরুল ইসলাম (পিতা)');
            const mobileText = emp.mobile || '০১৭১১-০০০০০০';
            const emergencyText = emp.emergency_contact || emp.mobile || '০১৭২০-১১২২৩৩';
            const nidText = emp.nid || `১৯৯২${String(emp.id).padStart(10, '0')}`;
            const addressText = emp.address || 'প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর';

            return (
              <div
                key={emp.id}
                id={`single-idcard-${emp.id}`}
                className={`id-card-print-item relative flex flex-col gap-4 max-w-[340px] mx-auto w-full group transition-all`}
              >
                {/* Action buttons in UI (hidden in print) */}
                <div className="print:hidden absolute -top-2.5 right-0 z-20 flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => printElementById(`single-idcard-${emp.id}`, `আইডি_কার্ড_${emp.employee_code}`)}
                    title="শুধুমাত্র এই কর্মীর আইডি কার্ড প্রিন্ট করুন"
                    className="w-7 h-7 rounded-full bg-white text-emerald-700 hover:bg-emerald-50 border border-emerald-200 shadow-sm flex items-center justify-center cursor-pointer transition-transform hover:scale-105"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setScannedWorker(emp)}
                    title="QR কোড স্ক্যান ও ডিজিটাল ভেরিফিকেশন"
                    className="w-7 h-7 rounded-full bg-white text-teal-700 hover:bg-teal-50 border border-teal-200 shadow-sm flex items-center justify-center cursor-pointer transition-transform hover:scale-105"
                  >
                    <QrCode className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteCard(emp)}
                    title="এই কর্মীর পরিচয়পত্র ও সমস্ত রেকর্ড সম্পূর্ণ মুছে ফেলুন"
                    className="w-7 h-7 rounded-full bg-white text-rose-600 hover:bg-rose-50 border border-rose-200 shadow-sm flex items-center justify-center cursor-pointer transition-transform hover:scale-105"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleSelect(emp.id)}
                    title={isSelected ? "নির্বাচন বাতিল" : "প্রিন্টের জন্য নির্বাচন"}
                    className={`w-7 h-7 rounded-full flex items-center justify-center cursor-pointer shadow-md transition-transform hover:scale-105 ${
                      isSelected
                        ? 'bg-emerald-600 text-white'
                        : 'bg-white text-slate-400 border border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {isSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                  </button>
                </div>

                {/* FRONT SIDE */}
                {(cardSide === 'front' || cardSide === 'both') && (
                  <div
                    className="relative bg-white border-2 border-slate-300 rounded-2xl shadow-md overflow-hidden flex flex-col justify-between w-full"
                    style={{ minHeight: '510px' }}
                  >
                    {/* Top Factory Header with Gradient */}
                    <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 text-white p-3.5 text-center relative shadow-xs">
                      <div className="flex items-center justify-center gap-2 mb-1">
                        <div className="w-6 h-6 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
                          <Shirt className="w-3.5 h-3.5 text-emerald-200" />
                        </div>
                        <h3 className="font-black text-sm tracking-tight leading-tight">
                          {companySettings?.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস'}
                        </h3>
                      </div>
                      <p className="text-[9.5px] text-emerald-200 tracking-wider uppercase font-semibold">
                        {companySettings?.company_name_en || 'TEXWARE APPARELS LTD.'}
                      </p>
                      <div className="inline-block mt-1 px-2 py-0.5 rounded-full bg-black/25 text-[8.5px] text-emerald-100 font-bold uppercase tracking-wider border border-white/10">
                        কারখানা শ্রমিক পরিচয়পত্র • FACTORY ID CARD
                      </div>
                    </div>

                    {/* Photo & Identity Section */}
                    <div className="p-4 text-center flex-1 flex flex-col items-center">
                      {/* Photo Badge */}
                      <div className="relative w-24 h-24 rounded-2xl border-2 border-emerald-600 p-0.5 shadow-sm mb-2.5 bg-slate-100 overflow-hidden flex items-center justify-center shrink-0">
                        {emp.photo_url ? (
                          <img
                            src={emp.photo_url}
                            alt={emp.full_name}
                            className="w-full h-full object-cover rounded-xl"
                            crossOrigin="anonymous"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-tr from-emerald-100 to-teal-50 flex flex-col items-center justify-center text-emerald-800">
                            <span className="text-2xl font-black">{emp.full_name?.charAt(0) || 'ক'}</span>
                            <span className="text-[8px] font-bold text-emerald-600 uppercase">কর্মী ছবি</span>
                          </div>
                        )}
                        <span className="absolute bottom-1 right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" title="সক্রিয় কর্মী" />
                      </div>

                      {/* Worker Name & Role */}
                      <h4 className="text-base font-bold text-slate-900 tracking-tight leading-tight">
                        {emp.full_name}
                      </h4>
                      <p className="text-xs font-semibold text-emerald-700 mt-0.5">
                        {emp.designation || 'সুইং অপারেটর'}
                      </p>

                      {/* ID Code Pill */}
                      <div className="mt-1.5 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-mono font-bold text-slate-800">
                        <span>আইডি: {emp.employee_code}</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                        <span className="text-emerald-700 font-sans font-semibold text-[10px]">
                          {emp.employee_type === 'worker' ? 'পোশাক শ্রমিক' : emp.employee_type === 'staff' ? 'স্টাফ' : 'কর্মকর্তা'}
                        </span>
                      </div>

                      {/* Real-time Detail Fields (NO BLANK FIELDS) */}
                      <div className="w-full mt-3.5 space-y-1.5 text-[11px] text-left border-t border-slate-100 pt-2.5 text-slate-600">
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">কারখানা বিভাগ:</span>
                          <span className="font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[10.5px]">
                            {emp.department}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">পিতা/স্বামীর নাম:</span>
                          <span className="font-medium text-slate-800 truncate max-w-[190px]">
                            {guardianText}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">মোবাইল নম্বর:</span>
                          <span className="font-mono font-semibold text-slate-800">
                            {mobileText}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">রক্তের গ্রুপ:</span>
                          <span className="inline-block px-1.5 py-0.2 rounded bg-rose-50 text-rose-700 font-bold font-mono text-[10.5px] border border-rose-200">
                            {bloodGroup}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">জাতীয় পরিচয়পত্র (NID):</span>
                          <span className="font-mono font-medium text-slate-700 text-[10px]">
                            {nidText}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">যোগদানের তারিখ:</span>
                          <span className="font-mono text-slate-700">
                            {issueDate}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">জরুরি যোগাযোগ:</span>
                          <span className="font-mono font-medium text-slate-700 truncate max-w-[170px]">
                            {emergencyText}
                          </span>
                        </div>
                      </div>

                      {/* Scannable Real-time QR Code & Security Barcode */}
                      <div className="w-full mt-3.5 p-2 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between">
                        <div
                          onClick={() => setScannedWorker(emp)}
                          title="QR কোড স্ক্যান ও ডিজিটাল গেট পাস যাচাই করতে ক্লিক করুন"
                          className="flex items-center gap-2 cursor-pointer group/qr"
                        >
                          <div className="w-10 h-10 bg-white p-0.5 rounded-lg border border-slate-200 group-hover/qr:border-teal-500 flex items-center justify-center shrink-0 shadow-2xs transition-colors">
                            {qrDataUrl ? (
                              <img src={qrDataUrl} alt="QR Code" className="w-full h-full object-contain" />
                            ) : (
                              <QrCode className="w-7 h-7 text-emerald-800" />
                            )}
                          </div>
                          <div className="text-left text-[9px] text-slate-500 leading-tight">
                            <span className="block font-bold text-slate-800 group-hover/qr:text-teal-700 transition-colors">
                              ডিজিটাল গেট পাস
                            </span>
                            <span className="font-mono text-[8px] text-slate-400">{emp.employee_code}</span>
                          </div>
                        </div>

                        <div className="text-right text-[8.5px] space-y-0.5 font-medium text-slate-500">
                          <div>মেয়াদ: <strong className="font-mono text-slate-700">{expiryDate}</strong></div>
                          <span className="inline-block px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[8px] font-bold uppercase">
                            যাচাইকৃত সক্রিয়
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Authorization Signatures */}
                    <div className="bg-slate-50 border-t border-slate-200 px-4 py-2.5">
                      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                        <div className="text-center">
                          <div className="w-20 border-t border-slate-400 mb-0.5" />
                          <span className="text-[9px]">কর্মীর স্বাক্ষর</span>
                        </div>

                        {/* Official Factory Stamp */}
                        <div className="flex flex-col items-center">
                          <div className="w-7 h-7 rounded-full border border-emerald-600/40 bg-emerald-50 flex items-center justify-center text-[7px] font-black text-emerald-700 leading-none text-center p-0.5 uppercase mb-0.5 shadow-2xs">
                            TEXWARE SEAL
                          </div>
                        </div>

                        <div className="text-center">
                          <div className="w-24 border-t border-slate-400 mb-0.5" />
                          <span className="font-bold text-emerald-900 text-[9px]">কর্তৃপক্ষ অনুমোদন</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* BACK SIDE */}
                {(cardSide === 'back' || cardSide === 'both') && (
                  <div
                    className="relative bg-white border-2 border-slate-300 rounded-2xl shadow-md overflow-hidden flex flex-col justify-between w-full p-4 text-left"
                    style={{ minHeight: '510px' }}
                  >
                    {/* Back Header */}
                    <div className="border-b border-slate-200 pb-2 text-center">
                      <h4 className="font-black text-xs text-slate-800 tracking-tight">
                        {companySettings?.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস'}
                      </h4>
                      <p className="text-[9px] text-slate-500 uppercase tracking-wide font-medium mt-0.5">
                        {companySettings?.company_name_en || 'Texware Apparels Ltd.'}
                      </p>
                    </div>

                    {/* Rules and Regulations for Factory Workers */}
                    <div className="space-y-2.5 my-auto text-[10.5px] text-slate-700 leading-relaxed">
                      <div className="p-2 bg-emerald-50/70 border border-emerald-100 rounded-xl text-emerald-900 text-[10px]">
                        <strong className="block font-bold mb-0.5">কারখানা শৃঙ্খলা ও পরিচয়পত্র ব্যবহারের নিয়মাবলী:</strong>
                        <ol className="list-decimal pl-4 space-y-1 text-slate-600">
                          <li>কারখানায় প্রবেশের সময় এই কার্ডটি দৃশ্যমানভাবে পরিধান করতে হবে।</li>
                          <li>কার্ডটি অহস্তান্তরযোগ্য এবং কারখানার নিজস্ব সম্পত্তি।</li>
                          <li>কার্ড হারিয়ে গেলে অবিলম্বে এইচআর বা সিকিউরিটি শাখাকে জানাতে হবে।</li>
                          <li>চাকরি ইস্তফা বা সমাপ্তির সময় কার্ডটি অবশ্যই কারখানা কর্তৃপক্ষের কাছে ফেরত দিতে হবে।</li>
                        </ol>
                      </div>

                      {/* Address & Emergency Contacts */}
                      <div className="space-y-1.5 text-[10px] text-slate-600 border-t border-slate-100 pt-2">
                        <div>
                          <span className="text-slate-400 font-semibold block text-[9.5px]">কর্মীর বর্তমান/স্থায়ী ঠিকানা:</span>
                          <span className="text-slate-800 font-medium">{addressText}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 font-semibold block text-[9.5px]">কারখানা অফিসের পূর্ণ ঠিকানা:</span>
                          <span className="text-slate-800">
                            {companySettings?.address || 'প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর, বাংলাদেশ'}
                          </span>
                        </div>
                        <div className="flex justify-between pt-1 font-mono text-[9.5px]">
                          <span>জরুরি ফোন: <strong className="text-slate-800">{companySettings?.phone || '+৮৮০ ১৭১১-২৩৪৫৬৭'}</strong></span>
                          <span>জাতীয় হটলাইন: <strong className="text-emerald-700">৯৯৯ / ৩৩৩</strong></span>
                        </div>
                      </div>
                    </div>

                    {/* Return Notice & Barcode */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-center text-[9px] text-slate-500">
                      <p className="font-semibold text-slate-700">
                        কার্ডটি কুড়িয়ে পেলে অনুগ্রহপূর্বক নিকটস্থ ডাকবাক্সে ফেলে দিন অথবা উপরিউক্ত কারখানা ঠিকানায় পৌঁছে দিন।
                      </p>
                      <div className="mt-2 font-mono text-[10px] tracking-widest text-slate-700 font-bold">
                        * {emp.employee_code} *
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Quick Add Worker Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="নতুন কর্মী যুক্ত করুন (Quick Worker Registration)"
        subtitle="কর্মীর তথ্য প্রদান করুন যা স্বয়ংক্রিয়ভাবে ডাটাবেজে সংরক্ষিত হবে এবং সাথে সাথে আইডি কার্ড তৈরি হবে"
        maxWidth="2xl"
      >
        <form onSubmit={handleCreateWorker} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">কর্মী আইডি (ঐচ্ছিক)</label>
              <input
                type="text"
                value={formData.employee_code}
                onChange={(e) => setFormData({ ...formData, employee_code: e.target.value })}
                placeholder="যেমন: EMP-105 (খালি রাখলে স্বয়ংক্রিয় হবে)"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">পূর্ণ নাম (Full Name) *</label>
              <input
                type="text"
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                required
                placeholder="যেমন: মোঃ আল আমিন"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">পিতা / স্বামীর নাম *</label>
              <input
                type="text"
                value={formData.guardian_name}
                onChange={(e) => setFormData({ ...formData, guardian_name: e.target.value })}
                required
                placeholder="যেমন: মোঃ মতিউর রহমান (পিতা)"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">মোবাইল নম্বর *</label>
              <input
                type="text"
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                required
                placeholder="01XXXXXXXXX"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">জাতীয় পরিচয়পত্র (NID) নম্বর</label>
              <input
                type="text"
                value={formData.nid}
                onChange={(e) => setFormData({ ...formData, nid: e.target.value })}
                placeholder="যেমন: 19942695503001"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">রক্তের গ্রুপ (Blood Group)</label>
              <select
                value={formData.blood_group}
                onChange={(e) => setFormData({ ...formData, blood_group: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-bold text-slate-700"
              >
                {BLOOD_GROUPS.map((bg) => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">কারখানা বিভাগ *</label>
              <select
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              >
                {DEPARTMENTS.filter((d) => d !== 'সব বিভাগ').map((dept) => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">পদবী (Designation) *</label>
              <input
                type="text"
                value={formData.designation}
                onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                required
                placeholder="যেমন: সুইং অপারেটর"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">কর্মীর ধরন / ক্যাটাগরি</label>
              <select
                value={formData.employee_type}
                onChange={(e) => setFormData({ ...formData, employee_type: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-medium"
              >
                <option value="worker">কারখানা পোশাক শ্রমিক (Worker)</option>
                <option value="staff">অফিস কর্মকর্তা ও স্টাফ (Staff)</option>
                <option value="supervisor">ফ্লোর সুপারভাইজার (Supervisor)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">যোগদানের তারিখ</label>
              <input
                type="date"
                value={formData.joining_date}
                onChange={(e) => setFormData({ ...formData, joining_date: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">বর্তমান ঠিকানা</label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              placeholder="গ্রাম/রোড, পোস্ট, থানা, জেলা"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">জরুরি যোগাযোগ (নাম ও মোবাইল)</label>
            <input
              type="text"
              value={formData.emergency_contact}
              onChange={(e) => setFormData({ ...formData, emergency_contact: e.target.value })}
              placeholder="যেমন: ভাই - 01720-112233"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">কর্মীর ছবি (URL - ঐচ্ছিক)</label>
            <input
              type="url"
              value={formData.photo_url}
              onChange={(e) => setFormData({ ...formData, photo_url: e.target.value })}
              placeholder="https://images.unsplash.com/..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={submittingWorker}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl shadow-xs shadow-emerald-600/20 cursor-pointer disabled:opacity-50"
            >
              {submittingWorker ? 'সংরক্ষণ হচ্ছে...' : 'ডাটাবেজে সংরক্ষণ ও কার্ড তৈরি'}
            </button>
          </div>
        </form>
      </Modal>

      {/* QR Code Digital Scanner / Verification Modal */}
      {scannedWorker && (
        <Modal
          isOpen={!!scannedWorker}
          onClose={() => setScannedWorker(null)}
          title="ডিজিটাল গেট পাস ও কিউআর কোড স্ক্যান যাচাই"
          subtitle={`স্মার্ট গেট পাস ও আইডি কার্ড ডিজিটাল ডাটা ভেরিফিকেশন (${scannedWorker.employee_code})`}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            {/* Top Verification Status Badge */}
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-emerald-900 text-sm">ডিজিটাল ভেরিফিকেশন সফল</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-800 text-[10px] font-bold">
                    সক্রিয় বৈধ কর্মী
                  </span>
                </div>
                <p className="text-slate-600 text-[11px] mt-0.5">
                  কারখানা গেট পাস সার্ভারে কর্মীর রিয়েল-টাইম রেকর্ড যাচাই সম্পন্ন হয়েছে।
                </p>
              </div>
            </div>

            {/* QR Code and Worker Photo preview */}
            <div className="flex items-center justify-center gap-6 p-4 bg-slate-50 border border-slate-200 rounded-2xl">
              <div className="text-center">
                <div className="w-28 h-28 bg-white p-1 rounded-xl border-2 border-emerald-500 shadow-sm mx-auto flex items-center justify-center">
                  {qrCodeMap[scannedWorker.id] ? (
                    <img
                      src={qrCodeMap[scannedWorker.id]}
                      alt="QR Code"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <QrCode className="w-16 h-16 text-emerald-800" />
                  )}
                </div>
                <span className="text-[10px] font-mono text-slate-500 font-bold block mt-1.5">
                  {scannedWorker.employee_code}
                </span>
              </div>

              <div className="text-left space-y-1">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">কারখানা</span>
                <p className="text-xs font-bold text-slate-800">
                  {companySettings?.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস'}
                </p>
                <span className="text-[10px] text-slate-400 block uppercase font-bold mt-2">কর্মী নাম</span>
                <p className="text-sm font-bold text-slate-900 leading-tight">
                  {scannedWorker.full_name}
                </p>
                <p className="text-xs font-semibold text-emerald-700">
                  {scannedWorker.designation} • {scannedWorker.department}
                </p>
              </div>
            </div>

            {/* Full Record Details */}
            <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-100 text-slate-700">
              <div className="px-3.5 py-2 flex justify-between">
                <span className="text-slate-400">মোবাইল নম্বর:</span>
                <span className="font-mono font-bold text-slate-800">{scannedWorker.mobile || '—'}</span>
              </div>
              <div className="px-3.5 py-2 flex justify-between">
                <span className="text-slate-400">রক্তের গ্রুপ:</span>
                <span className="font-bold text-rose-600 font-mono">{scannedWorker.blood_group || 'B+'}</span>
              </div>
              <div className="px-3.5 py-2 flex justify-between">
                <span className="text-slate-400">জাতীয় পরিচয়পত্র (NID):</span>
                <span className="font-mono text-slate-800">{scannedWorker.nid || '—'}</span>
              </div>
              <div className="px-3.5 py-2 flex justify-between">
                <span className="text-slate-400">জরুরি যোগাযোগ:</span>
                <span className="font-mono text-slate-800">{scannedWorker.emergency_contact || scannedWorker.mobile || '—'}</span>
              </div>
              <div className="px-3.5 py-2 flex justify-between">
                <span className="text-slate-400">বর্তমান ঠিকানা:</span>
                <span className="text-right text-slate-800 max-w-[200px] truncate">{scannedWorker.address || '—'}</span>
              </div>
              <div className="px-3.5 py-2 flex justify-between">
                <span className="text-slate-400">যোগদানের তারিখ:</span>
                <span className="font-mono text-slate-800">{scannedWorker.joining_date || '—'}</span>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  const toDelete = scannedWorker;
                  setScannedWorker(null);
                  handleDeleteCard(toDelete);
                }}
                className="px-3 py-1.5 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>আইডি কার্ড ও তথ্য মুছুন</span>
              </button>

              <button
                type="button"
                onClick={() => setScannedWorker(null)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
