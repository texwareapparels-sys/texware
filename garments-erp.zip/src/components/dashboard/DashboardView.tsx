import React, { useState, useEffect } from 'react';
import {
  Users,
  CalendarCheck,
  Banknote,
  Clock,
  Printer,
  Trash2,
  RefreshCw,
  Building,
  ShieldCheck,
  AlertTriangle,
  ChevronRight,
  UserPlus,
  MessageSquare,
  Contact,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileSpreadsheet,
  ArrowRight,
  Sparkles,
  Calendar,
  Layers,
  Award
} from 'lucide-react';
import { api } from '../../services/api';
import { DashboardStats } from '../../types';
import { useToast } from '../common/Toast';
import { NavTab } from '../layout/Sidebar';
import { Modal } from '../common/Modal';
import { QuickActionType } from '../layout/Header';
import { printElementById } from '../../utils/printDocument';

interface DashboardViewProps {
  onNavigate: (tab: NavTab) => void;
  onQuickAction: (action: QuickActionType) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onQuickAction }) => {
  const { showToast } = useToast();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const data = await api.getDashboardStats();
      setStats(data);
    } catch (err: any) {
      showToast(err.message || 'ড্যাশবোর্ড তথ্য লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const handleClearAllData = async () => {
    setIsResetting(true);
    try {
      const res = await api.clearAllData();
      showToast(res.message || 'সকল ডেমো তথ্য সফলভাবে মুছে ফেলা হয়েছে', 'success');
      setIsResetModalOpen(false);
      await fetchStats();
    } catch (err: any) {
      showToast(err.message || 'তথ্য মুছতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsResetting(false);
    }
  };

  const formatTk = (amount: number = 0) => {
    return '৳' + Math.round(amount).toLocaleString('bn-BD');
  };

  const formatNum = (num: number = 0) => {
    return Number(num).toLocaleString('bn-BD');
  };

  if (loading && !stats) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[450px] gap-3">
        <div className="w-10 h-10 border-3 border-emerald-500/20 border-t-emerald-600 rounded-full animate-spin" />
        <p className="text-xs text-slate-500 font-medium">কারখানা জনবল ও হাজিরা ড্যাশবোর্ড প্রস্তুত হচ্ছে...</p>
      </div>
    );
  }

  const todayStr = new Date().toLocaleDateString('bn-BD', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const totalEmps = stats?.activeEmployees || stats?.totalEmployees || 0;
  const presentEmps = stats?.attendance.present || 0;
  const absentEmps = stats?.attendance.absent || 0;
  const leaveEmps = stats?.attendance.leave || 0;
  const lateEmps = stats?.attendance.late || 0;
  const totalOtHours = stats?.attendance.otHours || 0;

  const attendanceRate = totalEmps > 0
    ? Math.round(((presentEmps + lateEmps) / totalEmps) * 100)
    : 0;

  const payroll = stats?.monthlyPayroll || {
    totalPayable: 0,
    totalPaid: 0,
    totalDue: 0,
    otAmount: 0,
  };

  const payrollPaidPercent = payroll.totalPayable > 0
    ? Math.round((payroll.totalPaid / payroll.totalPayable) * 100)
    : 0;

  const gatePasses = stats?.gatePassesToday || {
    total: 0,
    pending: 0,
    approved: 0,
    returned: 0,
    currentlyOut: 0
  };

  return (
    <div className="space-y-6 pb-14 font-['Hind_Siliguri',sans-serif]">
      {/* Top Header & Factory Operational Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              কারখানা লাইভ অপারেশন ও জনবল নিয়ন্ত্রণ
            </span>
            <span className="text-xs text-slate-500 font-medium">
              {todayStr}
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 mt-1 flex items-center gap-2">
            <span>টেক্স ওয়্যার অ্যাপারেলস — কারখানা এইচআর ও কর্মী ব্যবস্থাপনা</span>
          </h2>
          <p className="text-xs text-slate-500">
            শ্রমিক হাজিরা, লাইন শিফট, ওভারটাইম ঘণ্টা, মাসিক বেতন ও গেট পাস এক নজরে
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => printElementById('printable-dashboard-content', 'কারখানা_দৈনিক_জনবল_ও_হাজিরা_রিপোর্ট')}
            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            title="দৈনিক হাজিরা ও জনবল সারাংশ প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>জনবল রিপোর্ট প্রিন্ট</span>
          </button>

          <button
            onClick={fetchStats}
            title="রিফ্রেশ করুন"
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl border border-slate-200 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsResetModalOpen(true)}
            className="px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 border border-slate-200 hover:border-rose-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
            title="কারখানা ডাটাবেজ রিসেট করুন"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-500" />
            <span>ডাটা রিসেট</span>
          </button>
        </div>
      </div>

      {/* Actionable Alerts Bar */}
      {stats?.alerts && stats.alerts.length > 0 && (
        <div className="bg-amber-50/80 border border-amber-200/80 rounded-2xl p-4 flex items-start gap-3 text-amber-900 shadow-2xs">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <p className="font-bold text-amber-900">কারখানা অপারেশনাল নোটিশ ও অ্যালার্ট:</p>
            <div className="mt-1 flex flex-wrap gap-2 text-amber-800">
              {stats.alerts.map((al, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-100/70 border border-amber-200 font-medium"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  {al}
                </span>
              ))}
            </div>
          </div>
          <button
            onClick={() => onNavigate('attendance')}
            className="text-xs font-semibold text-amber-800 underline hover:text-amber-950 cursor-pointer shrink-0"
          >
            হাজিরা বিস্তারিত →
          </button>
        </div>
      )}

      {/* Printable Area Wrapper for Dashboard */}
      <div id="printable-dashboard-content" className="space-y-6">
        {/* Print-only Factory Header */}
        <div className="hidden print:block mb-6 pb-4 border-b-2 border-emerald-800 text-center">
          <h1 className="text-2xl font-black text-emerald-950">টেক্স ওয়্যার অ্যাপারেলস</h1>
          <p className="text-xs text-slate-600">Texware Apparels • প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর | ফোন: +880 1711-234567</p>
          <div className="inline-block mt-2 px-4 py-1 bg-emerald-800 text-white text-xs font-bold rounded-md">
            কারখানা দৈনিক জনবল, হাজিরা ও উৎপাদন সামারি রিপোর্ট
          </div>
          <div className="mt-2 text-xs text-slate-500 font-mono">
            তারিখ: {new Date().toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>

        {/* 🌟 1. মূল স্তম্ভ ৬টি KPI কার্ড (WORKFORCE EXECUTIVE METRICS) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3.5">
          {/* Card 1: মোট কর্মী */}
          <div
            onClick={() => onNavigate('employees')}
            className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-emerald-400 hover:shadow-sm transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">মোট সক্রিয় কর্মী</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-2xl font-black text-slate-900 font-mono">
                {formatNum(totalEmps)} <span className="text-xs font-normal text-slate-500">জন</span>
              </div>
              <p className="mt-2 text-[11px] text-slate-500 pt-1.5 border-t border-slate-100 flex justify-between">
                <span>রেজিস্টার্ড:</span>
                <span className="font-semibold text-slate-700">{formatNum(stats?.totalEmployees || totalEmps)} জন</span>
              </p>
            </div>
          </div>

          {/* Card 2: আজকের উপস্থিতি রেট */}
          <div
            onClick={() => onNavigate('attendance')}
            className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-emerald-400 hover:shadow-sm transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">আজকের উপস্থিতি</span>
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                <CalendarCheck className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-2xl font-black text-blue-700 font-mono">
                {formatNum(presentEmps)} <span className="text-xs font-normal text-slate-500">জন ({attendanceRate}%)</span>
              </div>
              <div className="mt-2 pt-1.5 border-t border-slate-100">
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-blue-600 h-1.5 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(attendanceRate, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Card 3: অনুপস্থিত ও লেট */}
          <div
            onClick={() => onNavigate('attendance')}
            className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-rose-400 hover:shadow-sm transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">অনুপস্থিত ও লেট</span>
              <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                <XCircle className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-2xl font-black text-rose-600 font-mono">
                {formatNum(absentEmps)} <span className="text-xs font-normal text-slate-500">অনুপস্থিত</span>
              </div>
              <p className="mt-2 text-[11px] text-slate-500 pt-1.5 border-t border-slate-100 flex justify-between">
                <span>বিলম্ব: <strong className="text-amber-700">{formatNum(lateEmps)}</strong></span>
                <span>ছুটি: <strong className="text-emerald-700">{formatNum(leaveEmps)}</strong></span>
              </p>
            </div>
          </div>

          {/* Card 4: ওভারটাইম কর্মঘণ্টা */}
          <div
            onClick={() => onNavigate('payroll')}
            className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-indigo-400 hover:shadow-sm transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">আজকের ওভারটাইম</span>
              <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-2xl font-black text-indigo-700 font-mono">
                {formatNum(totalOtHours)} <span className="text-xs font-normal text-slate-500">ঘণ্টা</span>
              </div>
              <p className="mt-2 text-[11px] text-slate-500 pt-1.5 border-t border-slate-100 flex justify-between">
                <span>শিফট: <strong>৮ ঘণ্টা</strong></span>
                <span className="text-indigo-600 font-medium">দ্বিগুণ হার (2x)</span>
              </p>
            </div>
          </div>

          {/* Card 5: চলতি মাসের বেতন বিল */}
          <div
            onClick={() => onNavigate('payroll')}
            className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-emerald-400 hover:shadow-sm transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">চলতি মাসের বেতন</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Banknote className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-black text-slate-900 font-mono truncate">
                {formatTk(payroll.totalPayable)}
              </div>
              <p className="mt-2 text-[11px] text-slate-500 pt-1.5 border-t border-slate-100 flex justify-between">
                <span>পরিশোধ:</span>
                <span className="font-semibold text-emerald-700">{formatTk(payroll.totalPaid)}</span>
              </p>
            </div>
          </div>

          {/* Card 6: আজকের গেট পাস */}
          <div
            onClick={() => onNavigate('attendance')}
            className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-amber-400 hover:shadow-sm transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">আজকের গেট পাস</span>
              <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                <ShieldCheck className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2.5">
              <div className="text-2xl font-black text-amber-700 font-mono">
                {formatNum(gatePasses.total)} <span className="text-xs font-normal text-slate-500">ইস্যু</span>
              </div>
              <p className="mt-2 text-[11px] text-slate-500 pt-1.5 border-t border-slate-100 flex justify-between">
                <span>বাইরে আছেন:</span>
                <span className="font-bold text-rose-600">{formatNum(gatePasses.currentlyOut)} জন</span>
              </p>
            </div>
          </div>
        </div>

        {/* 🌟 2. দ্রুত কাজের অ্যাকশন প্যানেল (QUICK WORKFORCE ACTION HUB) */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3.5">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>কারখানা ও কর্মী দ্রুত অপারেশনস (Quick HR Operations)</span>
            </h3>
            <span className="text-xs text-slate-500 hidden sm:inline">এক ক্লিকে মূল দায়িত্ব সম্পাদন</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <button
              onClick={() => onQuickAction('add_employee')}
              className="p-3 rounded-xl border border-slate-200/80 hover:border-emerald-500 hover:bg-emerald-50/40 text-left transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <UserPlus className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold text-slate-800">নতুন কর্মী যোগ</p>
              <p className="text-[10px] text-slate-500">বায়োডাটা ও লাইন নিবন্ধন</p>
            </button>

            <button
              onClick={() => onQuickAction('mark_attendance')}
              className="p-3 rounded-xl border border-slate-200/80 hover:border-blue-500 hover:bg-blue-50/40 text-left transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <CalendarCheck className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold text-slate-800">আজকের হাজিরা</p>
              <p className="text-[10px] text-slate-500">ইন-টাইম ও ওভারটাইম</p>
            </button>

            <button
              onClick={() => onQuickAction('payroll')}
              className="p-3 rounded-xl border border-slate-200/80 hover:border-emerald-500 hover:bg-emerald-50/40 text-left transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <Banknote className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold text-slate-800">বেতন ও পে-স্লিপ</p>
              <p className="text-[10px] text-slate-500">হাজিরা বোনাস ও কর্তন</p>
            </button>

            <button
              onClick={() => onQuickAction('issue_gatepass')}
              className="p-3 rounded-xl border border-slate-200/80 hover:border-amber-500 hover:bg-amber-50/40 text-left transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <Clock className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold text-slate-800">জরুরি গেট পাস</p>
              <p className="text-[10px] text-slate-500">অনুমোদন ও প্রিন্ট ভাউচার</p>
            </button>

            <button
              onClick={() => onNavigate('idcards')}
              className="p-3 rounded-xl border border-slate-200/80 hover:border-indigo-500 hover:bg-indigo-50/40 text-left transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <Contact className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold text-slate-800">আইডি কার্ড প্রিন্ট</p>
              <p className="text-[10px] text-slate-500">বারকোড ও ফ্যাক্টরি ব্যাজ</p>
            </button>

            <button
              onClick={() => onQuickAction('send_sms')}
              className="p-3 rounded-xl border border-slate-200/80 hover:border-purple-500 hover:bg-purple-50/40 text-left transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <MessageSquare className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold text-slate-800">এসএমএস নোটিশ</p>
              <p className="text-[10px] text-slate-500">বেতন ও ছুটির ঘোষণা</p>
            </button>
          </div>
        </div>

        {/* 🌟 3. ডিপার্টমেন্টভিত্তিক লাইভ হাজিরা ও ওভারটাইম টেবিল */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-600" />
                <span>বিভাগভিত্তিক আজকের হাজিরা ও ওভারটাইম পরিস্থিতি</span>
              </h3>
              <p className="text-xs text-slate-500">
                কাটিং, সুইং, ফিনিশিং, কিউসি, আয়রনিং ও অন্যান্য লাইনের আজকের উপস্থিতি রেকর্ড
              </p>
            </div>
            <button
              onClick={() => onNavigate('attendance')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
            >
              <span>সম্পূর্ণ হাজিরা শিট দেখুন</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200/70">
                <tr>
                  <th className="py-3 px-4">বিভাগ / লাইন</th>
                  <th className="py-3 px-4 text-center">মোট কর্মী</th>
                  <th className="py-3 px-4 text-center">উপস্থিত</th>
                  <th className="py-3 px-4 text-center">অনুপস্থিত</th>
                  <th className="py-3 px-4 text-center">উপস্থিতি হার (%)</th>
                  <th className="py-3 px-4 text-center">আজকের ওভারটাইম</th>
                  <th className="py-3 px-4 text-right">স্ট্যাটাস</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {(stats?.deptAttendance && stats.deptAttendance.length > 0) ? (
                  stats.deptAttendance.map((dept, index) => {
                    const deptTotal = dept.total || 0;
                    const deptPresent = dept.present || 0;
                    const deptAbsent = dept.absent || 0;
                    const deptOt = dept.ot_hours || 0;
                    const deptRate = deptTotal > 0 ? Math.round((deptPresent / deptTotal) * 100) : 0;

                    return (
                      <tr key={index} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-bold text-slate-800 flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-500" />
                          <span>{dept.department}</span>
                        </td>
                        <td className="py-3 px-4 text-center font-mono font-semibold">
                          {formatNum(deptTotal)} জন
                        </td>
                        <td className="py-3 px-4 text-center font-mono font-bold text-emerald-700">
                          {formatNum(deptPresent)}
                        </td>
                        <td className="py-3 px-4 text-center font-mono font-bold text-rose-600">
                          {formatNum(deptAbsent)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-16 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                              <div
                                className={`h-1.5 rounded-full ${
                                  deptRate >= 80 ? 'bg-emerald-600' : deptRate >= 60 ? 'bg-amber-500' : 'bg-rose-500'
                                }`}
                                style={{ width: `${Math.min(deptRate, 100)}%` }}
                              />
                            </div>
                            <span className="font-mono text-[11px] font-semibold">{deptRate}%</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-center font-mono font-semibold text-indigo-700">
                          {deptOt > 0 ? `${formatNum(deptOt)} ঘণ্টা` : '—'}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              deptRate >= 80
                                ? 'bg-emerald-100 text-emerald-800'
                                : deptRate >= 60
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {deptRate >= 80 ? 'চমৎকার' : deptRate >= 60 ? 'চলতি' : 'কম উপস্থিতি'}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-xs text-slate-400">
                      কোনো বিভাগীয় ডাটা খুঁজে পাওয়া যায়নি।
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot className="bg-slate-50/70 border-t border-slate-200 font-bold text-slate-800">
                <tr>
                  <td className="py-3 px-4">সর্বমোট কারখানা জনবল</td>
                  <td className="py-3 px-4 text-center font-mono">{formatNum(totalEmps)} জন</td>
                  <td className="py-3 px-4 text-center font-mono text-emerald-700">{formatNum(presentEmps)} জন</td>
                  <td className="py-3 px-4 text-center font-mono text-rose-600">{formatNum(absentEmps)} জন</td>
                  <td className="py-3 px-4 text-center font-mono">{attendanceRate}% গড়</td>
                  <td className="py-3 px-4 text-center font-mono text-indigo-700">{formatNum(totalOtHours)} ঘণ্টা</td>
                  <td className="py-3 px-4 text-right text-emerald-700">অপারেশন চলমান</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* 🌟 4. নিচের দুই কলাম: সাম্প্রতিক কর্মী ও জরুরি শিফট/পে-রোল তথ্য */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Left: নতুন যুক্ত কর্মীগণ */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>সাম্প্রতিক কর্মী তালিকা (Workforce Registry)</span>
                </h4>
                <button
                  onClick={() => onNavigate('employees')}
                  className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold cursor-pointer"
                >
                  সব কর্মী ({formatNum(totalEmps)}) →
                </button>
              </div>

              <div className="space-y-2.5">
                {(stats?.recentEmployees && stats.recentEmployees.length > 0) ? (
                  stats.recentEmployees.map((emp) => (
                    <div
                      key={emp.id}
                      className="p-2.5 rounded-xl border border-slate-100 bg-slate-50/50 flex items-center justify-between gap-3 hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs shrink-0">
                          {emp.full_name?.charAt(0) || 'E'}
                        </div>
                        <div className="truncate">
                          <p className="text-xs font-bold text-slate-800 truncate">{emp.full_name}</p>
                          <p className="text-[10px] text-slate-500 truncate">
                            {emp.employee_code} • {emp.designation} ({emp.department})
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => onNavigate('idcards')}
                        className="px-2 py-1 bg-white border border-slate-200 hover:border-emerald-400 text-slate-700 rounded-lg text-[10px] font-semibold shrink-0 cursor-pointer shadow-2xs"
                        title="আইডি কার্ড দেখুন"
                      >
                        আইডি কার্ড
                      </button>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-400 text-center py-4">কোনো সাম্প্রতিক কর্মী তথ্য নেই</p>
                )}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>নিয়মিত পরিচয়পত্র প্রদান ও বায়োডাটা সংরক্ষণ করুন</span>
              <button
                onClick={() => onQuickAction('add_employee')}
                className="font-bold text-emerald-700 hover:underline cursor-pointer"
              >
                + নতুন কর্মী যোগ করুন
              </button>
            </div>
          </div>

          {/* Right: চলতি মাসের বেতন ও বোনাস বিবরণী */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Banknote className="w-4 h-4 text-emerald-600" />
                  <span>চলতি মাসের বেতন ও ওভারটাইম বিল সারাংশ</span>
                </h4>
                <button
                  onClick={() => onNavigate('payroll')}
                  className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold cursor-pointer"
                >
                  বেতন শিট →
                </button>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-emerald-50/60 border border-emerald-100 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-emerald-800 font-semibold block">মোট প্রদেয় বেতন বিল</span>
                    <span className="text-lg font-black text-emerald-900 font-mono">
                      {formatTk(payroll.totalPayable)}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] text-slate-500 font-semibold block">পরিশোধের অগ্রগতি</span>
                    <span className="text-sm font-black text-emerald-700 font-mono">
                      {payrollPaidPercent}% সম্পন্ন
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 block">পরিশোধিত অর্থ</span>
                    <span className="text-sm font-bold text-emerald-700 font-mono">
                      {formatTk(payroll.totalPaid)}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 block">বকেয়া বেতন</span>
                    <span className={`text-sm font-bold font-mono ${payroll.totalDue > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
                      {formatTk(payroll.totalDue)}
                    </span>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-600">অন্তর্ভুক্ত ওভারটাইম বিল:</span>
                  <span className="font-bold text-indigo-700 font-mono">{formatTk(payroll.otAmount)}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">হাজিরা বোনাস ও অগ্রিম কর্তন স্বয়ংক্রিয়</span>
              <button
                onClick={() => onNavigate('payroll')}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs transition-colors"
              >
                মাসিক পে-রোল হিসাব দেখুন
              </button>
            </div>
          </div>
        </div>

        {/* Print-only Official Signatures */}
        <div className="hidden print:grid grid-cols-4 gap-6 mt-12 pt-6 text-center text-xs text-slate-700">
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1.5 font-semibold">ডিউটি অফিসার / টাইমকিপার</div>
          </div>
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1.5 font-semibold">ফ্লোর ইনচার্জ / সুপারভাইজার</div>
          </div>
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1.5 font-semibold">হিসাব কর্মকর্তা</div>
          </div>
          <div>
            <div className="h-10"></div>
            <div className="border-t border-dashed border-slate-400 pt-1.5 font-semibold">কারখানা ব্যবস্থাপক (জিএম)</div>
          </div>
        </div>
      </div>

      {/* Database Reset Confirmation Modal */}
      <Modal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        title="ডাটাবেজ সম্পূর্ণ রিসেট ও ডাটা মুছে ফেলার নিশ্চিতকরণ"
        maxWidth="md"
      >
        <div className="space-y-4">
          <div className="p-3 bg-rose-50 text-rose-900 border border-rose-200 rounded-xl flex items-start gap-3 text-xs">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">সতর্কতা: এটি পূর্বাবস্থায় ফিরিয়ে আনা যাবে না!</p>
              <p className="mt-1 text-rose-800">
                এই প্রক্রিয়াটি সম্পাদন করলে কারখানার সকল কর্মী, হাজিরা রেকর্ড, গেট পাস, ছুটি ও বেতন তালিকা মুছে যাবে। ডাটাবেজ সম্পূর্ণ শূন্য বা ফ্রেশ অবস্থায় ফিরে যাবে।
                সিস্টেমের প্রধান অ্যাডমিন অ্যাকাউন্ট ও ফ্যাক্টরি প্রোফাইল সেটিংস অক্ষত থাকবে।
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setIsResetModalOpen(false)}
              disabled={isResetting}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              onClick={handleClearAllData}
              disabled={isResetting}
              className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl cursor-pointer disabled:opacity-50"
            >
              {isResetting ? 'পরিষ্কার হচ্ছে...' : 'হ্যাঁ, সকল ডাটা রিসেট করুন'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
