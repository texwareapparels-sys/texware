import React, { useState, useMemo } from 'react';
import {
  Printer,
  FileText,
  Layers,
  CheckCircle2,
  ExternalLink,
  Building2,
  RotateCcw
} from 'lucide-react';
import { Modal } from '../common/Modal';
import { printHtml } from '../../utils/printDocument';
import { generateReportPrintHtml } from './reportPrintGenerator';

interface ReportPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  analytics: any;
  shops: any[];
  reportType: 'sales' | 'inventory' | 'payroll' | 'attendance' | 'expenses' | 'dues';
  monthYear: string;
}

export const ReportPrintModal: React.FC<ReportPrintModalProps> = ({
  isOpen,
  onClose,
  analytics,
  shops,
  reportType,
  monthYear,
}) => {
  const [mode, setMode] = useState<'current' | 'full'>('current');
  const [landscape, setLandscape] = useState<boolean>(true);
  const [printing, setPrinting] = useState(false);

  const reportTabLabels: Record<string, string> = {
    sales: 'পাইকারি বিক্রয় রিপোর্ট',
    inventory: 'উৎপাদন ও মজুদ ইনভেন্টরি',
    payroll: 'মাসিক বেতন ও ওভারটাইম',
    attendance: 'শ্রমিক হাজিরা ও মূল্যায়ন',
    expenses: 'কারখানা পরিচালন খরচ',
    dues: 'মার্কেট বাকি ও খাতা',
  };

  const printHtmlContent = useMemo(() => {
    if (!analytics) return '';
    return generateReportPrintHtml({
      analytics,
      shops,
      reportType,
      monthYear,
      mode,
      landscape,
    });
  }, [analytics, shops, reportType, monthYear, mode, landscape]);

  const handlePrint = () => {
    if (!printHtmlContent) return;
    setPrinting(true);
    const title =
      mode === 'full'
        ? `টেক্স_ওয়্যার_পূর্ণাঙ্গ_অডিট_রিপোর্ট_${monthYear}`
        : `টেক্স_ওয়্যার_${reportType}_রিপোর্ট_${monthYear}`;

    printHtml(printHtmlContent, { title, landscape });
    setTimeout(() => {
      setPrinting(false);
    }, 1000);
  };

  const handleOpenNewTab = () => {
    if (!printHtmlContent) return;
    const blob = new Blob([
      `<!DOCTYPE html><html lang="bn"><head><meta charset="UTF-8"><title>রিপোর্ট প্রিভিউ</title><style>@import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap'); body { font-family: 'Hind Siliguri', sans-serif; margin: 20px; }</style></head><body>${printHtmlContent}</body></html>`,
    ], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="ব্যবসায়িক রিপোর্ট প্রিন্ট ও অডিট সেন্টার"
      subtitle={`টেক্স ওয়্যার অ্যাপারেলস • ${monthYear} মাসের অফিসিয়াল অডিট ডকুমেন্ট প্রিন্ট`}
      maxWidth="4xl"
    >
      <div className="space-y-4 font-['Hind_Siliguri',sans-serif]">
        {/* Controls Bar */}
        <div className="bg-slate-50 p-3 sm:p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          {/* Scope Selector */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-slate-700">রিপোর্টের পরিধি:</span>
            <div className="inline-flex bg-white p-1 rounded-xl border border-slate-200 shadow-2xs">
              <button
                type="button"
                onClick={() => setMode('current')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  mode === 'current'
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>বর্তমান ট্যাব ({reportTabLabels[reportType]})</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('full')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  mode === 'full'
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>পূর্ণাঙ্গ অডিট রিপোর্ট (সকল বিভাগ সহ)</span>
              </button>
            </div>
          </div>

          {/* Orientation and Extra Buttons */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-white px-2 py-1 rounded-xl border border-slate-200">
              <span className="text-slate-500 font-medium">লেআউট:</span>
              <button
                type="button"
                onClick={() => setLandscape(true)}
                className={`px-2 py-1 rounded font-bold cursor-pointer transition-colors ${
                  landscape ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                ল্যান্ডস্কেপ (চওড়া)
              </button>
              <button
                type="button"
                onClick={() => setLandscape(false)}
                className={`px-2 py-1 rounded font-bold cursor-pointer transition-colors ${
                  !landscape ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                পোর্ট্রেট (লম্বা)
              </button>
            </div>

            <button
              type="button"
              onClick={handleOpenNewTab}
              className="p-2 text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              title="নতুন ট্যাবে ওপেন করুন"
            >
              <ExternalLink className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Live Print Preview Container */}
        <div className="border border-slate-300 rounded-xl bg-slate-100/70 p-3 sm:p-4 max-h-[60vh] overflow-y-auto shadow-inner">
          <div className="text-center text-[11px] text-slate-500 font-semibold mb-2 flex items-center justify-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>প্রিন্ট প্রিভিউ ডিসপ্লে (A4 কাগজের জন্য অপ্টিমাইজড)</span>
          </div>

          <div className="bg-white shadow-md rounded-lg p-6 sm:p-8 max-w-4xl mx-auto border border-slate-200">
            <div
              dangerouslySetInnerHTML={{ __html: printHtmlContent }}
              className="garments-print-preview"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-200">
          <div className="text-xs text-slate-500 hidden sm:block">
            রেজিস্ট্রেশন: <strong className="text-slate-700">BD-GAR-TEX-49021</strong> • টেক্স ওয়্যার অ্যাপারেলস
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer transition-colors"
            >
              বন্ধ করুন
            </button>

            <button
              type="button"
              onClick={handlePrint}
              disabled={printing}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-sm hover:shadow transition-all disabled:opacity-50"
            >
              <Printer className="w-4 h-4" />
              <span>{printing ? 'প্রিন্ট পাঠানো হচ্ছে...' : 'প্রিন্ট করুন (Print Now)'}</span>
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
