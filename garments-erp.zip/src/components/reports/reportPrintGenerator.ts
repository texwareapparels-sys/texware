/**
 * Report Print HTML Generator for Texware Apparels
 * Produces clean, print-optimized HTML for both single-tab and comprehensive audit reports.
 */

export interface ReportPrintOptions {
  analytics: any;
  shops?: any[];
  reportType: 'sales' | 'inventory' | 'payroll' | 'attendance' | 'expenses' | 'dues';
  monthYear: string;
  mode?: 'current' | 'full';
  landscape?: boolean;
}

export function generateReportPrintHtml(options: ReportPrintOptions): string {
  const { analytics, shops = [], reportType, monthYear, mode = 'current' } = options;

  const formatTk = (n: number = 0) => '৳ ' + Math.round(n).toLocaleString('bn-BD');
  const formatNum = (n: number = 0) => n.toLocaleString('bn-BD');

  const comp = analytics?.company || {
    company_name_bn: 'টেক্স ওয়্যার অ্যাপারেলস',
    company_name_en: 'Texware Apparels',
    address: 'প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর, বাংলাদেশ',
    phone: '+880 1711-234567',
    email: 'info@texwareapparels.com',
  };

  const kpis = {
    totalProductionPieces: analytics?.kpis?.totalProductionPieces || analytics?.kpis?.producedPieces || 0,
    totalSales: analytics?.kpis?.totalSales || 0,
    totalExpenses: analytics?.kpis?.totalExpenses || 0,
    totalSalaryPaid: analytics?.kpis?.totalSalaryPaid || analytics?.payroll?.summary?.total_paid || 0,
    totalDue: analytics?.kpis?.totalDue || analytics?.kpis?.marketDues || 0,
    netOperatingProfit: analytics?.kpis?.netOperatingProfit || 0,
    attendanceRate: analytics?.kpis?.attendanceRate || 0,
    activeEmployees: analytics?.kpis?.activeEmployees || 0,
  };

  const tabTitles: Record<string, string> = {
    sales: 'পাইকারি বিক্রয় ও শোরুম লেনদেন অডিট রিপোর্ট',
    inventory: 'গেঞ্জি উৎপাদন ও মজুদ ইনভেন্টরি অডিট রিপোর্ট',
    payroll: 'শ্রমিক-কর্মচারীদের মাসিক বেতন ও ওভারটাইম শিট',
    attendance: 'কারখানা কর্মী মাসিক হাজিরা ও কার্যদক্ষতা মূল্যায়ন',
    expenses: 'কারখানা পরিচালন ব্যয় ও খরচ ভাউচার অডিট রিপোর্ট',
    dues: 'মার্কেট বাকি ও শোরুম পার্টি খাতা লেজার',
  };

  const docTitle =
    mode === 'full'
      ? 'পূর্ণাঙ্গ ব্যবসায়িক ও কারখানা নিরীক্ষা অডিট রিপোর্ট (Comprehensive Audit Report)'
      : tabTitles[reportType] || 'ব্যবসায়িক রিপোর্ট';

  // KPI Section HTML
  const kpiSectionHtml = `
    <div style="margin-bottom: 14px;">
      <div style="font-weight: bold; font-size: 11px; margin-bottom: 5px; color: #064e3b; text-transform: uppercase; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px;">
        সাধারণ অডিট মেট্রিক্স ও সারসংক্ষেপ (Key Audit Metrics)
      </div>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 10.5px;">
        <tr style="background: #f8fafc;">
          <th style="padding: 5px 8px; border: 1px solid #cbd5e1; width: 14%;">মোট গেঞ্জি উৎপাদন</th>
          <th style="padding: 5px 8px; border: 1px solid #cbd5e1; width: 14%;">মোট পাইকারি বিক্রয়</th>
          <th style="padding: 5px 8px; border: 1px solid #cbd5e1; width: 14%;">মোট পরিচালন ব্যয়</th>
          <th style="padding: 5px 8px; border: 1px solid #cbd5e1; width: 14%;">মোট পরিশোধিত বেতন</th>
          <th style="padding: 5px 8px; border: 1px solid #cbd5e1; width: 14%;">মার্কেট বকেয়া (Due)</th>
          <th style="padding: 5px 8px; border: 1px solid #cbd5e1; width: 15%;">নিট পরিচালন মুনাফা</th>
          <th style="padding: 5px 8px; border: 1px solid #cbd5e1; width: 15%;">শ্রমিক হাজিরা হার</th>
        </tr>
        <tr style="text-align: center; font-weight: bold;">
          <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 12px; color: #0f172a;">
            ${formatNum(kpis.totalProductionPieces)} পিস
          </td>
          <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 12px; color: #065f46;">
            ${formatTk(kpis.totalSales)}
          </td>
          <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 12px; color: #991b1b;">
            ${formatTk(kpis.totalExpenses)}
          </td>
          <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 12px; color: #1e293b;">
            ${formatTk(kpis.totalSalaryPaid)}
          </td>
          <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 12px; color: #b45309;">
            ${formatTk(kpis.totalDue)}
          </td>
          <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 12px; color: ${kpis.netOperatingProfit >= 0 ? '#047857' : '#dc2626'};">
            ${formatTk(kpis.netOperatingProfit)}
          </td>
          <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 12px; color: #0f172a;">
            ${kpis.attendanceRate}% (${kpis.activeEmployees} জন)
          </td>
        </tr>
      </table>
    </div>
  `;

  // 1. Sales Table HTML
  const salesList = analytics?.salesByShop || analytics?.sales?.items || [];
  let totalSalesPieces = 0;
  let totalSalesVal = 0;
  let totalSalesPaid = 0;
  let totalSalesDue = 0;

  salesList.forEach((s: any) => {
    totalSalesPieces += Number(s.total_pieces || s.quantity || 0);
    totalSalesVal += Number(s.total_sales || s.net_amount || 0);
    totalSalesPaid += Number(s.total_paid || s.paid_amount || 0);
    totalSalesDue += Number(s.current_due || s.due_amount || 0);
  });

  const salesRows = salesList.length > 0 ? salesList.map((s: any, idx: number) => `
    <tr>
      <td style="text-align: center; width: 30px;">${idx + 1}</td>
      <td style="font-weight: bold; color: #0f172a;">${s.shop_name || s.name || '—'}</td>
      <td>${s.address || '—'} ${s.owner_name ? '(' + s.owner_name + ')' : ''}</td>
      <td style="font-family: monospace; text-align: center;">${s.phone || '—'}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold;">${formatNum(s.total_pieces || 0)} পিস</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold;">${formatTk(s.total_sales)}</td>
      <td style="text-align: right; font-family: monospace; color: #065f46;">${formatTk(s.total_paid)}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold; color: ${(s.current_due || 0) > 0 ? '#b45309' : '#047857'};">
        ${(s.current_due || 0) > 0 ? formatTk(s.current_due) : '৳ ০'}
      </td>
    </tr>
  `).join('') : `
    <tr>
      <td colspan="8" style="text-align: center; padding: 12px; color: #64748b;">নির্বাচিত মাসে কোনো পাইকারি বিক্রয়ের রেকর্ড পাওয়া যায়নি</td>
    </tr>
  `;

  const salesTableHtml = `
    <div style="margin-bottom: 16px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
        <span style="font-weight: bold; font-size: 11px; color: #064e3b; border-left: 3px solid #059669; padding-left: 6px;">
          ১. পাইকারি ক্রেতা ও শোরুম বিক্রয় বিবরণী
        </span>
        <span style="font-size: 10px; color: #64748b;">মোট ক্রেতা/দোকান: ${salesList.length} টি</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
        <thead>
          <tr style="background: #f1f5f9; text-align: left;">
            <th style="width: 30px; text-align: center;">#</th>
            <th>দোকানের নাম</th>
            <th>ঠিকানা ও মালিক</th>
            <th style="text-align: center;">ফোন</th>
            <th style="text-align: right;">ক্রয়কৃত গেঞ্জি</th>
            <th style="text-align: right;">মোট বিক্রয় মূল্য</th>
            <th style="text-align: right;">পরিশোধ</th>
            <th style="text-align: right;">বকেয়া (Due)</th>
          </tr>
        </thead>
        <tbody>
          ${salesRows}
        </tbody>
        <tfoot>
          <tr style="background: #f8fafc; font-weight: bold; border-top: 2px solid #94a3b8;">
            <td colspan="4" style="text-align: right; padding: 6px 8px;">সর্বমোট বিক্রয় যোগফল:</td>
            <td style="text-align: right; font-family: monospace; padding: 6px 8px;">${formatNum(totalSalesPieces)} পিস</td>
            <td style="text-align: right; font-family: monospace; padding: 6px 8px;">${formatTk(totalSalesVal)}</td>
            <td style="text-align: right; font-family: monospace; color: #065f46; padding: 6px 8px;">${formatTk(totalSalesPaid)}</td>
            <td style="text-align: right; font-family: monospace; color: #b45309; padding: 6px 8px;">${formatTk(totalSalesDue)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  `;

  // 2. Inventory Table HTML
  const inventoryList = analytics?.inventoryBreakdown || analytics?.inventory?.breakdown || [];
  let totalStockPieces = 0;
  let totalStockValue = 0;

  inventoryList.forEach((it: any) => {
    totalStockPieces += Number(it.total_stock || it.total_pieces || it.stock_quantity || 0);
    totalStockValue += Number(it.total_value || it.stock_value || 0);
  });

  const inventoryRows = inventoryList.length > 0 ? inventoryList.map((it: any, idx: number) => `
    <tr>
      <td style="text-align: center; width: 30px;">${idx + 1}</td>
      <td style="font-weight: bold; color: #0f172a;">${it.product_name || it.category || 'গেঞ্জি'}</td>
      <td style="font-weight: 500;">${it.color || 'সকল কালার'}</td>
      <td style="font-family: monospace;">${it.sizes || it.size_details || '—'}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold;">${formatNum(it.total_stock || it.total_pieces || 0)} পিস</td>
      <td style="text-align: right; font-family: monospace;">৳ ${(it.unit_price || it.selling_price || 0)}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold; color: #065f46;">${formatTk(it.total_value || it.stock_value || 0)}</td>
    </tr>
  `).join('') : `
    <tr>
      <td colspan="7" style="text-align: center; padding: 12px; color: #64748b;">ইনভেন্টরিতে কোনো স্টক বা উৎপাদনের রেকর্ড নেই</td>
    </tr>
  `;

  const inventoryTableHtml = `
    <div style="margin-bottom: 16px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
        <span style="font-weight: bold; font-size: 11px; color: #064e3b; border-left: 3px solid #059669; padding-left: 6px;">
          ২. গেঞ্জি উৎপাদন আউটপুট ও মজুদ ইনভেন্টরি বিবরণী
        </span>
        <span style="font-size: 10px; color: #64748b;">মোট ভ্যারিয়েন্ট: ${inventoryList.length} টি</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
        <thead>
          <tr style="background: #f1f5f9; text-align: left;">
            <th style="width: 30px; text-align: center;">#</th>
            <th>পণ্য / ক্যাটাগরি</th>
            <th>কালার</th>
            <th>সাইজ বিস্তারিত (S, M, L, XL, XXL)</th>
            <th style="text-align: right;">মজুদ স্টক</th>
            <th style="text-align: right;">পাইকারি দর</th>
            <th style="text-align: right;">মোট স্টক মূল্য</th>
          </tr>
        </thead>
        <tbody>
          ${inventoryRows}
        </tbody>
        <tfoot>
          <tr style="background: #f8fafc; font-weight: bold; border-top: 2px solid #94a3b8;">
            <td colspan="4" style="text-align: right; padding: 6px 8px;">মোট প্রস্তুত স্টক ও মূল্যায়ন:</td>
            <td style="text-align: right; font-family: monospace; padding: 6px 8px;">${formatNum(totalStockPieces)} পিস</td>
            <td></td>
            <td style="text-align: right; font-family: monospace; color: #065f46; padding: 6px 8px;">${formatTk(totalStockValue)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  `;

  // 3. Payroll Table HTML
  const payrollList = analytics?.payrollBreakdown || analytics?.payroll?.departments || [];
  let totalPayrollPayable = 0;
  let totalPayrollPaid = 0;
  let totalPayrollWorkers = 0;
  let totalOtHours = 0;

  payrollList.forEach((p: any) => {
    totalPayrollWorkers += Number(p.employee_count || p.emp_count || 0);
    totalPayrollPayable += Number(p.total_payable || p.total_salary || 0);
    totalPayrollPaid += Number(p.total_paid || 0);
    totalOtHours += Number(p.total_overtime_hours || p.total_ot_hours || 0);
  });

  const payrollRows = payrollList.length > 0 ? payrollList.map((p: any, idx: number) => `
    <tr>
      <td style="text-align: center; width: 30px;">${idx + 1}</td>
      <td style="font-weight: bold; color: #0f172a;">${p.department}</td>
      <td style="text-align: center; font-family: monospace;">${p.employee_count || p.emp_count} জন</td>
      <td style="text-align: right; font-family: monospace;">${p.total_overtime_hours || p.total_ot_hours || 0} ঘণ্টা</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold;">${formatTk(p.total_payable || p.total_salary)}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold; color: #065f46;">${formatTk(p.total_paid)}</td>
    </tr>
  `).join('') : `
    <tr>
      <td colspan="6" style="text-align: center; padding: 12px; color: #64748b;">নির্বাচিত মাসের কোনো বেতন শিট রেকর্ড পাওয়া যায়নি</td>
    </tr>
  `;

  const payrollTableHtml = `
    <div style="margin-bottom: 16px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
        <span style="font-weight: bold; font-size: 11px; color: #064e3b; border-left: 3px solid #059669; padding-left: 6px;">
          ৩. বিভাগভিত্তিক শ্রমিক-কর্মচারী বেতন ও ওভারটাইম শিট
        </span>
        <span style="font-size: 10px; color: #64748b;">মোট বিভাগ: ${payrollList.length} টি</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
        <thead>
          <tr style="background: #f1f5f9; text-align: left;">
            <th style="width: 30px; text-align: center;">#</th>
            <th>কারখানা সেকশন / বিভাগ</th>
            <th style="text-align: center;">কর্মী সংখ্যা</th>
            <th style="text-align: right;">ওভারটাইম (ঘণ্টা)</th>
            <th style="text-align: right;">মোট প্রদেয় বেতন</th>
            <th style="text-align: right;">পরিশোধিত বেতন</th>
          </tr>
        </thead>
        <tbody>
          ${payrollRows}
        </tbody>
        <tfoot>
          <tr style="background: #f8fafc; font-weight: bold; border-top: 2px solid #94a3b8;">
            <td colspan="2" style="text-align: right; padding: 6px 8px;">মোট বেতন ব্যয়:</td>
            <td style="text-align: center; font-family: monospace; padding: 6px 8px;">${totalPayrollWorkers} জন</td>
            <td style="text-align: right; font-family: monospace; padding: 6px 8px;">${totalOtHours} ঘণ্টা</td>
            <td style="text-align: right; font-family: monospace; padding: 6px 8px;">${formatTk(totalPayrollPayable)}</td>
            <td style="text-align: right; font-family: monospace; color: #065f46; padding: 6px 8px;">${formatTk(totalPayrollPaid)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  `;

  // 4. Attendance Table HTML
  const attendanceList = analytics?.attendanceBreakdown || analytics?.attendance?.departments || [];
  const attendanceRows = attendanceList.length > 0 ? attendanceList.map((a: any, idx: number) => `
    <tr>
      <td style="text-align: center; width: 30px;">${idx + 1}</td>
      <td style="font-weight: bold; color: #0f172a;">${a.department}</td>
      <td style="text-align: center; font-family: monospace;">${a.employee_count || a.emp_count} জন</td>
      <td style="text-align: center; font-family: monospace; color: #065f46; font-weight: bold;">${a.present_count || a.presents || 0}</td>
      <td style="text-align: center; font-family: monospace; color: #b45309;">${a.late_count || 0}</td>
      <td style="text-align: center; font-family: monospace; color: #dc2626;">${a.absent_count || 0}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold;">${a.attendance_rate || a.rate || 0}%</td>
    </tr>
  `).join('') : `
    <tr>
      <td colspan="7" style="text-align: center; padding: 12px; color: #64748b;">নির্বাচিত মাসে কোনো হাজিরা রেকর্ড নেই</td>
    </tr>
  `;

  const attendanceTableHtml = `
    <div style="margin-bottom: 16px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
        <span style="font-weight: bold; font-size: 11px; color: #064e3b; border-left: 3px solid #059669; padding-left: 6px;">
          ৪. কারখানা কর্মী মাসিক হাজিরা ও মূল্যায়ন
        </span>
        <span style="font-size: 10px; color: #64748b;">গড় উপস্থিতি: ${kpis.attendanceRate}%</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
        <thead>
          <tr style="background: #f1f5f9; text-align: left;">
            <th style="width: 30px; text-align: center;">#</th>
            <th>কারখানা সেকশন</th>
            <th style="text-align: center;">কর্মী সংখ্যা</th>
            <th style="text-align: center;">উপস্থিত দিন</th>
            <th style="text-align: center;">দেরি</th>
            <th style="text-align: center;">অনুপস্থিত</th>
            <th style="text-align: right;">উপস্থিতি হার</th>
          </tr>
        </thead>
        <tbody>
          ${attendanceRows}
        </tbody>
      </table>
    </div>
  `;

  // 5. Expenses Table HTML
  const expensesList = analytics?.expenses?.items || [];
  let totalExpenseVal = 0;
  expensesList.forEach((e: any) => {
    totalExpenseVal += Number(e.amount || 0);
  });

  const expenseRows = expensesList.length > 0 ? expensesList.map((e: any, idx: number) => `
    <tr>
      <td style="text-align: center; width: 30px;">${idx + 1}</td>
      <td style="font-family: monospace; font-weight: bold;">${e.voucher_no || e.expense_no || 'EXP-' + (idx + 1)}</td>
      <td>${e.date || e.expense_date || '—'}</td>
      <td style="font-weight: bold;">${e.category || 'সাধারণ খরচ'}</td>
      <td>${e.paid_to || 'কারখানা'}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold; color: #991b1b;">${formatTk(e.amount)}</td>
    </tr>
  `).join('') : `
    <tr>
      <td colspan="6" style="text-align: center; padding: 12px; color: #64748b;">নির্বাচিত মাসে কোনো ব্যয়ের ভাউচার নেই</td>
    </tr>
  `;

  const expensesTableHtml = `
    <div style="margin-bottom: 16px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
        <span style="font-weight: bold; font-size: 11px; color: #064e3b; border-left: 3px solid #059669; padding-left: 6px;">
          ৫. কারখানা ব্যয় ও পরিচালন খরচ লেজার
        </span>
        <span style="font-size: 10px; color: #64748b;">মোট ভাউচার: ${expensesList.length} টি</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
        <thead>
          <tr style="background: #f1f5f9; text-align: left;">
            <th style="width: 30px; text-align: center;">#</th>
            <th>ভাউচার নং</th>
            <th>তারিখ</th>
            <th>খরচের খাত (Head)</th>
            <th>প্রাপক</th>
            <th style="text-align: right;">পরিমাণ (টাকা)</th>
          </tr>
        </thead>
        <tbody>
          ${expenseRows}
        </tbody>
        <tfoot>
          <tr style="background: #f8fafc; font-weight: bold; border-top: 2px solid #94a3b8;">
            <td colspan="5" style="text-align: right; padding: 6px 8px;">মোট কারখানা ব্যয়:</td>
            <td style="text-align: right; font-family: monospace; color: #991b1b; padding: 6px 8px;">${formatTk(totalExpenseVal || kpis.totalExpenses)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  `;

  // 6. Market Dues Table HTML
  const dueShops = shops.filter((s: any) => (s.current_due || 0) > 0);
  let totalShopDue = 0;
  dueShops.forEach((s: any) => {
    totalShopDue += Number(s.current_due || 0);
  });

  const dueRows = dueShops.length > 0 ? dueShops.map((s: any, idx: number) => `
    <tr>
      <td style="text-align: center; width: 30px;">${idx + 1}</td>
      <td style="font-weight: bold; color: #0f172a;">${s.name}</td>
      <td>${s.owner_name || '—'} (${s.address || '—'})</td>
      <td style="font-family: monospace; text-align: center;">${s.phone || '—'}</td>
      <td style="text-align: right; font-family: monospace;">${formatTk(s.total_purchased)}</td>
      <td style="text-align: right; font-family: monospace; color: #065f46;">${formatTk(s.total_paid)}</td>
      <td style="text-align: right; font-family: monospace; font-weight: bold; color: #b45309;">${formatTk(s.current_due)}</td>
    </tr>
  `).join('') : `
    <tr>
      <td colspan="7" style="text-align: center; padding: 12px; color: #047857; font-weight: bold;">আলহামদুলিল্লাহ, শোরুম বা পার্টিদের নিকট কোনো বকেয়া নেই!</td>
    </tr>
  `;

  const duesTableHtml = `
    <div style="margin-bottom: 16px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
        <span style="font-weight: bold; font-size: 11px; color: #064e3b; border-left: 3px solid #059669; padding-left: 6px;">
          ৬. মার্কেট বকেয়া ও পার্টি লেজার বিবরণী
        </span>
        <span style="font-size: 10px; color: #64748b;">বকেয়া পার্টি: ${dueShops.length} টি</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
        <thead>
          <tr style="background: #f1f5f9; text-align: left;">
            <th style="width: 30px; text-align: center;">#</th>
            <th>দোকানের নাম</th>
            <th>মালিক ও ঠিকানা</th>
            <th style="text-align: center;">ফোন</th>
            <th style="text-align: right;">মোট ক্রয়</th>
            <th style="text-align: right;">মোট জমা</th>
            <th style="text-align: right;">বর্তমান বকেয়া (Due)</th>
          </tr>
        </thead>
        <tbody>
          ${dueRows}
        </tbody>
        <tfoot>
          <tr style="background: #f8fafc; font-weight: bold; border-top: 2px solid #94a3b8;">
            <td colspan="6" style="text-align: right; padding: 6px 8px;">মার্কেটে সর্বমোট বকেয়া:</td>
            <td style="text-align: right; font-family: monospace; color: #b45309; padding: 6px 8px;">${formatTk(totalShopDue || kpis.totalDue)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  `;

  // Determine which sections to render
  let contentHtml = '';
  if (mode === 'full') {
    contentHtml = `
      ${salesTableHtml}
      <div style="page-break-before: auto;"></div>
      ${inventoryTableHtml}
      <div style="page-break-before: auto;"></div>
      ${payrollTableHtml}
      <div style="page-break-before: auto;"></div>
      ${attendanceTableHtml}
      <div style="page-break-before: auto;"></div>
      ${expensesTableHtml}
      <div style="page-break-before: auto;"></div>
      ${duesTableHtml}
    `;
  } else {
    // Current selected tab only
    if (reportType === 'sales') contentHtml = salesTableHtml;
    else if (reportType === 'inventory') contentHtml = inventoryTableHtml;
    else if (reportType === 'payroll') contentHtml = payrollTableHtml;
    else if (reportType === 'attendance') contentHtml = attendanceTableHtml;
    else if (reportType === 'expenses') contentHtml = expensesTableHtml;
    else if (reportType === 'dues') contentHtml = duesTableHtml;
  }

  const currentDateBn = new Date().toLocaleDateString('bn-BD', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return `
    <div style="padding: 10px; font-family: 'Hind Siliguri', sans-serif;">
      <!-- Company Official Header -->
      <div class="print-header">
        <h1 class="company-title">${comp.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস'}</h1>
        <p class="company-sub">${comp.company_name_en || 'Texware Apparels Ltd.'} • পাইকারি গেঞ্জি ম্যানুফ্যাকচারিং ও সাপ্লাইয়ার</p>
        <p class="company-sub">${comp.address || 'প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর'} | ফোন: ${comp.phone || '০১৭১১-২৩৪৫৬৭'} | ইমেইল: ${comp.email || 'info@texwareapparels.com'}</p>
        <div class="doc-title">${docTitle}</div>
        <div style="margin-top: 4px; font-size: 10.5px; color: #475569;">
          প্রতিবেদনের সময়কাল: <strong style="color: #0f172a;">${monthYear}</strong> • প্রিন্টের তারিখ: <strong style="color: #0f172a;">${currentDateBn}</strong> • রেজিস্ট্রেশন: BD-GAR-TEX-49021
        </div>
      </div>

      <!-- KPI Executive Summary -->
      ${kpiSectionHtml}

      <!-- Detailed Content Tables -->
      ${contentHtml}

      <!-- Factory Audit & Authorization Signatures -->
      <div style="margin-top: 35px; page-break-inside: avoid;">
        <table style="width: 100%; border: none; text-align: center; font-size: 10.5px; color: #475569;">
          <tr style="border: none;">
            <td style="border: none; width: 25%; padding-top: 30px;">
              <div style="border-top: 1px dashed #64748b; width: 140px; margin: 0 auto 4px auto;"></div>
              <strong>হিসাব নিরীক্ষক (Auditor)</strong>
            </td>
            <td style="border: none; width: 25%; padding-top: 30px;">
              <div style="border-top: 1px dashed #64748b; width: 140px; margin: 0 auto 4px auto;"></div>
              <strong>অ্যাকাউন্টস অফিসার</strong>
            </td>
            <td style="border: none; width: 25%; padding-top: 30px;">
              <div style="border-top: 1px dashed #64748b; width: 140px; margin: 0 auto 4px auto;"></div>
              <strong>ফ্যাক্টরি ম্যানেজার</strong>
            </td>
            <td style="border: none; width: 25%; padding-top: 30px;">
              <div style="border-top: 1px dashed #64748b; width: 140px; margin: 0 auto 4px auto;"></div>
              <strong>ব্যবস্থাপনা পরিচালক (MD)</strong>
            </td>
          </tr>
        </table>
      </div>

      <div style="margin-top: 20px; font-size: 9px; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 6px;">
        Texware Apparels Garments ERP সিস্টেম দ্বারা স্বয়ংক্রিয়ভাবে প্রস্তুতকৃত অফিসিয়াল অডিট ডকুমেন্ট • পৃষ্ঠা সংক্রান্ত কোনো অসঙ্গতি পরিলক্ষিত হলে অবিলম্বে প্রধান কার্যালয়ে যোগাযোগ করুন।
      </div>
    </div>
  `;
}
