import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Calendar,
  Filter,
  BarChart3,
  TrendingUp,
  Boxes,
  Users,
  Banknote,
  DollarSign,
  Shirt,
  AlertCircle,
  RefreshCw,
  Trash2,
  Receipt,
  CreditCard
} from 'lucide-react';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { printHtml, printElementById } from '../../utils/printDocument';
import { ReportPrintModal } from './ReportPrintModal';
import { generateReportPrintHtml } from './reportPrintGenerator';

export const ReportsView: React.FC = () => {
  const { showToast } = useToast();
  const [reportType, setReportType] = useState<
    'sales' | 'inventory' | 'payroll' | 'attendance' | 'expenses' | 'dues'
  >('sales');

  // Default to current year-month
  const [monthYear, setMonthYear] = useState(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  });

  const [analytics, setAnalytics] = useState<any>(null);
  const [shops, setShops] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Print Modal state
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Delete Report Modal
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteCategory, setDeleteCategory] = useState<string>('all');
  const [deleting, setDeleting] = useState(false);

  const fetchAnalytics = async (selectedMonth: string) => {
    setLoading(true);
    try {
      const [data, shopData] = await Promise.all([
        api.getAnalyticsReport({ month: selectedMonth }),
        api.getShops().catch(() => []),
      ]);
      setAnalytics(data);
      setShops(shopData || []);
    } catch (err: any) {
      showToast(err.message || 'রিপোর্ট অ্যানালিটিক্স লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics(monthYear);
  }, [monthYear]);

  const handleOpenPrintModal = () => {
    if (!analytics) {
      showToast('রিপোর্ট লোড হচ্ছে, অনুগ্রহ করে একটু অপেক্ষা করুন', 'info');
      return;
    }
    setIsPrintModalOpen(true);
  };

  const handleQuickPrint = () => {
    if (!analytics) {
      showToast('কোনো রিপোর্ট তথ্য পাওয়া যায়নি', 'error');
      return;
    }
    const html = generateReportPrintHtml({
      analytics,
      shops,
      reportType,
      monthYear,
      mode: 'current',
      landscape: true,
    });
    printHtml(html, {
      title: `টেক্স_ওয়্যার_${reportType}_রিপোর্ট_${monthYear}`,
      landscape: true,
    });
  };

  const formatTk = (n: number = 0) => '৳ ' + Math.round(n).toLocaleString('bn-BD');

  const handleDeleteReportData = async () => {
    setDeleting(true);
    try {
      await api.deleteReportPeriod(monthYear, deleteCategory);
      showToast(`${monthYear} মাসের রিপোর্ট রেকর্ড সফলভাবে মুছে ফেলা হয়েছে`, 'success');
      setIsDeleteModalOpen(false);
      fetchAnalytics(monthYear);
    } catch (err: any) {
      showToast(err.message || 'রিপোর্ট মুছতে সমস্যা হয়েছে', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const handleExportCsv = () => {
    if (!analytics) {
      showToast('কোনো রিপোর্ট তথ্য পাওয়া যায়নি', 'error');
      return;
    }

    const compName = analytics.company?.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস';
    const rows: string[][] = [
      [compName],
      ['ব্যবসায়িক অ্যানালিটিক্স ও অডিট রিপোর্ট'],
      [`প্রতিবেদনের মাস: ${monthYear}`],
      [],
      ['সাধারণ সারসংক্ষেপ (KPI Metrics)', 'পরিমাণ / তথ্য'],
      ['মোট গেঞ্জি উৎপাদন', `${analytics.kpis?.totalProductionPieces || analytics.kpis?.producedPieces || 0} পিস`],
      ['মোট পাইকারি বিক্রয়', `${analytics.kpis?.totalSales || 0} টাকা`],
      ['মোট কারখানা পরিচালন ব্যয়', `${analytics.kpis?.totalExpenses || 0} টাকা`],
      ['মোট পরিশোধিত বেতন', `${analytics.kpis?.totalSalaryPaid || 0} টাকা`],
      ['মার্কেটের মোট বকেয়া (Due)', `${analytics.kpis?.totalDue || analytics.kpis?.marketDues || 0} টাকা`],
      ['নিট পরিচালন মুনাফা (Net Profit)', `${analytics.kpis?.netOperatingProfit || 0} টাকা`],
      ['শ্রমিক গড় উপস্থিতি হার', `${analytics.kpis?.attendanceRate || 0}%`],
      ['বর্তমান সক্রিয় কর্মী', `${analytics.kpis?.activeEmployees || 0} জন`],
      [],
    ];

    if (reportType === 'sales') {
      rows.push(['পাইকারি ক্রেতা ও শোরুম বিক্রয় বিবরণী']);
      rows.push(['দোকানের নাম', 'প্রোপ্রাইটর / ঠিকানা', 'ফোন', 'ক্রয়কৃত গেঞ্জি (পিস)', 'মোট বিক্রয় মূল্য (৳)', 'জমা / পরিশোধ (৳)', 'বর্তমান বকেয়া (৳)']);
      (analytics.salesByShop || analytics.sales?.items || []).forEach((s: any) => {
        rows.push([
          s.shop_name || s.name,
          `${s.owner_name || ''} - ${s.address || ''}`,
          s.phone || '',
          String(s.total_pieces || s.total_quantity || 0),
          String(s.total_sales || s.net_amount || 0),
          String(s.total_paid || s.paid_amount || 0),
          String(s.current_due || s.due_amount || 0),
        ]);
      });
    } else if (reportType === 'inventory') {
      rows.push(['গেঞ্জি উৎপাদন ও মজুদ ইনভেন্টরি বিবরণী']);
      rows.push(['ক্যাটাগরি', 'কালার', 'সাইজ', 'স্টক পরিমাণ (পিস)', 'দর (৳)', 'মোট মূল্য (৳)']);
      (analytics.inventoryBreakdown || analytics.inventory?.breakdown || []).forEach((i: any) => {
        rows.push([
          i.category,
          i.color,
          i.sizes || '',
          String(i.total_stock || i.stock_quantity || 0),
          String(i.unit_price || 0),
          String(i.total_value || (i.stock_quantity * i.unit_price) || 0),
        ]);
      });
    } else if (reportType === 'expenses') {
      rows.push(['কারখানা ব্যয় ও পরিচালন খরচ বিবরণী']);
      rows.push(['ভাউচার নং', 'তারিখ', 'খাত', 'প্রাপক', 'পরিমাণ (৳)']);
      (analytics.expenses?.items || []).forEach((e: any) => {
        rows.push([
          e.voucher_no || e.expense_no || 'EXP',
          e.date || e.expense_date || '',
          e.category,
          e.paid_to || '',
          String(e.amount || 0),
        ]);
      });
    }

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      rows.map((e) => e.map((val) => `"${(val || '').toString().replace(/"/g, '""')}"`).join(',')).join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `টেক্স_ওয়্যার_রিপোর্ট_${reportType}_${monthYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const company = analytics?.company || {
    company_name_bn: 'টেক্স ওয়্যার অ্যাপারেলস',
    company_name_en: 'Texware Apparels',
    address: 'কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর',
    phone: '০১৭১১-২৩৪৫৬৭',
  };

  const kpis = {
    totalProductionPieces: analytics?.kpis?.totalProductionPieces || analytics?.kpis?.producedPieces || 0,
    totalSales: analytics?.kpis?.totalSales || 0,
    totalExpenses: analytics?.kpis?.totalExpenses || 0,
    totalSalaryPaid: analytics?.kpis?.totalSalaryPaid || analytics?.payroll?.summary?.total_paid || 0,
    totalDue: analytics?.kpis?.totalDue || analytics?.kpis?.marketDues || 0,
    netOperatingProfit: analytics?.kpis?.netOperatingProfit || 0,
    attendanceRate: analytics?.kpis?.attendanceRate || 0,
    activeEmployees: analytics?.kpis?.activeEmployees || 0,
  };

  return (
    <div className="space-y-5 pb-12 font-['Hind_Siliguri',sans-serif]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <BarChart3 className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              ব্যবসায়িক রিপোর্ট ও অডিট সেন্টার (Reports & Analytics)
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            টেক্স ওয়্যার অ্যাপারেলস • কারখানা উৎপাদন, পাইকারি বিক্রয়, বেতন ও খরচের পূর্ণাঙ্গ অডিট প্রিন্ট ও ব্যবস্থাপনা
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => fetchAnalytics(monthYear)}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            title="রিফ্রেশ"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>CSV এক্সপোর্ট</span>
          </button>

          <button
            onClick={handleQuickPrint}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
            title="বর্তমান ট্যাব রিপোর্ট সরাসরি প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4 text-emerald-600" />
            <span>তাত্ক্ষণিক প্রিন্ট</span>
          </button>

          <button
            onClick={handleOpenPrintModal}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs hover:shadow transition-all"
            title="অফিশিয়াল অডিট রিপোর্ট প্রিন্ট ও প্রিভিউ খুলুন"
          >
            <Printer className="w-4 h-4" />
            <span>অফিশিয়াল অডিট প্রিন্ট</span>
          </button>

          {/* Delete Report Option (Requirement 5: রিপোর্ট দেখা যাবে এবং প্রিন্ট ও ডিলিট করা যাবে) */}
          <button
            onClick={() => setIsDeleteModalOpen(true)}
            className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200/80 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
            title="এই মাসের রিপোর্ট রেকর্ড ডিলিট করুন"
          >
            <Trash2 className="w-4 h-4 text-rose-600" />
            <span>রিপোর্ট ডাটা মুছুন</span>
          </button>
        </div>
      </div>

      {/* Report Switcher & Month Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200/80 text-xs shadow-xs">
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setReportType('sales')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              reportType === 'sales'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            পাইকারি বিক্রয় রিপোর্ট
          </button>
          <button
            onClick={() => setReportType('inventory')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              reportType === 'inventory'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            উৎপাদন ও মজুদ ইনভেন্টরি
          </button>
          <button
            onClick={() => setReportType('payroll')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              reportType === 'payroll'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            মাসিক বেতন ও ওভারটাইম
          </button>
          <button
            onClick={() => setReportType('attendance')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              reportType === 'attendance'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            শ্রমিক হাজিরা ও মূল্যায়ন
          </button>
          <button
            onClick={() => setReportType('expenses')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              reportType === 'expenses'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            কারখানা পরিচালন খরচ
          </button>
          <button
            onClick={() => setReportType('dues')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              reportType === 'dues'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            মার্কেট বাকি ও খাতা
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">প্রতিবেদনের মাস:</span>
          <input
            type="month"
            value={monthYear}
            onChange={(e) => setMonthYear(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 text-xs focus:bg-white focus:border-emerald-500 focus:outline-hidden"
          />
        </div>
      </div>

      {loading ? (
        <div className="bg-white rounded-2xl p-16 text-center text-slate-400 border border-slate-200/80 shadow-xs">
          <div className="w-9 h-9 border-2 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto mb-3" />
          রিয়েল-টাইম অডিট ও রিপোর্ট প্রস্তুত হচ্ছে...
        </div>
      ) : (
        /* Printable Report Document Card */
        <div
          id="printable-report"
          className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-300 shadow-xs space-y-6 text-xs text-slate-800"
        >
          {/* Report Company Header */}
          <div className="text-center border-b pb-4 border-slate-200">
            <h2 className="text-xl font-bold text-slate-900">
              {company.company_name_bn || 'টেক্স ওয়্যার অ্যাপারেলস'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {company.address || 'কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর'} • মোবাইল: {company.phone || '০১৭১১-২৩৪৫৬৭'}
            </p>
            <div className="mt-2.5 inline-block px-3.5 py-1 rounded-full bg-slate-100 text-slate-800 font-bold text-xs uppercase tracking-wider border border-slate-200">
              {reportType === 'sales' && 'পাইকারি বিক্রয় ও শোরুম বকেয়া অ্যানালিটিক্স রিপোর্ট'}
              {reportType === 'inventory' && 'গেঞ্জি উৎপাদন আউটপুট ও বর্তমান স্টক বিবরণী'}
              {reportType === 'payroll' && 'শ্রমিক-কর্মচারীদের মাসিক বেতন ও ওভারটাইম শিট রিপোর্ট'}
              {reportType === 'attendance' && 'কারখানা কর্মী মাসিক হাজিরা ও মূল্যায়ন'}
              {reportType === 'expenses' && 'কারখানা ব্যয় ও পরিচালন খরচ লেজার রিপোর্ট'}
              {reportType === 'dues' && 'মার্কেট বাকি ও শোরুম পার্টি লেজার বিবরণী'}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              প্রতিবেদনের সময়কাল: <strong className="text-slate-700">{monthYear}</strong> • প্রস্তুতের তারিখ:{' '}
              {new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>

          {/* Highlight KPI Matrix */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 block">মাসের মোট উৎপাদন</span>
              <span className="text-xl font-black text-slate-900 font-mono mt-0.5 block">
                {kpis.totalProductionPieces.toLocaleString('bn-BD')} পিস
              </span>
              <span className="text-[10px] text-slate-500 block mt-1">কারখানা আউটপুট</span>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 block">মোট পাইকারি বিক্রয়</span>
              <span className="text-xl font-black text-emerald-700 font-mono mt-0.5 block">
                {formatTk(kpis.totalSales)}
              </span>
              <span className="text-[10px] text-emerald-600 block mt-1">বিক্রয় চালান ও মেমো</span>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 block">মোট পরিচালন খরচ</span>
              <span className="text-xl font-black text-rose-700 font-mono mt-0.5 block">
                {formatTk(kpis.totalExpenses)}
              </span>
              <span className="text-[10px] text-slate-400 block mt-1">ফেব্রিক, বেতন ও ইউটিলিটি</span>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500 block">মার্কেটে বর্তমান বকেয়া</span>
              <span className="text-xl font-black text-amber-700 font-mono mt-0.5 block">
                {formatTk(kpis.totalDue)}
              </span>
              <span className="text-[10px] text-amber-600 block mt-1">শোরুম ও পাইকারি খাতা</span>
            </div>
          </div>

          {/* Secondary KPI Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 text-slate-700">
            <div>
              <span className="text-[11px] text-slate-500">নিট পরিচালন মুনাফা (বিক্রয় - খরচ):</span>
              <div className="text-sm font-bold font-mono text-emerald-800">
                {formatTk(kpis.netOperatingProfit)}
              </div>
            </div>
            <div>
              <span className="text-[11px] text-slate-500">শ্রমিক উপস্থিতি হার:</span>
              <div className="text-sm font-bold font-mono text-slate-800">
                {kpis.attendanceRate}% ({kpis.activeEmployees} জন সক্রিয় কর্মী)
              </div>
            </div>
            <div>
              <span className="text-[11px] text-slate-500">পরিশোধিত বেতন (চলতি মাস):</span>
              <div className="text-sm font-bold font-mono text-slate-800">
                {formatTk(kpis.totalSalaryPaid)}
              </div>
            </div>
          </div>

          {/* TAB 1: SALES BREAKDOWN */}
          {reportType === 'sales' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-sm border-l-4 border-emerald-600 pl-2">
                  পাইকারি ক্রেতা ও শোরুম বিক্রয় বিবরণী
                </h4>
                <span className="text-xs text-slate-500 font-medium">
                  মোট দোকান: {(analytics?.salesByShop || []).length} টি
                </span>
              </div>

              {(analytics?.salesByShop || []).length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500">
                  নির্বাচিত মাসে ({monthYear}) কোনো পাইকারি বিক্রয়ের রেকর্ড পাওয়া যায়নি।
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">দোকানের নাম</th>
                        <th className="py-2.5 px-3">ঠিকানা ও প্রোপ্রাইটর</th>
                        <th className="py-2.5 px-3">ফোন নম্বর</th>
                        <th className="py-2.5 px-3 text-right">ক্রয়কৃত গেঞ্জি</th>
                        <th className="py-2.5 px-3 text-right">মোট বিক্রয় মূল্য</th>
                        <th className="py-2.5 px-3 text-right">পরিশোধ</th>
                        <th className="py-2.5 px-3 text-right">বর্তমান বকেয়া (Due)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(analytics?.salesByShop || []).map((shop: any) => (
                        <tr key={shop.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-bold text-slate-800">{shop.shop_name}</td>
                          <td className="py-2.5 px-3 text-slate-600">
                            {shop.address || '—'}{' '}
                            {shop.owner_name ? `(${shop.owner_name})` : ''}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-600">{shop.phone || '—'}</td>
                          <td className="py-2.5 px-3 text-right font-mono font-semibold">
                            {(shop.total_pieces || 0).toLocaleString('bn-BD')} পিস
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            {formatTk(shop.total_sales)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-emerald-700 font-semibold">
                            {formatTk(shop.total_paid)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-amber-700">
                            {shop.current_due > 0 ? formatTk(shop.current_due) : '৳ ০ (পরিশোধিত)'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: INVENTORY BREAKDOWN */}
          {reportType === 'inventory' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-sm border-l-4 border-emerald-600 pl-2">
                  গেঞ্জি উৎপাদন ও মজুদ ইনভেন্টরি বিশ্লেষণ
                </h4>
                <span className="text-xs text-slate-500 font-medium">
                  মোট আইটেম: {(analytics?.inventoryBreakdown || []).length} টি
                </span>
              </div>

              {(analytics?.inventoryBreakdown || []).length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500">
                  ইনভেন্টরিতে কোনো স্টক বা উৎপাদনের ডাটা পাওয়া যায়নি।
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">গেঞ্জির ক্যাটাগরি</th>
                        <th className="py-2.5 px-3">কালার</th>
                        <th className="py-2.5 px-3">সাইজসমূহ (S, M, L, XL, XXL)</th>
                        <th className="py-2.5 px-3 text-right">বর্তমান রেডি স্টক</th>
                        <th className="py-2.5 px-3 text-right">পাইকারি দর</th>
                        <th className="py-2.5 px-3 text-right">মোট স্টক মূল্য</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(analytics?.inventoryBreakdown || []).map((item: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-bold text-slate-800">{item.category}</td>
                          <td className="py-2.5 px-3 font-medium text-slate-700">{item.color}</td>
                          <td className="py-2.5 px-3 font-mono text-slate-600">{item.sizes || '—'}</td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            {(item.total_stock || 0).toLocaleString('bn-BD')} পিস
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                            ৳ {item.unit_price || item.selling_price || 0}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                            {formatTk(item.total_value || ((item.total_stock || 0) * (item.unit_price || item.selling_price || 0)))}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PAYROLL BREAKDOWN */}
          {reportType === 'payroll' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-sm border-l-4 border-emerald-600 pl-2">
                  বিভাগভিত্তিক বেতন ও ওভারটাইম শিট
                </h4>
                <span className="text-xs text-slate-500 font-medium">
                  মোট সেকশন: {(analytics?.payrollBreakdown || []).length} টি
                </span>
              </div>

              {(analytics?.payrollBreakdown || []).length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500">
                  নির্বাচিত মাসের ({monthYear}) কোনো বেতন শিট রেকর্ড পাওয়া যায়নি।
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">কারখানা সেকশন</th>
                        <th className="py-2.5 px-3 text-center">কর্মী সংখ্যা</th>
                        <th className="py-2.5 px-3 text-right">ওভারটাইম (ঘণ্টা)</th>
                        <th className="py-2.5 px-3 text-right">মোট প্রদেয় বেতন</th>
                        <th className="py-2.5 px-3 text-right">পরিশোধিত বেতন</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(analytics?.payrollBreakdown || []).map((p: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-bold text-slate-800">{p.department}</td>
                          <td className="py-2.5 px-3 text-center font-mono">
                            {p.employee_count} জন
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono">
                            {p.total_overtime_hours} ঘণ্টা
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            {formatTk(p.total_payable)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                            {formatTk(p.total_paid)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ATTENDANCE BREAKDOWN */}
          {reportType === 'attendance' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-sm border-l-4 border-emerald-600 pl-2">
                  কারখানা কর্মী মাসিক হাজিরা ও বিলম্ব মূল্যায়ন
                </h4>
                <span className="text-xs text-slate-500 font-medium">
                  মোট সেকশন: {(analytics?.attendanceBreakdown || []).length} টি
                </span>
              </div>

              {(analytics?.attendanceBreakdown || []).length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500">
                  নির্বাচিত মাসে ({monthYear}) কোনো হাজিরা রেকর্ড পাওয়া যায়নি।
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">কারখানা সেকশন</th>
                        <th className="py-2.5 px-3 text-center">কর্মী সংখ্যা</th>
                        <th className="py-2.5 px-3 text-center">উপস্থিত দিন</th>
                        <th className="py-2.5 px-3 text-center">দেরিতে আগমন</th>
                        <th className="py-2.5 px-3 text-center">অনুপস্থিত দিন</th>
                        <th className="py-2.5 px-3 text-right">উপস্থিতি হার</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(analytics?.attendanceBreakdown || []).map((a: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-bold text-slate-800">{a.department}</td>
                          <td className="py-2.5 px-3 text-center font-mono">{a.employee_count} জন</td>
                          <td className="py-2.5 px-3 text-center font-mono text-emerald-700 font-bold">
                            {a.present_count}
                          </td>
                          <td className="py-2.5 px-3 text-center font-mono text-amber-700">
                            {a.late_count}
                          </td>
                          <td className="py-2.5 px-3 text-center font-mono text-rose-700">
                            {a.absent_count}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            {a.attendance_rate}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: EXPENSES BREAKDOWN */}
          {reportType === 'expenses' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-sm border-l-4 border-rose-600 pl-2">
                  কারখানা ব্যয় ও পরিচালন খরচ লেজার
                </h4>
                <span className="text-xs text-slate-500 font-medium">
                  মোট খরচ: {formatTk(kpis.totalExpenses)}
                </span>
              </div>

              {(analytics?.expenses?.items || []).length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500">
                  নির্বাচিত মাসে ({monthYear}) কোনো খরচের ভাউচার রেকর্ড নেই।
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">ভাউচার</th>
                        <th className="py-2.5 px-3">তারিখ</th>
                        <th className="py-2.5 px-3">খাত (Head)</th>
                        <th className="py-2.5 px-3">প্রাপক / ব্যক্তি</th>
                        <th className="py-2.5 px-3 text-right">পরিমাণ (টাকা)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(analytics?.expenses?.items || []).map((e: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-800">{e.voucher_no || e.expense_no || 'EXP'}</td>
                          <td className="py-2.5 px-3 text-slate-500">{e.date || e.expense_date}</td>
                          <td className="py-2.5 px-3 font-semibold text-slate-700">{e.category}</td>
                          <td className="py-2.5 px-3 text-slate-600">{e.paid_to || 'কারখানা'}</td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                            {formatTk(e.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: DUES BREAKDOWN */}
          {reportType === 'dues' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-sm border-l-4 border-amber-600 pl-2">
                  মার্কেট বাকি ও শোরুম বকেয়া খাতা
                </h4>
                <span className="text-xs text-slate-500 font-medium">
                  মোট মার্কেট বাকি: {formatTk(kpis.totalDue)}
                </span>
              </div>

              {shops.filter(s => (s.current_due || 0) > 0).length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-emerald-600 font-semibold">
                  আলহামদুলিল্লাহ, শোরুম বা পার্টিদের নিকট কোনো বকেয়া নেই!
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">দোকানের নাম</th>
                        <th className="py-2.5 px-3">মালিকের নাম</th>
                        <th className="py-2.5 px-3">ফোন নম্বর</th>
                        <th className="py-2.5 px-3 text-right">মোট ক্রয়</th>
                        <th className="py-2.5 px-3 text-right">মোট জমা</th>
                        <th className="py-2.5 px-3 text-right">বর্তমান বাকি</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {shops
                        .filter(s => (s.current_due || 0) > 0)
                        .map((s: any) => (
                          <tr key={s.id} className="hover:bg-slate-50">
                            <td className="py-2.5 px-3 font-bold text-slate-800">{s.name}</td>
                            <td className="py-2.5 px-3 text-slate-600">{s.owner_name || '—'}</td>
                            <td className="py-2.5 px-3 font-mono text-slate-600">{s.phone || '—'}</td>
                            <td className="py-2.5 px-3 text-right font-mono">
                              {formatTk(s.total_purchased)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-emerald-700">
                              {formatTk(s.total_paid)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-amber-700">
                              {formatTk(s.current_due)}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Authorized Factory Audit Signatures */}
          <div className="pt-10 grid grid-cols-3 gap-6 text-center text-[11px] text-slate-500">
            <div>
              <div className="border-t border-slate-400 w-36 mx-auto mb-1" />
              হিসাব নিরীক্ষক (Auditor)
            </div>
            <div>
              <div className="border-t border-slate-400 w-36 mx-auto mb-1" />
              ফ্যাক্টরি ম্যানেজার
            </div>
            <div>
              <div className="border-t border-slate-400 w-36 mx-auto mb-1" />
              ব্যবস্থাপনা পরিচালক (MD)
            </div>
          </div>
        </div>
      )}

      {/* Delete Report Data Confirmation Modal (Requirement 5: রিপোর্ট ডিলিট করা যাবে) */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="রিপোর্ট রেকর্ড ও হিস্ট্রি মুছে ফেলার নিশ্চয়তা"
        subtitle={`টেক্স ওয়্যার অ্যাপারেলস • ${monthYear} মাসের নির্দিষ্ট অথবা সকল রিপোর্ট ডাটা মুছুন`}
        maxWidth="sm"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 space-y-2">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <span>সতর্কবার্তা: ডাটা স্থায়ীভাবে মুছে যাবে!</span>
            </div>
            <p className="text-[11px] text-rose-700">
              নির্বাচিত মাসের হিসাব বা ভুল রেকর্ড পুনরায় নতুন করে শুরু করতে চাইলে সংশ্লিষ্ট রিপোর্টটি মুছে ফেলতে পারেন।
            </p>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">মুছে ফেলার ক্যাটাগরি বেছে নিন:</label>
            <select
              value={deleteCategory}
              onChange={(e) => setDeleteCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800"
            >
              <option value="payroll">শুধুমাত্র {monthYear} মাসের বেতন শিট রেকর্ড</option>
              <option value="attendance">শুধুমাত্র {monthYear} মাসের হাজিরা রেকর্ড</option>
              <option value="production">শুধুমাত্র {monthYear} মাসের উৎপাদন রেকর্ড</option>
              <option value="expenses">শুধুমাত্র {monthYear} মাসের কারখানা খরচ রেকর্ড</option>
              <option value="sales">শুধুমাত্র {monthYear} মাসের পাইকারি বিক্রয় চালান রেকর্ড</option>
              <option value="all">সবকিছু ({monthYear} মাসের সকল রিপোর্ট রেকর্ড)</option>
            </select>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              onClick={() => setIsDeleteModalOpen(false)}
              disabled={deleting}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              onClick={handleDeleteReportData}
              disabled={deleting}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs disabled:opacity-50"
            >
              {deleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, মুছে ফেলুন'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Official Audit & Report Print Modal with Live Preview */}
      <ReportPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        analytics={analytics}
        shops={shops}
        reportType={reportType}
        monthYear={monthYear}
      />
    </div>
  );
};
