import React, { useState, useEffect } from 'react';
import {
  CalendarCheck,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileSpreadsheet,
  Plus,
  Printer,
  ShieldCheck,
  ArrowRight,
  Filter,
  Save,
  Check,
  Users,
  Eye,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { api } from '../../services/api';
import { AttendanceRecord, LeaveRecord, GatePass } from '../../types';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { AttendancePrintSheetModal } from './AttendancePrintSheetModal';
import { printElementById } from '../../utils/printDocument';

export const AttendanceView: React.FC = () => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'attendance' | 'leaves' | 'gatepass'>('attendance');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedDept, setSelectedDept] = useState<string>('');
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [isPrintSheetOpen, setIsPrintSheetOpen] = useState(false);

  // Click-to-view detail state
  const [selectedRecordForDetail, setSelectedRecordForDetail] = useState<AttendanceRecord | null>(null);
  const [detailSaving, setDetailSaving] = useState(false);

  // Leave records & Gate passes state
  const [leaves, setLeaves] = useState<LeaveRecord[]>([]);
  const [gatePasses, setGatePasses] = useState<GatePass[]>([]);
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState(false);
  const [isGatePassModalOpen, setIsGatePassModalOpen] = useState(false);
  const [printGatePass, setPrintGatePass] = useState<GatePass | null>(null);

  // Leave Form
  const [leaveForm, setLeaveForm] = useState({
    employee_id: 0,
    leave_type: 'নৈমিত্তিক ছুটি (Casual Leave)',
    start_date: new Date().toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    reason: '',
  });

  // Gate Pass Form
  const [gatePassForm, setGatePassForm] = useState({
    employee_id: 0,
    date: new Date().toISOString().split('T')[0],
    out_time: '14:30',
    expected_return_time: '16:00',
    reason: 'জরুরি পারিবারিক প্রয়োজনে',
  });

  const fetchAttendance = async () => {
    setLoading(true);
    try {
      const data = await api.getAttendance(selectedDate, selectedDept || undefined);
      // Strictly exclude any worker who has resigned
      const activeData = data.filter((r: any) => r.status !== 'resigned' && r.employee_status !== 'resigned');
      setRecords(activeData);
    } catch (err: any) {
      showToast(err.message || 'হাজিরা তথ্য লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteRecord = async (rec: AttendanceRecord) => {
    if (!window.confirm(`${rec.full_name}-এর ${selectedDate} তারিখের হাজিরা রেকর্ড বাদ দিতে চান?`)) {
      return;
    }
    try {
      if (rec.attendance_id) {
        await api.deleteAttendanceRecord(rec.attendance_id);
      } else {
        await api.clearAttendanceDay(selectedDate, rec.employee_id);
      }
      showToast(`${rec.full_name}-এর হাজিরা রেকর্ড সফলভাবে বাদ দেওয়া হয়েছে`, 'success');
      if (selectedRecordForDetail?.employee_id === rec.employee_id) {
        setSelectedRecordForDetail(null);
      }
      fetchAttendance();
    } catch (err: any) {
      showToast(err.message || 'হাজিরা রেকর্ড বাদ দেওয়া যায়নি', 'error');
    }
  };

  const handleSaveSingleRecord = async (rec: AttendanceRecord) => {
    setDetailSaving(true);
    try {
      await api.markAttendance({
        employee_id: rec.employee_id,
        date: selectedDate,
        status: rec.status || 'present',
        in_time: rec.in_time || '08:00',
        out_time: rec.out_time || '17:00',
        ot_hours: Number(rec.ot_hours) || 0,
        notes: rec.notes || ''
      });
      showToast(`${rec.full_name}-এর হাজিরা সফলভাবে সংরক্ষণ করা হয়েছে`, 'success');
      setSelectedRecordForDetail(null);
      fetchAttendance();
    } catch (err: any) {
      showToast(err.message || 'হাজিরা সংরক্ষণ করা যায়নি', 'error');
    } finally {
      setDetailSaving(false);
    }
  };

  const fetchLeavesAndPasses = async () => {
    try {
      const [lData, gData] = await Promise.all([api.getLeaves(), api.getGatePasses()]);
      setLeaves(lData);
      setGatePasses(gData);
    } catch (err: any) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAttendance();
  }, [selectedDate, selectedDept]);

  useEffect(() => {
    fetchLeavesAndPasses();
  }, []);

  // One-click mark all as Present
  const handleMarkAllPresent = () => {
    setRecords((prev) =>
      prev.map((r) => ({
        ...r,
        status: 'present',
        in_time: r.in_time || '08:00',
        out_time: r.out_time || '17:00',
        ot_hours: r.ot_hours || 0,
      }))
    );
    showToast('সবাইকে উপস্থিত সেট করা হয়েছে। ব্যতিক্রম থাকলে পরিবর্তন করে সংরক্ষণ করুন।', 'info');
  };

  // Update specific row locally
  const handleUpdateRecord = (empId: number, field: keyof AttendanceRecord, value: any) => {
    setRecords((prev) =>
      prev.map((r) => (r.employee_id === empId ? { ...r, [field]: value } : r))
    );
  };

  // Save all modified attendance
  const handleSaveAll = async () => {
    setSaving(true);
    try {
      const items = records.map((r) => ({
        employee_id: r.employee_id,
        status: r.status || 'present',
        in_time: r.in_time || '08:00',
        out_time: r.out_time || '17:00',
        ot_hours: Number(r.ot_hours) || 0,
        notes: r.notes || '',
      }));

      await api.markBulkAttendance({
        date: selectedDate,
        items,
      });

      showToast('আজকের হাজিরা সফলভাবে ডাটাবেজে সংরক্ষণ করা হয়েছে!', 'success');
      fetchAttendance();
    } catch (err: any) {
      showToast(err.message || 'হাজিরা সংরক্ষণ ব্যর্থ হয়েছে', 'error');
    } finally {
      setSaving(false);
    }
  };

  // Submit Leave
  const handleLeaveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveForm.employee_id) {
      showToast('অনুগ্রহ করে কর্মী নির্বাচন করুন', 'error');
      return;
    }
    try {
      await api.createLeave(leaveForm);
      showToast('ছুটির আবেদন সফলভাবে অনুমোদন ও সংরক্ষণ করা হয়েছে', 'success');
      setIsLeaveModalOpen(false);
      fetchLeavesAndPasses();
    } catch (err: any) {
      showToast(err.message || 'ছুটি সংরক্ষণ করা যায়নি', 'error');
    }
  };

  // Submit Gate Pass
  const handleGatePassSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!gatePassForm.employee_id) {
      showToast('কর্মী নির্বাচন করুন', 'error');
      return;
    }
    try {
      const res = await api.createGatePass(gatePassForm);
      showToast(`গেট পাস তৈরি হয়েছে: ${res.pass_no}`, 'success');
      setIsGatePassModalOpen(false);
      fetchLeavesAndPasses();
    } catch (err: any) {
      showToast(err.message || 'গেট পাস তৈরি করা যায়নি', 'error');
    }
  };

  const handleReturnGatePass = async (id: number) => {
    const time = prompt('ফেরার সময় লিখুন (যেমন 16:30):', '16:30');
    if (!time) return;
    try {
      await api.returnGatePass(id, { actual_return_time: time });
      showToast('গেট পাস সফলভাবে সমাপ্ত রেকর্ড করা হয়েছে', 'success');
      fetchLeavesAndPasses();
    } catch (err: any) {
      showToast(err.message || 'ব্যর্থ হয়েছে', 'error');
    }
  };

  // Calculate summary counts
  const presentCount = records.filter((r) => r.status === 'present').length;
  const absentCount = records.filter((r) => r.status === 'absent').length;
  const leaveCount = records.filter((r) => r.status === 'leave').length;
  const lateCount = records.filter((r) => r.status === 'late').length;
  const totalOt = records.reduce((sum, r) => sum + (Number(r.ot_hours) || 0), 0);

  return (
    <div className="space-y-5 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
              <CalendarCheck className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              দৈনিক হাজিরা, ওভারটাইম, ছুটি ও গেট পাস
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            কারখানার দৈনিক উপস্থিতি, ইন/আউট টাইম, ওভারটাইম হিসাব ও জরুরি গেট পাস নিয়ন্ত্রণ
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {activeTab === 'attendance' && (
            <>
              <button
                onClick={() => setIsPrintSheetOpen(true)}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                title="প্রতিদিনের সকল শ্রমিকের হাজিরা এক জায়গায় প্রিন্ট করুন"
              >
                <Printer className="w-4 h-4 text-emerald-400" />
                <span>হাজিরা শীট প্রিন্ট</span>
              </button>
              <button
                onClick={handleMarkAllPresent}
                className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                সবাইকে উপস্থিত মার্ক
              </button>
              <button
                onClick={handleSaveAll}
                disabled={saving}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs shadow-emerald-600/20 disabled:opacity-60 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'হাজিরা সংরক্ষণ করুন'}</span>
              </button>
            </>
          )}

          {activeTab === 'leaves' && (
            <button
              onClick={() => setIsLeaveModalOpen(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs shadow-emerald-600/20"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন ছুটি মঞ্জুর করুন</span>
            </button>
          )}

          {activeTab === 'gatepass' && (
            <button
              onClick={() => setIsGatePassModalOpen(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs shadow-emerald-600/20"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন গেট পাস ইস্যু</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Tabs */}
      <div className="flex border-b border-slate-200 text-xs font-semibold gap-2">
        <button
          onClick={() => setActiveTab('attendance')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors ${
            activeTab === 'attendance'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          দৈনিক হাজিরা শীট
        </button>
        <button
          onClick={() => setActiveTab('leaves')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors ${
            activeTab === 'leaves'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          ছুটির তালিকা ({leaves.length})
        </button>
        <button
          onClick={() => setActiveTab('gatepass')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors ${
            activeTab === 'gatepass'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          কারখানা গেট পাস ({gatePasses.length})
        </button>
      </div>

      {/* Tab 1: Attendance Register */}
      {activeTab === 'attendance' && (
        <div className="space-y-4">
          {/* Filter & Date selector */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">তারিখ নির্বাচন</label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">বিভাগ ফিল্টার</label>
                <select
                  value={selectedDept}
                  onChange={(e) => setSelectedDept(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                >
                  <option value="">সকল কারখানা বিভাগ</option>
                  <option value="কাটিং (Cutting)">কাটিং (Cutting)</option>
                  <option value="সুইং (Sewing)">সুইং (Sewing)</option>
                  <option value="ফিনিশিং (Finishing)">ফিনিশিং (Finishing)</option>
                  <option value="কোয়ালিটি কন্ট্রোল (QC)">কোয়ালিটি কন্ট্রোল (QC)</option>
                  <option value="আয়রনিং (Ironing)">আয়রনিং (Ironing)</option>
                  <option value="প্যাকেজিং (Packaging)">প্যাকেজিং (Packaging)</option>
                </select>
              </div>
            </div>

            {/* Quick stats pills */}
            <div className="flex items-center gap-2 flex-wrap text-xs">
              <span className="px-3 py-1 bg-emerald-50 text-emerald-800 rounded-lg font-bold">
                উপস্থিত: {presentCount} জন
              </span>
              <span className="px-3 py-1 bg-rose-50 text-rose-800 rounded-lg font-bold">
                অনুপস্থিত: {absentCount} জন
              </span>
              <span className="px-3 py-1 bg-amber-50 text-amber-800 rounded-lg font-bold">
                ছুটি: {leaveCount} জন
              </span>
              <span className="px-3 py-1 bg-blue-50 text-blue-800 rounded-lg font-bold">
                মোট ওটি: {totalOt} ঘণ্টা
              </span>
              <button
                onClick={() => setIsPrintSheetOpen(true)}
                className="ml-auto px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                title="আজকের সকল শ্রমিকের হাজিরা এক পেজে প্রিন্ট করুন"
              >
                <Printer className="w-3.5 h-3.5 text-slate-600" />
                <span>সকলের হাজিরা এক সাথে প্রিন্ট</span>
              </button>
            </div>
          </div>

          {/* Attendance Table */}
          <div id="printable-attendance-table" className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3.5 px-4">আইডি ও কর্মী নাম</th>
                    <th className="py-3.5 px-4">বিভাগ ও পদবী</th>
                    <th className="py-3.5 px-4">উপস্থিতি স্ট্যাটাস</th>
                    <th className="py-3.5 px-4">প্রবেশ (In)</th>
                    <th className="py-3.5 px-4">প্রস্থান (Out)</th>
                    <th className="py-3.5 px-4 text-center">ওভারটাইম (ঘণ্টা)</th>
                    <th className="py-3.5 px-4">নোট / মন্তব্য</th>
                    <th className="py-3.5 px-4 text-center">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loading ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        <div className="w-8 h-8 border-2 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto mb-2" />
                        হাজিরা তালিকা লোড হচ্ছে...
                      </td>
                    </tr>
                  ) : records.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        কোনো কর্মী পাওয়া যায়নি
                      </td>
                    </tr>
                  ) : (
                    records.map((rec) => (
                      <tr key={rec.employee_id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => setSelectedRecordForDetail(rec)}
                            className="text-left group cursor-pointer"
                            title="বিস্তারিত দেখতে ক্লিক করুন"
                          >
                            <div className="font-bold text-slate-800 group-hover:text-emerald-700 transition-colors flex items-center gap-1.5">
                              <span>{rec.full_name}</span>
                              <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded font-normal group-hover:bg-emerald-50 group-hover:text-emerald-700">বিস্তারিত</span>
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">{rec.employee_code}</div>
                          </button>
                        </td>

                        <td className="py-3 px-4">
                          <div className="text-slate-700 font-medium">{rec.designation}</div>
                          <div className="text-[11px] text-slate-400">{rec.department}</div>
                        </td>

                        {/* Status Select */}
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleUpdateRecord(rec.employee_id, 'status', 'present')}
                              className={`px-2 py-1 rounded text-[11px] font-bold cursor-pointer transition-all ${
                                rec.status === 'present'
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              উপস্থিত
                            </button>
                            <button
                              type="button"
                              onClick={() => handleUpdateRecord(rec.employee_id, 'status', 'absent')}
                              className={`px-2 py-1 rounded text-[11px] font-bold cursor-pointer transition-all ${
                                rec.status === 'absent'
                                  ? 'bg-rose-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              অনুপস্থিত
                            </button>
                            <button
                              type="button"
                              onClick={() => handleUpdateRecord(rec.employee_id, 'status', 'leave')}
                              className={`px-2 py-1 rounded text-[11px] font-bold cursor-pointer transition-all ${
                                rec.status === 'leave'
                                  ? 'bg-amber-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              ছুটি
                            </button>
                            <button
                              type="button"
                              onClick={() => handleUpdateRecord(rec.employee_id, 'status', 'late')}
                              className={`px-2 py-1 rounded text-[11px] font-bold cursor-pointer transition-all ${
                                rec.status === 'late'
                                  ? 'bg-blue-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              দেরি
                            </button>
                          </div>
                        </td>

                        {/* In Time */}
                        <td className="py-3 px-4">
                          <input
                            type="text"
                            value={rec.in_time || ''}
                            onChange={(e) => handleUpdateRecord(rec.employee_id, 'in_time', e.target.value)}
                            placeholder="08:00"
                            className="w-20 px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                          />
                        </td>

                        {/* Out Time */}
                        <td className="py-3 px-4">
                          <input
                            type="text"
                            value={rec.out_time || ''}
                            onChange={(e) => handleUpdateRecord(rec.employee_id, 'out_time', e.target.value)}
                            placeholder="17:00"
                            className="w-20 px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                          />
                        </td>

                        {/* Overtime Hours */}
                        <td className="py-3 px-4 text-center">
                          <input
                            type="number"
                            min={0}
                            max={12}
                            step={0.5}
                            value={rec.ot_hours ?? 0}
                            onChange={(e) => handleUpdateRecord(rec.employee_id, 'ot_hours', Number(e.target.value))}
                            className="w-16 px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs text-center font-bold"
                          />
                        </td>

                        {/* Notes */}
                        <td className="py-3 px-4">
                          <input
                            type="text"
                            value={rec.notes || ''}
                            onChange={(e) => handleUpdateRecord(rec.employee_id, 'notes', e.target.value)}
                            placeholder="মন্তব্য..."
                            className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        </td>

                        {/* Action buttons */}
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setSelectedRecordForDetail(rec)}
                              className="p-1.5 hover:bg-emerald-50 text-slate-500 hover:text-emerald-700 rounded-lg transition-colors cursor-pointer"
                              title="বিস্তারিত দেখুন ও সম্পাদন করুন"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteRecord(rec)}
                              className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                              title="আজকের হাজিরা রেকর্ড বাদ দিন"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Detail & Edit Modal for an Employee's Attendance Record */}
      {selectedRecordForDetail && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedRecordForDetail(null)}
          title={`হাজিরা বিস্তারিত — ${selectedRecordForDetail.full_name}`}
          size="md"
        >
          <div className="space-y-4">
            {/* Employee Quick Banner */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-sm font-bold text-slate-800">{selectedRecordForDetail.full_name}</div>
                <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                  <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200">{selectedRecordForDetail.employee_code}</span>
                  <span>{selectedRecordForDetail.department}</span>
                  <span>•</span>
                  <span>{selectedRecordForDetail.designation}</span>
                </div>
              </div>
              <div className="text-right text-xs">
                <div className="text-slate-400">মূল বেতন</div>
                <div className="font-bold text-slate-700">৳{(selectedRecordForDetail.basic_salary || 0).toLocaleString('bn-BD')}</div>
                <div className="text-[10px] text-slate-400">ওটি রেট: ৳{Number(selectedRecordForDetail.overtime_rate || 0).toFixed(1)}/ঘণ্টা</div>
              </div>
            </div>

            {/* Attendance Status Picker */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                উপস্থিতি স্ট্যাটাস (তারিখ: {selectedDate})
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'present', label: 'উপস্থিত', color: 'bg-emerald-600 text-white' },
                  { id: 'absent', label: 'অনুপস্থিত', color: 'bg-rose-600 text-white' },
                  { id: 'leave', label: 'ছুটি', color: 'bg-amber-600 text-white' },
                  { id: 'late', label: 'দেরি', color: 'bg-blue-600 text-white' },
                ].map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() =>
                      setSelectedRecordForDetail({
                        ...selectedRecordForDetail,
                        status: st.id as any,
                      })
                    }
                    className={`py-2 px-3 rounded-xl text-xs font-bold text-center cursor-pointer transition-all ${
                      selectedRecordForDetail.status === st.id
                        ? `${st.color} shadow-xs`
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Timing and Overtime */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">প্রবেশের সময় (In)</label>
                <input
                  type="text"
                  value={selectedRecordForDetail.in_time || ''}
                  onChange={(e) =>
                    setSelectedRecordForDetail({
                      ...selectedRecordForDetail,
                      in_time: e.target.value,
                    })
                  }
                  placeholder="08:00"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">প্রস্থানের সময় (Out)</label>
                <input
                  type="text"
                  value={selectedRecordForDetail.out_time || ''}
                  onChange={(e) =>
                    setSelectedRecordForDetail({
                      ...selectedRecordForDetail,
                      out_time: e.target.value,
                    })
                  }
                  placeholder="17:00"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ওভারটাইম (ঘণ্টা)</label>
                <input
                  type="number"
                  min={0}
                  max={12}
                  step={0.5}
                  value={selectedRecordForDetail.ot_hours ?? 0}
                  onChange={(e) =>
                    setSelectedRecordForDetail({
                      ...selectedRecordForDetail,
                      ot_hours: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-center"
                />
              </div>
            </div>

            {/* Earnings Calculation Card */}
            <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3 text-xs space-y-1">
              <div className="font-bold text-emerald-900 mb-1 flex items-center justify-between">
                <span>আজকের মজুরি ও ওটি হিসাব (আনুমানিক)</span>
                <span className="text-[11px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-semibold">
                  {selectedRecordForDetail.status === 'present' || selectedRecordForDetail.status === 'late' ? 'কর্মদিবস কার্যকর' : 'অনুপস্থিত/ছুটি'}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>দৈনিক মৌলিক বেতন (Basic / 26):</span>
                <span className="font-semibold text-slate-800">
                  ৳{Math.round((Number(selectedRecordForDetail.basic_salary) || 0) / 26).toLocaleString('bn-BD')}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>ওভারটাইম বিল ({selectedRecordForDetail.ot_hours || 0} ঘণ্টা × ৳{Number(selectedRecordForDetail.overtime_rate || 0).toFixed(1)}):</span>
                <span className="font-semibold text-emerald-800">
                  +৳{Math.round((Number(selectedRecordForDetail.ot_hours) || 0) * (Number(selectedRecordForDetail.overtime_rate) || 0)).toLocaleString('bn-BD')}
                </span>
              </div>
              <div className="border-t border-emerald-200 pt-1 flex justify-between font-bold text-emerald-950">
                <span>আজকের মোট উপার্জিত পাওনা:</span>
                <span>
                  ৳{
                    selectedRecordForDetail.status === 'present' || selectedRecordForDetail.status === 'late'
                      ? (Math.round((Number(selectedRecordForDetail.basic_salary) || 0) / 26) + Math.round((Number(selectedRecordForDetail.ot_hours) || 0) * (Number(selectedRecordForDetail.overtime_rate) || 0))).toLocaleString('bn-BD')
                      : Math.round((Number(selectedRecordForDetail.ot_hours) || 0) * (Number(selectedRecordForDetail.overtime_rate) || 0)).toLocaleString('bn-BD')
                  }
                </span>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">মন্তব্য / বিশেষ নোট</label>
              <textarea
                rows={2}
                value={selectedRecordForDetail.notes || ''}
                onChange={(e) =>
                  setSelectedRecordForDetail({
                    ...selectedRecordForDetail,
                    notes: e.target.value,
                  })
                }
                placeholder="বিলম্বের কারণ বা বিশেষ নির্দেশনা..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
              />
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => handleDeleteRecord(selectedRecordForDetail)}
                className="px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>হাজিরা রেকর্ড বাদ দিন</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedRecordForDetail(null)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-50 cursor-pointer"
                >
                  বন্ধ করুন
                </button>
                <button
                  type="button"
                  disabled={detailSaving}
                  onClick={() => handleSaveSingleRecord(selectedRecordForDetail)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{detailSaving ? 'সংরক্ষণ হচ্ছে...' : 'হালনাগাদ সেভ করুন'}</span>
                </button>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Tab 2: Leaves List */}
      {activeTab === 'leaves' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">কর্মী বিবরণ</th>
                  <th className="py-3.5 px-4">ছুটির ধরন</th>
                  <th className="py-3.5 px-4">সময়সীমা</th>
                  <th className="py-3.5 px-4 text-center">মোট দিন</th>
                  <th className="py-3.5 px-4">ছুটির কারণ</th>
                  <th className="py-3.5 px-4 text-center">অবস্থা</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {leaves.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      কোনো ছুটির আবেদন বা রেকর্ড নেই
                    </td>
                  </tr>
                ) : (
                  leaves.map((l) => (
                    <tr key={l.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-800">{l.full_name}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {l.employee_code} • {l.department}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-700">{l.leave_type}</td>
                      <td className="py-3 px-4 font-mono text-slate-600">
                        {l.start_date} থেকে {l.end_date}
                      </td>
                      <td className="py-3 px-4 text-center font-bold text-slate-800">
                        {l.total_days} দিন
                      </td>
                      <td className="py-3 px-4 text-slate-600">{l.reason}</td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                          মঞ্জুরকৃত (Approved)
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Gate Pass Module */}
      {activeTab === 'gatepass' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">গেট পাস নং</th>
                  <th className="py-3.5 px-4">কর্মী</th>
                  <th className="py-3.5 px-4">তারিখ ও প্রস্থান সময়</th>
                  <th className="py-3.5 px-4">প্রত্যাশিত / প্রকৃত ফেরা</th>
                  <th className="py-3.5 px-4">উদ্দেশ্য / কারণ</th>
                  <th className="py-3.5 px-4 text-center">অবস্থা</th>
                  <th className="py-3.5 px-4 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {gatePasses.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      কোনো গেট পাস পাওয়া যায়নি
                    </td>
                  </tr>
                ) : (
                  gatePasses.map((gp) => (
                    <tr key={gp.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-bold font-mono text-emerald-800">{gp.pass_no}</td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-800">{gp.full_name}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {gp.employee_code} • {gp.department}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-700">{gp.date}</div>
                        <div className="text-[11px] font-mono text-slate-500">বের হয়েছেন: {gp.out_time}</div>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">
                        {gp.actual_return_time ? (
                          <span className="text-emerald-700 font-bold">ফিরেছেন: {gp.actual_return_time}</span>
                        ) : (
                          <span>প্রত্যাশিত: {gp.expected_return_time || '—'}</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-700">{gp.reason}</td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            gp.status === 'returned'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {gp.status === 'returned' ? 'ফিরেছেন' : 'অনুমোদিত / বাইরে'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {gp.status !== 'returned' && (
                            <button
                              onClick={() => handleReturnGatePass(gp.id)}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded text-[10px] font-bold cursor-pointer"
                            >
                              ফেরা মার্ক করুন
                            </button>
                          )}
                          <button
                            onClick={() => setPrintGatePass(gp)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-100 cursor-pointer"
                            title="গেট পাস প্রিন্ট"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Leave Modal */}
      <Modal
        isOpen={isLeaveModalOpen}
        onClose={() => setIsLeaveModalOpen(false)}
        title="নতুন ছুটির আবেদন অনুমোদন"
        subtitle="শ্রমিক বা কর্মচারীর অনুমোদিত ছুটির বিবরণ সংরক্ষণ করুন"
        maxWidth="md"
      >
        <form onSubmit={handleLeaveSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">কর্মী নির্বাচন করুন</label>
            <select
              value={leaveForm.employee_id}
              onChange={(e) => setLeaveForm({ ...leaveForm, employee_id: Number(e.target.value) })}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 font-medium"
            >
              <option value="">কর্মী বেছে নিন...</option>
              {records.map((r) => (
                <option key={r.employee_id} value={r.employee_id}>
                  {r.full_name} ({r.employee_code} - {r.department})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">ছুটির ধরন</label>
            <select
              value={leaveForm.leave_type}
              onChange={(e) => setLeaveForm({ ...leaveForm, leave_type: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
            >
              <option value="নৈমিত্তিক ছুটি (Casual Leave)">নৈমিত্তিক ছুটি (Casual Leave)</option>
              <option value="অসুস্থতাজনিত ছুটি (Sick Leave)">অসুস্থতাজনিত ছুটি (Sick Leave)</option>
              <option value="অর্জিত ছুটি (Earned Leave)">অর্জিত ছুটি (Earned Leave)</option>
              <option value="বিশেষ ছুটি (Special Leave)">বিশেষ ছুটি (Special Leave)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">শুরুর তারিখ</label>
              <input
                type="date"
                value={leaveForm.start_date}
                onChange={(e) => setLeaveForm({ ...leaveForm, start_date: e.target.value })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">শেষের তারিখ</label>
              <input
                type="date"
                value={leaveForm.end_date}
                onChange={(e) => setLeaveForm({ ...leaveForm, end_date: e.target.value })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">ছুটির কারণ</label>
            <textarea
              rows={2}
              value={leaveForm.reason}
              onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
              placeholder="ছুটি মঞ্জুরের কারণ উল্লেখ করুন..."
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsLeaveModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl cursor-pointer"
            >
              ছুটি মঞ্জুর করুন
            </button>
          </div>
        </form>
      </Modal>

      {/* Gate Pass Modal */}
      <Modal
        isOpen={isGatePassModalOpen}
        onClose={() => setIsGatePassModalOpen(false)}
        title="নতুন গেট পাস ইস্যু করুন"
        subtitle="কারখানা প্রাঙ্গণ ত্যাগের অনুমতিপত্র"
        maxWidth="md"
      >
        <form onSubmit={handleGatePassSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">কর্মী নির্বাচন করুন</label>
            <select
              value={gatePassForm.employee_id}
              onChange={(e) => setGatePassForm({ ...gatePassForm, employee_id: Number(e.target.value) })}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            >
              <option value="">কর্মী বেছে নিন...</option>
              {records.map((r) => (
                <option key={r.employee_id} value={r.employee_id}>
                  {r.full_name} ({r.employee_code} - {r.department})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">প্রস্থান সময় (Out Time)</label>
              <input
                type="text"
                value={gatePassForm.out_time}
                onChange={(e) => setGatePassForm({ ...gatePassForm, out_time: e.target.value })}
                placeholder="14:30"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">প্রত্যাশিত ফেরা (Expected Return)</label>
              <input
                type="text"
                value={gatePassForm.expected_return_time}
                onChange={(e) => setGatePassForm({ ...gatePassForm, expected_return_time: e.target.value })}
                placeholder="16:00"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">প্রস্থানের কারণ / কার্যাবলী</label>
            <input
              type="text"
              value={gatePassForm.reason}
              onChange={(e) => setGatePassForm({ ...gatePassForm, reason: e.target.value })}
              required
              placeholder="যেমন: জরুরি পারিবারিক বা অফিসিয়াল কাজ"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsGatePassModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl cursor-pointer"
            >
              গেট পাস ইস্যু করুন
            </button>
          </div>
        </form>
      </Modal>

      {/* Printable Gate Pass View */}
      {printGatePass && (
        <Modal
          isOpen={Boolean(printGatePass)}
          onClose={() => setPrintGatePass(null)}
          title={`কারখানা গেট পাস: ${printGatePass.pass_no}`}
          maxWidth="md"
        >
          <div id="printable-gatepass" className="p-4 border-2 border-dashed border-slate-300 rounded-xl space-y-4 text-xs font-sans bg-slate-50/50">
            <div className="text-center border-b pb-3 border-slate-200">
              <h3 className="font-bold text-base text-slate-900">টেক্স ওয়্যার অ্যাপারেলস</h3>
              <p className="text-[11px] text-slate-500">ফ্যাক্টরি গেট পাস (Factory Exit Permission)</p>
              <div className="mt-1 font-mono font-bold text-xs text-emerald-800">
                পাস নং: {printGatePass.pass_no}
              </div>
            </div>

            <div className="space-y-1.5 text-slate-700">
              <div className="flex justify-between">
                <span className="text-slate-500">কর্মীর নাম:</span>
                <span className="font-bold">{printGatePass.full_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">কর্মী আইডি ও বিভাগ:</span>
                <span className="font-mono">{printGatePass.employee_code} ({printGatePass.department})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">তারিখ:</span>
                <span>{printGatePass.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">প্রস্থান সময়:</span>
                <span className="font-mono font-bold text-rose-700">{printGatePass.out_time}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">প্রত্যাশিত ফেরার সময়:</span>
                <span className="font-mono">{printGatePass.expected_return_time || 'আজ আর ফিরবেন না'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">কারখানা ত্যাগের কারণ:</span>
                <span className="font-medium text-slate-800">{printGatePass.reason}</span>
              </div>
            </div>

            <div className="pt-8 grid grid-cols-2 text-center text-[10px] text-slate-500 border-t border-slate-200">
              <div>
                <div className="border-t border-slate-400 w-28 mx-auto mb-1" />
                কর্মচারীর স্বাক্ষর
              </div>
              <div>
                <div className="border-t border-slate-400 w-28 mx-auto mb-1" />
                অনুমোদিত কর্মকর্তার স্বাক্ষর
              </div>
            </div>
          </div>

          <div className="mt-4 flex justify-end gap-2">
            <button
              onClick={() => printElementById('printable-gatepass', `গেট পাস - ${printGatePass.pass_no}`)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট করুন</span>
            </button>
          </div>
        </Modal>
      )}

      {/* Daily Attendance Sheet Printable Modal */}
      <AttendancePrintSheetModal
        isOpen={isPrintSheetOpen}
        onClose={() => setIsPrintSheetOpen(false)}
        date={selectedDate}
        department={selectedDept || 'all'}
        records={records as any}
      />
    </div>
  );
};
