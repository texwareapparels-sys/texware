import React from 'react';
import { Modal } from '../common/Modal';
import { Printer, ExternalLink, Calendar, Users, Clock, Building2 } from 'lucide-react';
import { printHtml } from '../../utils/printDocument';

interface AttendanceItem {
  id: number;
  employee_id: number;
  employee_code: string;
  full_name: string;
  department: string;
  designation: string;
  mobile: string;
  date: string;
  status: 'present' | 'absent' | 'leave' | 'late';
  in_time?: string;
  out_time?: string;
  ot_hours?: number;
  notes?: string;
}

interface AttendancePrintSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  date: string;
  department: string;
  records: AttendanceItem[];
  companyName?: string;
  companyAddress?: string;
  companyPhone?: string;
}

export const AttendancePrintSheetModal: React.FC<AttendancePrintSheetModalProps> = ({
  isOpen,
  onClose,
  date,
  department,
  records,
  companyName = 'টেক্স ওয়্যার অ্যাপারেলস',
  companyAddress = 'প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর, বাংলাদেশ',
  companyPhone = '+880 1711-234567'
}) => {
  if (!isOpen) return null;

  // Calculate summary metrics
  const totalEmployees = records.length;
  const presentCount = records.filter(r => r.status === 'present').length;
  const lateCount = records.filter(r => r.status === 'late').length;
  const absentCount = records.filter(r => r.status === 'absent').length;
  const leaveCount = records.filter(r => r.status === 'leave').length;
  const totalOtHours = records.reduce((sum, r) => sum + (Number(r.ot_hours) || 0), 0);

  // Status Bengali text
  const getStatusText = (status: string) => {
    switch (status) {
      case 'present': return 'উপস্থিত (P)';
      case 'late': return 'বিলম্ব (L)';
      case 'leave': return 'ছুটি (LV)';
      case 'absent': return 'অনুপস্থিত (A)';
      default: return status;
    }
  };

  // Generate printable HTML content
  const generatePrintableHtml = () => {
    const rowsHtml = records.map((r, idx) => `
      <tr>
        <td class="text-center font-mono">${idx + 1}</td>
        <td class="text-center font-mono font-bold">${r.employee_code || '-'}</td>
        <td class="font-bold">${r.full_name}</td>
        <td>${r.designation}</td>
        <td>${r.department}</td>
        <td class="text-center font-mono">${r.in_time || '-'}</td>
        <td class="text-center font-mono">${r.out_time || '-'}</td>
        <td class="text-center font-bold" style="color: ${r.status === 'present' ? '#047857' : r.status === 'absent' ? '#b91c1c' : r.status === 'late' ? '#d97706' : '#2563eb'};">
          ${getStatusText(r.status)}
        </td>
        <td class="text-center font-mono font-bold">${r.ot_hours ? r.ot_hours + ' ঘণ্টা' : '-'}</td>
        <td style="min-width: 80px;">${r.notes || ''}</td>
      </tr>
    `).join('');

    return `
      <div class="print-header">
        <h1 class="company-title">${companyName}</h1>
        <p class="company-sub">${companyAddress} | ফোন: ${companyPhone}</p>
        <div class="doc-title">দৈনিক কারখানা শ্রমিক ও কর্মচারী হাজিরা ও ওভারটাইম রেজিস্টার</div>
      </div>

      <div class="summary-strip">
        <div class="summary-item"><strong>তারিখ:</strong> ${date}</div>
        <div class="summary-item"><strong>বিভাগ:</strong> ${department === 'all' || department === 'সব বিভাগ' ? 'সকল কারখানা বিভাগ' : department}</div>
        <div class="summary-item"><strong>মোট কর্মী:</strong> ${totalEmployees} জন</div>
        <div class="summary-item"><strong>উপস্থিত:</strong> ${presentCount + lateCount} জন (সরাসরি: ${presentCount}, বিলম্ব: ${lateCount})</div>
        <div class="summary-item"><strong>অনুপস্থিত:</strong> ${absentCount} জন</div>
        <div class="summary-item"><strong>ছুটি:</strong> ${leaveCount} জন</div>
        <div class="summary-item"><strong>মোট ওভারটাইম:</strong> ${totalOtHours} ঘণ্টা</div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 35px;" class="text-center">ক্র:</th>
            <th style="width: 75px;" class="text-center">কার্ড নং</th>
            <th>শ্রমিক / কর্মচারীর নাম</th>
            <th>পদবী</th>
            <th>বিভাগ</th>
            <th style="width: 60px;" class="text-center">ইন টাইম</th>
            <th style="width: 60px;" class="text-center">আউট টাইম</th>
            <th style="width: 70px;" class="text-center">হাজিরা স্থিতি</th>
            <th style="width: 60px;" class="text-center">ওভারটাইম</th>
            <th style="width: 100px;">মন্তব্য / স্বাক্ষর</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml || '<tr><td colspan="10" class="text-center" style="padding: 20px;">এই তারিখে কোনো কর্মীর তথ্য পাওয়া যায়নি</td></tr>'}
        </tbody>
      </table>

      <div class="signature-grid">
        <div>
          <div style="height: 35px;"></div>
          <div class="signature-line">হাজিরা প্রস্তুতকারক (টাইমকিপার)</div>
        </div>
        <div>
          <div style="height: 35px;"></div>
          <div class="signature-line">ফ্লোর ইনচার্জ / সুপারভাইজার</div>
        </div>
        <div>
          <div style="height: 35px;"></div>
          <div class="signature-line">হিসাব ও অডিট কর্মকর্তা</div>
        </div>
        <div>
          <div style="height: 35px;"></div>
          <div class="signature-line">কারখানা কর্তৃপক্ষ / জিএম</div>
        </div>
      </div>
    `;
  };

  const handlePrint = () => {
    const html = generatePrintableHtml();
    printHtml(html, {
      title: `দৈনিক হাজিরা শীট - ${date}`,
      landscape: true
    });
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="দৈনিক পূর্ণাঙ্গ হাজিরা শীট প্রিন্ট প্রিভিউ"
      subtitle={`তারিখ: ${date} | সকল শ্রমিকের হাজিরা এক জায়গায়`}
      maxWidth="5xl"
    >
      <div className="space-y-4">
        {/* Top Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span className="inline-flex items-center gap-1 font-semibold text-slate-800">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              {date}
            </span>
            <span>•</span>
            <span className="inline-flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-slate-500" />
              {department === 'all' ? 'সকল বিভাগ' : department}
            </span>
            <span>•</span>
            <span className="inline-flex items-center gap-1 font-medium text-emerald-700">
              <Users className="w-3.5 h-3.5" />
              মোট: {totalEmployees} জন
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-emerald-600/30 cursor-pointer transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট করুন (A4 Landscape)</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
              title="নতুন ট্যাবে প্রিন্ট ভিউ খুলুন"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">নতুন উইন্ডো</span>
            </button>
          </div>
        </div>

        {/* Printable Paper Preview Box */}
        <div id="printable-attendance-sheet" className="bg-white border border-slate-300 rounded-xl p-6 text-slate-900 shadow-xs max-h-[60vh] overflow-y-auto">
          {/* Header */}
          <div className="text-center pb-4 mb-4 border-b-2 border-slate-900">
            <h2 className="text-xl font-extrabold text-emerald-900">{companyName}</h2>
            <p className="text-xs text-slate-500">{companyAddress} | ফোন: {companyPhone}</p>
            <div className="inline-block mt-2 px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded">
              দৈনিক কারখানা শ্রমিক ও কর্মচারী হাজিরা ও ওভারটাইম রেজিস্টার
            </div>
          </div>

          {/* Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs mb-4">
            <div>
              <span className="text-slate-500 block text-[10px]">তারিখ:</span>
              <span className="font-bold text-slate-800">{date}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">মোট কর্মী:</span>
              <span className="font-bold text-slate-800">{totalEmployees} জন</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">উপস্থিত:</span>
              <span className="font-bold text-emerald-700">{presentCount + lateCount} জন</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">অনুপস্থিত:</span>
              <span className="font-bold text-rose-700">{absentCount} জন</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">ছুটি:</span>
              <span className="font-bold text-blue-700">{leaveCount} জন</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">মোট ওভারটাইম:</span>
              <span className="font-bold text-amber-700">{totalOtHours} ঘণ্টা</span>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-300">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                <tr>
                  <th className="p-2 border border-slate-300 text-center w-8">ক্র:</th>
                  <th className="p-2 border border-slate-300 text-center w-20">কার্ড নং</th>
                  <th className="p-2 border border-slate-300">শ্রমিকের নাম</th>
                  <th className="p-2 border border-slate-300">পদবী</th>
                  <th className="p-2 border border-slate-300">বিভাগ</th>
                  <th className="p-2 border border-slate-300 text-center w-16">ইন টাইম</th>
                  <th className="p-2 border border-slate-300 text-center w-16">আউট টাইম</th>
                  <th className="p-2 border border-slate-300 text-center w-20">স্থিতি</th>
                  <th className="p-2 border border-slate-300 text-center w-16">ওটি ঘণ্টা</th>
                  <th className="p-2 border border-slate-300">স্বাক্ষর / মন্তব্য</th>
                </tr>
              </thead>
              <tbody>
                {records.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="p-6 text-center text-slate-400 border border-slate-300">
                      কোনো তথ্য পাওয়া যায়নি। অনুগ্রহ করে কর্মী যোগ করুন অথবা হাজিরা এন্ট্রি দিন।
                    </td>
                  </tr>
                ) : (
                  records.map((r, idx) => (
                    <tr key={r.id || idx} className="hover:bg-slate-50/50">
                      <td className="p-2 border border-slate-300 text-center font-mono text-slate-500">{idx + 1}</td>
                      <td className="p-2 border border-slate-300 text-center font-mono font-bold text-slate-800">{r.employee_code}</td>
                      <td className="p-2 border border-slate-300 font-bold text-slate-800">{r.full_name}</td>
                      <td className="p-2 border border-slate-300 text-slate-600">{r.designation}</td>
                      <td className="p-2 border border-slate-300 text-slate-600">{r.department}</td>
                      <td className="p-2 border border-slate-300 text-center font-mono">{r.in_time || '-'}</td>
                      <td className="p-2 border border-slate-300 text-center font-mono">{r.out_time || '-'}</td>
                      <td className="p-2 border border-slate-300 text-center font-bold">
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          r.status === 'present' ? 'bg-emerald-50 text-emerald-700' :
                          r.status === 'absent' ? 'bg-rose-50 text-rose-700' :
                          r.status === 'late' ? 'bg-amber-50 text-amber-700' : 'bg-blue-50 text-blue-700'
                        }`}>
                          {getStatusText(r.status)}
                        </span>
                      </td>
                      <td className="p-2 border border-slate-300 text-center font-mono font-bold text-slate-700">
                        {r.ot_hours ? `${r.ot_hours} ঘ:` : '-'}
                      </td>
                      <td className="p-2 border border-slate-300 text-slate-500 italic text-[11px] min-w-[90px]">
                        {r.notes || ''}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Official Signatures */}
          <div className="grid grid-cols-4 gap-4 mt-8 pt-4 text-center">
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 text-[11px] font-semibold text-slate-600">
                টাইমকিপার (প্রস্তুতকারক)
              </div>
            </div>
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 text-[11px] font-semibold text-slate-600">
                সুপারভাইজার / ইনচার্জ
              </div>
            </div>
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 text-[11px] font-semibold text-slate-600">
                হিসাব কর্মকর্তা
              </div>
            </div>
            <div>
              <div className="h-10"></div>
              <div className="border-t border-dashed border-slate-400 pt-1 text-[11px] font-semibold text-slate-600">
                ব্যবস্থাপক / কারখানা প্রধান
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex justify-end gap-2.5 pt-2 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>প্রিন্ট করুন</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
