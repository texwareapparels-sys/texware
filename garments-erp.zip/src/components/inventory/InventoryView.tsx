import React, { useState, useEffect, useMemo } from 'react';
import {
  Shirt,
  Plus,
  Printer,
  Calendar,
  Layers,
  Sparkles,
  Search,
  Filter,
  Trash2,
  RefreshCw,
  Tag,
  Boxes,
  ArrowRight,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Product, ProductVariant, ProductionRecord } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { printHtml } from '../../utils/printDocument';

const DEFAULT_CATEGORIES = [
  'Round Neck (গোল গলা)',
  'Polo Shirt (কলার গেঞ্জি)',
  'Drop Shoulder (ড্রপ শোল্ডার)',
  'V-Neck (ভি গলা)',
  'Hoodie (হুডি)',
];

const PRESET_COLORS = [
  { name: 'কালো (Jet Black)', hex: '#0f172a' },
  { name: 'নেভি ব্লু (Navy Blue)', hex: '#1e3a8a' },
  { name: 'সাদা (Pure White)', hex: '#f8fafc', border: true },
  { name: 'লাল (Deep Red)', hex: '#dc2626' },
  { name: 'মেরুন (Maroon)', hex: '#831843' },
  { name: 'রয়্যাল ব্লু (Royal Blue)', hex: '#2563eb' },
  { name: 'অলিভ গ্রিন (Olive Green)', hex: '#3f6212' },
  { name: 'ছাই / অ্যাশ (Heather Gray)', hex: '#64748b' },
  { name: 'বটল গ্রিন (Bottle Green)', hex: '#064e3b' },
  { name: 'হলুদ / মাস্টার্ড (Mustard)', hex: '#d97706' },
];

const SIZES = ['S', 'M', 'L', 'XL', 'XXL'] as const;

export const InventoryView: React.FC = () => {
  const { showToast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [productionRecords, setProductionRecords] = useState<ProductionRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'inventory' | 'production'>('inventory');

  // Category filter
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [customCategories, setCustomCategories] = useState<string[]>([]);

  // Modals
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [isNewCategoryModalOpen, setIsNewCategoryModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [deletingRecord, setDeletingRecord] = useState<ProductionRecord | null>(null);
  const [deletingColorGroup, setDeletingColorGroup] = useState<{
    category: string;
    color: string;
    product_id: number;
    count: number;
  } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Stock Entry Form
  const [entryForm, setEntryForm] = useState({
    category: DEFAULT_CATEGORIES[0],
    color: PRESET_COLORS[0].name,
    customColor: '',
    date: new Date().toISOString().split('T')[0],
    sizes: {
      S: 0,
      M: 0,
      L: 0,
      XL: 0,
      XXL: 0,
    },
    unit_cost: 180,
    unit_price: 280,
    notes: '',
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [prods, prodsRec] = await Promise.all([
        api.getProducts(),
        api.getProduction(),
      ]);
      setProducts(prods || []);
      setProductionRecords(prodsRec || []);

      // Extract any unique categories from existing products
      if (prods && prods.length > 0) {
        const extraCats = prods
          .map((p) => p.category)
          .filter((c): c is string => Boolean(c) && !DEFAULT_CATEGORIES.includes(c));
        setCustomCategories(Array.from(new Set(extraCats)));
      }
    } catch (err: any) {
      showToast(err.message || 'ইনভেন্টরি তথ্য লোড করা যায়নি', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Combined categories
  const allCategories = useMemo(() => {
    return Array.from(new Set([...DEFAULT_CATEGORIES, ...customCategories]));
  }, [customCategories]);

  // Handle open stock modal
  const handleOpenStockModal = (presetCat?: string, presetColor?: string) => {
    setEntryForm({
      category: presetCat || (selectedCategory !== 'all' ? selectedCategory : allCategories[0]),
      color: presetColor || PRESET_COLORS[0].name,
      customColor: '',
      date: new Date().toISOString().split('T')[0],
      sizes: { S: 20, M: 40, L: 50, XL: 30, XXL: 10 },
      unit_cost: 180,
      unit_price: 280,
      notes: '',
    });
    setIsStockModalOpen(true);
  };

  const handleSaveStockEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalColor = entryForm.color === 'custom' ? entryForm.customColor.trim() : entryForm.color;
    if (!finalColor) {
      showToast('গেঞ্জির কালার নির্বাচন বা লিখুন', 'error');
      return;
    }

    const totalQty = Object.values(entryForm.sizes).reduce<number>((sum, q) => sum + (Number(q) || 0), 0);
    if (totalQty <= 0) {
      showToast('কমপক্ষে একটি সাইজের পরিমাণ (পিস) দিন', 'error');
      return;
    }

    try {
      await api.garmentsStockEntry({
        category: entryForm.category,
        color: finalColor,
        date: entryForm.date,
        sizes: entryForm.sizes,
        unit_cost: entryForm.unit_cost,
        unit_price: entryForm.unit_price,
        notes: entryForm.notes,
      });

      showToast(`${entryForm.category} (${finalColor}): মোট ${totalQty} পিস স্টক সফলভাবে যুক্ত হয়েছে!`, 'success');
      setIsStockModalOpen(false);
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'স্টক সংরক্ষণ ব্যর্থ হয়েছে', 'error');
    }
  };

  const handleAddCustomCategory = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCategoryName.trim();
    if (!trimmed) return;
    if (!allCategories.includes(trimmed)) {
      setCustomCategories((prev) => [...prev, trimmed]);
      setSelectedCategory(trimmed);
      showToast(`নতুন ক্যাটাগরি '${trimmed}' যুক্ত করা হয়েছে`, 'success');
    }
    setNewCategoryName('');
    setIsNewCategoryModalOpen(false);
  };

  const handleConfirmDeleteProduction = async () => {
    if (!deletingRecord) return;
    setIsDeleting(true);
    try {
      await api.deleteProduction(deletingRecord.id);
      showToast('উৎপাদন রেকর্ড সফলভাবে মুছে ফেলা হয়েছে এবং সংশ্লিষ্ট স্টক সমন্বয় করা হয়েছে', 'success');
      setDeletingRecord(null);
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'রেকর্ড মুছতে সমস্যা হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleConfirmDeleteColorGroup = async () => {
    if (!deletingColorGroup) return;
    setIsDeleting(true);
    try {
      await api.deleteColorStock({
        category: deletingColorGroup.category,
        color: deletingColorGroup.color,
        product_id: deletingColorGroup.product_id,
      });
      showToast(`কালার "${deletingColorGroup.color}" এর সমস্ত স্টক ও রেকর্ড সফলভাবে মুছে ফেলা হয়েছে`, 'success');
      setDeletingColorGroup(null);
      fetchData();
    } catch (err: any) {
      showToast(err.message || 'স্টক মুছতে সমস্যা হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Group variants by Category and then Color
  const colorGroups = useMemo(() => {
    // Collect all variants across products
    interface VariantEntry {
      category: string;
      color: string;
      product_id: number;
      product_name: string;
      selling_price: number;
      sizes: Record<string, { variant_id: number; stock: number; sku: string }>;
      totalPieces: number;
    }

    const map = new Map<string, VariantEntry>();

    products.forEach((prod) => {
      const cat = prod.category || prod.name_bn || 'সাধারণ গেঞ্জি';
      if (selectedCategory !== 'all' && cat !== selectedCategory) {
        return;
      }

      (prod.variants || []).forEach((v) => {
        const color = v.color || 'অন্যান্য কালার';
        const key = `${cat}___${color}`;

        if (!map.has(key)) {
          map.set(key, {
            category: cat,
            color,
            product_id: prod.id,
            product_name: prod.name_bn || prod.name_en || cat,
            selling_price: prod.selling_price || 280,
            sizes: {},
            totalPieces: 0,
          });
        }

        const entry = map.get(key)!;
        entry.sizes[v.size] = {
          variant_id: v.id,
          stock: v.stock_quantity || 0,
          sku: v.sku || '',
        };
        entry.totalPieces += v.stock_quantity || 0;
      });
    });

    return Array.from(map.values());
  }, [products, selectedCategory]);

  const totalStockInView = useMemo(() => {
    return colorGroups.reduce((acc, g) => acc + g.totalPieces, 0);
  }, [colorGroups]);

  // Universal Printing: Print Current Stock Inventory
  const handlePrintStockReport = () => {
    const dateStr = new Date().toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    let tableRows = '';
    if (colorGroups.length === 0) {
      tableRows = `
        <tr>
          <td colspan="9" style="text-align: center; padding: 25px; color: #64748b;">
            বর্তমানে ইনভেন্টরিতে কোনো গেঞ্জি স্টক রেকর্ড নেই
          </td>
        </tr>
      `;
    } else {
      colorGroups.forEach((cg, idx) => {
        const sQty = cg.sizes['S']?.stock || 0;
        const mQty = cg.sizes['M']?.stock || 0;
        const lQty = cg.sizes['L']?.stock || 0;
        const xlQty = cg.sizes['XL']?.stock || 0;
        const xxlQty = cg.sizes['XXL']?.stock || 0;
        const total = cg.totalPieces;

        tableRows += `
          <tr>
            <td style="text-align: center; font-weight: bold;">${idx + 1}</td>
            <td style="font-weight: bold; color: #0f172a;">${cg.category}</td>
            <td style="font-weight: bold; color: #1e3a8a;">${cg.color}</td>
            <td style="text-align: center;">${sQty > 0 ? sQty + ' পিস' : '—'}</td>
            <td style="text-align: center;">${mQty > 0 ? mQty + ' পিস' : '—'}</td>
            <td style="text-align: center;">${lQty > 0 ? lQty + ' পিস' : '—'}</td>
            <td style="text-align: center;">${xlQty > 0 ? xlQty + ' পিস' : '—'}</td>
            <td style="text-align: center;">${xxlQty > 0 ? xxlQty + ' পিস' : '—'}</td>
            <td style="text-align: right; font-weight: bold; font-family: monospace; font-size: 12px; color: #064e3b;">
              ${total} পিস
            </td>
          </tr>
        `;
      });
    }

    const html = `
      <div class="print-header">
        <h1 class="company-title">টেক্স ওয়্যার অ্যাপারেলস</h1>
        <p class="company-sub">প্লট #১২, কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর | ফোন: +880 1711-000000</p>
        <div class="doc-title">গেঞ্জি উৎপাদন ও মজুদ স্টক ইনভেন্টরি রিপোর্ট</div>
      </div>

      <div class="summary-strip">
        <div class="summary-item"><strong>রিপোর্ট তৈরির তারিখ:</strong> ${dateStr}</div>
        <div class="summary-item"><strong>ফিল্টার ক্যাটাগরি:</strong> ${selectedCategory === 'all' ? 'সকল ক্যাটাগরি' : selectedCategory}</div>
        <div class="summary-item"><strong>মোট কালার সেকশন:</strong> ${colorGroups.length} টি</div>
        <div class="summary-item"><strong>সর্বমোট মজুদ গেঞ্জি:</strong> <span style="font-size: 13px; font-weight: bold; color: #064e3b;">${totalStockInView} পিস</span></div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 35px; text-align: center;">ক্র নং</th>
            <th>গেঞ্জির ক্যাটাগরি</th>
            <th>রং / কালার</th>
            <th style="text-align: center;">সাইজ: S</th>
            <th style="text-align: center;">সাইজ: M</th>
            <th style="text-align: center;">সাইজ: L</th>
            <th style="text-align: center;">সাইজ: XL</th>
            <th style="text-align: center;">সাইজ: XXL</th>
            <th style="text-align: right;">মোট মজুদ (পিস)</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
        <tfoot>
          <tr style="background: #f1f5f9; font-weight: bold;">
            <td colspan="8" style="text-align: right; padding: 7px 10px;">ইনভেন্টরিতে মোট মজুদ গেঞ্জি:</td>
            <td style="text-align: right; font-family: monospace; font-size: 13px; color: #064e3b; padding: 7px 10px;">
              ${totalStockInView} পিস
            </td>
          </tr>
        </tfoot>
      </table>

      <div class="signature-grid">
        <div>
          <div class="signature-line">স্টোর কিপার / প্রস্তুতকারক</div>
        </div>
        <div>
          <div class="signature-line">উৎপাদন ইনচার্জ</div>
        </div>
        <div>
          <div class="signature-line">হিসাব বিভাগ</div>
        </div>
        <div>
          <div class="signature-line">ব্যবস্থাপনা পরিচালক / অথরাইজড</div>
        </div>
      </div>
    `;

    printHtml(html, { title: `গেঞ্জি_স্টক_ইনভেন্টরি_${new Date().toISOString().split('T')[0]}` });
  };

  // Universal Printing: Print Production History Report
  const handlePrintProductionHistory = () => {
    const dateStr = new Date().toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    let tableRows = '';
    let grandTotal = 0;

    if (productionRecords.length === 0) {
      tableRows = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 25px; color: #64748b;">
            কোনো উৎপাদন এন্ট্রি পাওয়া যায়নি
          </td>
        </tr>
      `;
    } else {
      productionRecords.forEach((pr, idx) => {
        grandTotal += pr.quantity || 0;
        tableRows += `
          <tr>
            <td style="text-align: center;">${idx + 1}</td>
            <td style="font-family: monospace; font-size: 10px;">${pr.date}</td>
            <td style="font-family: monospace; font-weight: bold;">${pr.batch_no}</td>
            <td style="font-weight: bold;">${pr.product_name || 'গেঞ্জি'}</td>
            <td>${pr.color || '—'} / ${pr.size || '—'}</td>
            <td style="text-align: right; font-weight: bold; font-family: monospace;">${pr.quantity} পিস</td>
            <td>${pr.supervisor_name || 'কারখানা ইনচার্জ'}</td>
          </tr>
        `;
      });
    }

    const html = `
      <div class="print-header">
        <h1 class="company-title">টেক্স ওয়্যার অ্যাপারেলস</h1>
        <p class="company-sub">প্লট #১২, কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর</p>
        <div class="doc-title">গেঞ্জি উৎপাদন ও ব্যাচ হিস্ট্রি লগ</div>
      </div>

      <div class="summary-strip">
        <div class="summary-item"><strong>তারিখ:</strong> ${dateStr}</div>
        <div class="summary-item"><strong>মোট উৎপাদন ব্যাচ:</strong> ${productionRecords.length} টি</div>
        <div class="summary-item"><strong>সর্বমোট উৎপাদিত পরিমাণ:</strong> <strong>${grandTotal} পিস</strong></div>
      </div>

      <table>
        <thead>
          <tr>
            <th style="width: 35px; text-align: center;">#</th>
            <th>উৎপাদন তারিখ</th>
            <th>ব্যাচ / লট নং</th>
            <th>গেঞ্জির ধরন / ক্যাটাগরি</th>
            <th>কালার ও সাইজ</th>
            <th style="text-align: right;">পরিমাণ (পিস)</th>
            <th>দায়িত্বপ্রাপ্ত কর্মকর্তা</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
        <tfoot>
          <tr style="background: #f1f5f9; font-weight: bold;">
            <td colspan="5" style="text-align: right;">মোট উৎপাদিত পিস:</td>
            <td style="text-align: right; font-family: monospace; color: #064e3b;">${grandTotal} পিস</td>
            <td></td>
          </tr>
        </tfoot>
      </table>

      <div class="signature-grid">
        <div><div class="signature-line">উৎপাদন সুপারভাইজার</div></div>
        <div><div class="signature-line">কোয়ালিটি কন্ট্রোলার</div></div>
        <div><div class="signature-line">ফ্যাক্টরি ম্যানেজার</div></div>
        <div><div class="signature-line">পরিচালক</div></div>
      </div>
    `;

    printHtml(html, { title: `গেঞ্জি_উৎপাদন_লগ_${new Date().toISOString().split('T')[0]}` });
  };

  return (
    <div className="space-y-6 pb-14 font-['Hind_Siliguri',sans-serif]">
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <Shirt className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              গেঞ্জি উৎপাদন ও স্টক ইনভেন্টরি
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            কালারভিত্তিক আলাদা আলাদা সেকশন, সাইজ (S, M, L, XL, XXL) স্টক ট্র্যাকিং এবং নিখুঁত উৎপাদন এন্ট্রি
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Universal Print Button */}
          <button
            onClick={activeTab === 'inventory' ? handlePrintStockReport : handlePrintProductionHistory}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            title="ইনভেন্টরি বা উৎপাদন রিপোর্ট প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>{activeTab === 'inventory' ? 'স্টক ইনভেন্টরি প্রিন্ট' : 'উৎপাদন রিপোর্ট প্রিন্ট'}</span>
          </button>

          <button
            onClick={fetchData}
            title="রিফ্রেশ করুন"
            className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl border border-slate-200 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={() => handleOpenStockModal()}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs shadow-emerald-600/20 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন গেঞ্জি উৎপাদন / স্টক যোগ</span>
          </button>
        </div>
      </div>

      {/* Main Tabs (স্টক ইনভেন্টরি vs উৎপাদন ইতিহাস) */}
      <div className="flex border-b border-slate-200 text-xs font-semibold gap-2">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors flex items-center gap-2 ${
            activeTab === 'inventory'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Boxes className="w-4 h-4" />
          <span>কালার ও সাইজভিত্তিক স্টক ({totalStockInView} পিস)</span>
        </button>

        <button
          onClick={() => setActiveTab('production')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors flex items-center gap-2 ${
            activeTab === 'production'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>উৎপাদন হিস্ট্রি ও ব্যাচ লগ ({productionRecords.length} এন্ট্রি)</span>
        </button>
      </div>

      {/* TAB 1: INVENTORY (Color & Size Sections) */}
      {activeTab === 'inventory' && (
        <div className="space-y-6">
          {/* Category Filter Bar */}
          <div className="bg-white p-3 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-1.5 overflow-x-auto py-1 max-w-full">
              <span className="text-xs font-bold text-slate-400 mr-1 flex items-center gap-1 shrink-0">
                <Filter className="w-3.5 h-3.5" />
                ক্যাটাগরি:
              </span>

              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 cursor-pointer transition-all ${
                  selectedCategory === 'all'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                সকল ক্যাটাগরি
              </button>

              {allCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 cursor-pointer transition-all ${
                    selectedCategory === cat
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}

              <button
                onClick={() => setIsNewCategoryModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold text-emerald-700 border border-dashed border-emerald-300 hover:bg-emerald-50 shrink-0 cursor-pointer flex items-center gap-1"
                title="নতুন ক্যাটাগরি তৈরি করুন"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>নতুন ক্যাটাগরি</span>
              </button>
            </div>

            <div className="text-xs text-slate-500 font-medium">
              মজুদ গেঞ্জি: <span className="font-bold text-slate-800 font-mono">{totalStockInView}</span> পিস
            </div>
          </div>

          {/* Color Sections List */}
          {loading ? (
            <div className="bg-white rounded-2xl p-12 text-center text-slate-400 border border-slate-200/80">
              <div className="w-8 h-8 border-2 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto mb-2" />
              ইনভেন্টরি তথ্য লোড হচ্ছে...
            </div>
          ) : colorGroups.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs max-w-2xl mx-auto">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                <Shirt className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800">
                বর্তমানে কোনো গেঞ্জি উৎপাদন বা স্টক রেকর্ড নেই
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 max-w-md mx-auto leading-relaxed">
                আপনার কারখানায় উৎপাদিত গেঞ্জির কালার, সাইজ (S, M, L, XL, XXL) এবং পরিমাণ এন্ট্রি করতে নিচে বাটনে ক্লিক করুন। কোনো ডেমো বা পরীক্ষামূলক ডাটা রাখা হয়নি।
              </p>
              <button
                onClick={() => handleOpenStockModal()}
                className="mt-5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold inline-flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>প্রথম গেঞ্জি উৎপাদন ও স্টক যোগ করুন</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {colorGroups.map((group) => {
                const preset = PRESET_COLORS.find((c) => c.name === group.color || group.color.includes(c.name));
                const swatchColor = preset?.hex || '#334155';

                return (
                  <div
                    key={`${group.category}-${group.color}`}
                    className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden transition-all hover:border-slate-300"
                  >
                    {/* Section Header: Color Info & Category */}
                    <div className="p-4 sm:p-5 bg-slate-50/70 border-b border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <span
                          className="w-5 h-5 rounded-full shadow-inner border border-slate-300 shrink-0"
                          style={{ backgroundColor: swatchColor }}
                        />
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="text-sm font-bold text-slate-900">
                              কালার: {group.color}
                            </h3>
                            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-semibold">
                              {group.category}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            পাইকারি দর: ৳{group.selling_price} | বর্তমান মোট স্টক: <strong className="text-slate-800">{group.totalPieces} পিস</strong>
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleOpenStockModal(group.category, group.color)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>এই কালারে স্টক যোগ</span>
                        </button>
                        <button
                          onClick={() => setDeletingColorGroup({ category: group.category, color: group.color, product_id: group.product_id, count: group.totalPieces })}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                          title="এই কালারের সমস্ত স্টক ও রেকর্ড মুছে ফেলুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* 5 Sizes Box Grid: S, M, L, XL, XXL */}
                    <div className="p-4 sm:p-5">
                      <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">
                        সাইজভিত্তিক বর্তমান মজুদ (পিস):
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                        {SIZES.map((sizeKey) => {
                          const sizeData = group.sizes[sizeKey];
                          const qty = sizeData?.stock || 0;
                          const hasStock = qty > 0;

                          return (
                            <div
                              key={sizeKey}
                              className={`p-3.5 rounded-xl border text-center transition-all ${
                                hasStock
                                  ? 'bg-emerald-50/40 border-emerald-200/80'
                                  : 'bg-slate-50/80 border-slate-200/60 opacity-60'
                              }`}
                            >
                              <div className="flex items-center justify-between pb-1 border-b border-slate-200/60 mb-2">
                                <span className="text-xs font-black text-slate-700 bg-white px-2 py-0.5 rounded border border-slate-200 font-mono">
                                  {sizeKey}
                                </span>
                                <span className="text-[10px] text-slate-400 font-medium">সাইজ</span>
                              </div>

                              <div className={`text-xl font-black font-mono ${hasStock ? 'text-slate-900' : 'text-slate-400'}`}>
                                {qty}
                              </div>
                              <span className="text-[10px] text-slate-500 mt-0.5 block font-medium">পিস মজুদ</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PRODUCTION HISTORY & BATCH LOG */}
      {activeTab === 'production' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200/80 flex items-center justify-between gap-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                উৎপাদন ব্যাচ ও এন্ট্রি তালিকা
              </h3>
              <p className="text-[11px] text-slate-400">
                কারখানায় যে যে তারিখে গেঞ্জি উৎপাদন হয়ে স্টকে যোগ হয়েছে তার পূর্ণাঙ্গ তালিকা
              </p>
            </div>
            <div className="text-xs font-mono font-bold text-slate-700">
              মোট এন্ট্রি: {productionRecords.length}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/60 border-b border-slate-200 text-slate-500 font-bold uppercase text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">তারিখ ও ব্যাচ নং</th>
                  <th className="py-3.5 px-4">গেঞ্জির ধরন / ক্যাটাগরি</th>
                  <th className="py-3.5 px-4">কালার ও সাইজ</th>
                  <th className="py-3.5 px-4 text-right">উৎপাদিত পরিমাণ</th>
                  <th className="py-3.5 px-4">সুপারভাইজার / কর্মকর্তা</th>
                  <th className="py-3.5 px-4">নোট / মন্তব্য</th>
                  <th className="py-3.5 px-4 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {productionRecords.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      কোনো উৎপাদন রেকর্ড নেই
                    </td>
                  </tr>
                ) : (
                  productionRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4">
                        <div className="font-mono font-bold text-slate-800">{rec.batch_no}</div>
                        <div className="text-[11px] text-slate-400">{rec.date}</div>
                      </td>

                      <td className="py-3 px-4 font-bold text-slate-800">
                        {rec.product_name || 'গেঞ্জি'}
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-700">{rec.color || '—'}</span>
                        <span className="ml-2 inline-block px-1.5 py-0.2 bg-slate-100 rounded text-[10px] font-mono font-bold text-slate-600">
                          {rec.size || '—'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-bold font-mono text-emerald-700 text-sm">
                        {rec.quantity} পিস
                      </td>

                      <td className="py-3 px-4 text-slate-600">
                        {rec.supervisor_name || 'কারখানা ইনচার্জ'}
                      </td>

                      <td className="py-3 px-4 text-slate-500 max-w-xs truncate">
                        {rec.notes || '—'}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setDeletingRecord(rec)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                          title="রেকর্ড মুছুন ও স্টক সমন্বয় করুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: NEW STOCK ENTRY (Category, Color, Sizes: S, M, L, XL, XXL, Date, Quantity) */}
      <Modal
        isOpen={isStockModalOpen}
        onClose={() => setIsStockModalOpen(false)}
        title="নতুন গেঞ্জি উৎপাদন ও স্টক এন্ট্রি"
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSaveStockEntry} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Category */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                গেঞ্জির ক্যাটাগরি *
              </label>
              <select
                value={entryForm.category}
                onChange={(e) => setEntryForm({ ...entryForm, category: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                required
              >
                {allCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Date */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                উৎপাদন / এন্ট্রি তারিখ *
              </label>
              <input
                type="date"
                value={entryForm.date}
                onChange={(e) => setEntryForm({ ...entryForm, date: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold"
                required
              />
            </div>
          </div>

          {/* Color Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              গেঞ্জির কালার *
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {PRESET_COLORS.map((col) => (
                <button
                  type="button"
                  key={col.name}
                  onClick={() => setEntryForm({ ...entryForm, color: col.name })}
                  className={`px-2.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 border cursor-pointer transition-all ${
                    entryForm.color === col.name
                      ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 shadow-xs'
                      : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-slate-300 shrink-0"
                    style={{ backgroundColor: col.hex }}
                  />
                  <span className="truncate">{col.name.split(' ')[0]}</span>
                </button>
              ))}

              <button
                type="button"
                onClick={() => setEntryForm({ ...entryForm, color: 'custom' })}
                className={`px-2.5 py-2 rounded-xl text-xs font-semibold border cursor-pointer transition-all ${
                  entryForm.color === 'custom'
                    ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900'
                    : 'border-dashed border-slate-300 bg-slate-50 text-slate-600'
                }`}
              >
                + কাস্টম কালার
              </button>
            </div>

            {entryForm.color === 'custom' && (
              <div className="mt-2">
                <input
                  type="text"
                  value={entryForm.customColor}
                  onChange={(e) => setEntryForm({ ...entryForm, customColor: e.target.value })}
                  placeholder="কালারের নাম লিখুন (যেমন: মেরুন, লেমন ইয়োলো, পার্পল)"
                  className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs font-semibold"
                  autoFocus
                  required
                />
              </div>
            )}
          </div>

          {/* Sizes Box: S, M, L, XL, XXL */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-800">
                সাইজভিত্তিক উৎপাদনের পরিমাণ (পিস) *
              </label>
              <span className="text-xs font-bold text-emerald-700">
                মোট:{' '}
                {Object.values(entryForm.sizes).reduce<number>((s, n) => s + (Number(n) || 0), 0)} পিস
              </span>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {SIZES.map((sKey) => (
                <div key={sKey} className="bg-white p-2.5 rounded-xl border border-slate-200 text-center">
                  <span className="text-[11px] font-bold text-slate-600 font-mono block mb-1">
                    {sKey}
                  </span>
                  <input
                    type="number"
                    min={0}
                    value={entryForm.sizes[sKey]}
                    onChange={(e) =>
                      setEntryForm({
                        ...entryForm,
                        sizes: {
                          ...entryForm.sizes,
                          [sKey]: Math.max(0, parseInt(e.target.value, 10) || 0),
                        },
                      })
                    }
                    className="w-full text-center text-sm font-bold font-mono py-1 px-1 border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                  />
                  <span className="text-[9px] text-slate-400 mt-0.5 block">পিস</span>
                </div>
              ))}
            </div>
          </div>

          {/* Pricing & Cost */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                প্রতি পিস উৎপাদন খরচ (৳)
              </label>
              <input
                type="number"
                min={0}
                value={entryForm.unit_cost}
                onChange={(e) => setEntryForm({ ...entryForm, unit_cost: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                পাইকারি বিক্রয় দর (৳)
              </label>
              <input
                type="number"
                min={0}
                value={entryForm.unit_price}
                onChange={(e) => setEntryForm({ ...entryForm, unit_price: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              নোট বা লট বিবরণ (ঐচ্ছিক)
            </label>
            <input
              type="text"
              value={entryForm.notes}
              onChange={(e) => setEntryForm({ ...entryForm, notes: e.target.value })}
              placeholder="যেমন: লট #০৪, সুতা ও কালার কোয়ালিটি চেকড"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsStockModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
            >
              স্টকে সংরক্ষণ করুন
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL 2: ADD NEW CATEGORY */}
      <Modal
        isOpen={isNewCategoryModalOpen}
        onClose={() => setIsNewCategoryModalOpen(false)}
        title="নতুন গেঞ্জি ক্যাটাগরি তৈরি করুন"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleAddCustomCategory} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ক্যাটাগরির নাম *
            </label>
            <input
              type="text"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="যেমন: ফুল হাতা গেঞ্জি (Full Sleeve), ট্যাংক টপ"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:bg-white focus:border-emerald-500 focus:outline-hidden"
              required
              autoFocus
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsNewCategoryModalOpen(false)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
            >
              ক্যাটাগরি যোগ করুন
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL 3: DELETE PRODUCTION RECORD CONFIRMATION */}
      <Modal
        isOpen={Boolean(deletingRecord)}
        onClose={() => setDeletingRecord(null)}
        title="উৎপাদন রেকর্ড মুছে ফেলার নিশ্চিতকরণ"
        subtitle="সতর্কতা: এই রেকর্ডটি মুছে ফেললে পণ্যের বর্তমান স্টক থেকে এই পরিমাণ বিয়োগ হয়ে যাবে।"
        maxWidth="max-w-md"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="text-rose-900 leading-relaxed">
              আপনি কি নিশ্চিতভাবে উৎপাদন রেকর্ড{' '}
              <strong className="font-bold text-slate-900">
                #{deletingRecord?.id} (ব্যাচ: {deletingRecord?.batch_no || 'N/A'}, পরিমাণ: {deletingRecord?.quantity} পিস)
              </strong>{' '}
              মুছে ফেলতে চান?
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setDeletingRecord(null)}
              disabled={isDeleting}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="button"
              onClick={handleConfirmDeleteProduction}
              disabled={isDeleting}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              {isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, নিশ্চিত মুছে ফেলুন'}
            </button>
          </div>
        </div>
      </Modal>

      {/* MODAL 4: DELETE COLOR GROUP STOCK CONFIRMATION */}
      <Modal
        isOpen={Boolean(deletingColorGroup)}
        onClose={() => setDeletingColorGroup(null)}
        title="কালার ও স্টক মুছে ফেলার নিশ্চিতকরণ"
        subtitle="এই কালারের অন্তর্ভুক্ত সমস্ত সাইজ ও উৎপাদন রেকর্ড স্থায়ীভাবে মুছে যাবে।"
        maxWidth="max-w-md"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="text-rose-900 leading-relaxed">
              আপনি কি নিশ্চিতভাবে{' '}
              <strong className="font-bold text-slate-900">
                {deletingColorGroup?.category} - {deletingColorGroup?.color}
              </strong>{' '}
              এর সমস্ত সাইজ ও মজুদ ({deletingColorGroup?.count || 0} পিস) সিস্টেম থেকে মুছে ফেলতে চান?
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setDeletingColorGroup(null)}
              disabled={isDeleting}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="button"
              onClick={handleConfirmDeleteColorGroup}
              disabled={isDeleting}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              {isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'হ্যাঁ, স্টক সম্পূর্ণ মুছে ফেলুন'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
