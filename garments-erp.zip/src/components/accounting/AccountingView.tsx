import React, { useState, useEffect, useMemo } from 'react';
import {
  Wallet,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  Filter,
  DollarSign,
  TrendingUp,
  Receipt,
  Download,
  Calendar,
  Building,
  CreditCard,
  PieChart,
  Printer,
  Trash2,
  Search,
  X,
  CheckCircle,
  FileText,
  ShoppingBag,
  Banknote,
  Users,
  AlertCircle,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { Expense, Shop } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { printHtml, openReportInNewTab } from '../../utils/printDocument';
import { BusinessReportModal, BusinessReportType } from './BusinessReportModal';

type SubTab = 'expenses' | 'collections' | 'sales' | 'dues' | 'payroll' | 'statements';

export const AccountingView: React.FC = () => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<SubTab>('expenses');

  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [sales, setSales] = useState<any[]>([]);
  const [collections, setCollections] = useState<any[]>([]);
  const [payrollPeriods, setPayrollPeriods] = useState<any[]>([]);
  const [financialStats, setFinancialStats] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Date-based Search & Filters for Expenses
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isCollectionModalOpen, setIsCollectionModalOpen] = useState(false);
  const [isReportsModalOpen, setIsReportsModalOpen] = useState(false);
  const [selectedReportType, setSelectedReportType] = useState<BusinessReportType>('combined');
  const [deleteExpenseConfirm, setDeleteExpenseConfirm] = useState<Expense | null>(null);
  const [deleteCollectionConfirm, setDeleteCollectionConfirm] = useState<any | null>(null);
  const [deleteSaleConfirm, setDeleteSaleConfirm] = useState<any | null>(null);
  const [clearDataModalOpen, setClearDataModalOpen] = useState(false);
  const [clearTargetType, setClearTargetType] = useState<'expenses' | 'collections' | 'sales' | 'all' | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Expense Form
  const [expenseForm, setExpenseForm] = useState({
    category: 'কাঁচামাল ও ফেব্রিক (Fabric & Yarn)',
    amount: 5000,
    date: new Date().toISOString().split('T')[0],
    paid_to: '',
    payment_method: 'কারখানা ক্যাশ (Cash)',
    voucher_no: `EXP-${Date.now().toString().slice(-4)}`,
    description: '',
  });

  // Collection Form
  const [collectionForm, setCollectionForm] = useState({
    shop_id: '',
    amount: 10000,
    collection_date: new Date().toISOString().split('T')[0],
    payment_method: 'Cash',
    reference: '',
    notes: '',
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [expData, shopData, salesData, collData, payrollData, statsData] = await Promise.all([
        api.getExpenses(),
        api.getShops(),
        api.getSales(),
        api.getCollections(),
        api.getPayrollPeriods(),
        api.getFinancialStats(),
      ]);

      setExpenses(expData || []);
      setShops(shopData || []);
      setSales(salesData || []);
      setCollections(collData || []);
      setPayrollPeriods(payrollData || []);
      setFinancialStats(statsData || null);
    } catch (error) {
      console.error('Failed to load accounting data:', error);
      showToast('হিসাবের তথ্য লোড করতে সমস্যা হয়েছে', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Quick Date Presets
  const setQuickDateRange = (type: 'today' | '7days' | 'this_month' | 'all') => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (type === 'today') {
      setStartDate(todayStr);
      setEndDate(todayStr);
    } else if (type === '7days') {
      const prev = new Date();
      prev.setDate(today.getDate() - 7);
      setStartDate(prev.toISOString().split('T')[0]);
      setEndDate(todayStr);
    } else if (type === 'this_month') {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      setStartDate(firstDay.toISOString().split('T')[0]);
      setEndDate(todayStr);
    } else {
      setStartDate('');
      setEndDate('');
    }
  };

  // Filtered Expenses
  const filteredExpenses = useMemo(() => {
    return expenses.filter((exp) => {
      const expDate = exp.date || (exp as any).expense_date || '';

      if (startDate && expDate < startDate) return false;
      if (endDate && expDate > endDate) return false;

      if (categoryFilter !== 'all' && exp.category !== categoryFilter) {
        return false;
      }

      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const vNo = (exp.voucher_no || (exp as any).expense_no || '').toLowerCase();
        const paidTo = (exp.paid_to || '').toLowerCase();
        const desc = (exp.description || '').toLowerCase();
        const cat = (exp.category || '').toLowerCase();

        return vNo.includes(query) || paidTo.includes(query) || desc.includes(query) || cat.includes(query);
      }

      return true;
    });
  }, [expenses, startDate, endDate, categoryFilter, searchTerm]);

  const totalFilteredExpense = useMemo(() => {
    return filteredExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [filteredExpenses]);

  // Currency Formatter
  const formatTk = (amount: number | string | undefined | null) => {
    const num = Number(amount) || 0;
    return `৳ ${num.toLocaleString('bn-BD')}`;
  };

  // Open Report Modal with specific report pre-selected
  const openReportModal = (type: BusinessReportType = 'combined') => {
    setSelectedReportType(type);
    setIsReportsModalOpen(true);
  };

  // Save Expense
  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseForm.amount || expenseForm.amount <= 0) {
      showToast('খরচের সঠিক পরিমাণ লিখুন', 'error');
      return;
    }

    try {
      await api.createExpense({
        ...expenseForm,
        amount: Number(expenseForm.amount),
      });

      showToast('কারখানা খরচ সফলভাবে এন্ট্রি হয়েছে', 'success');
      setIsExpenseModalOpen(false);
      loadData();
    } catch (error) {
      console.error('Error saving expense:', error);
      showToast('খরচ সংরক্ষণ করতে ব্যর্থ হয়েছে', 'error');
    }
  };

  // Delete Expense
  const handleDeleteExpense = async () => {
    if (!deleteExpenseConfirm) return;
    try {
      await api.deleteExpense(deleteExpenseConfirm.id);
      showToast('খরচের ভাউচারটি মুছে ফেলা হয়েছে', 'success');
      setDeleteExpenseConfirm(null);
      loadData();
    } catch (error) {
      console.error('Error deleting expense:', error);
      showToast('ভাউচার মুছতে সমস্যা হয়েছে', 'error');
    }
  };

  // Delete Collection
  const handleDeleteCollection = async () => {
    if (!deleteCollectionConfirm) return;
    setIsDeleting(true);
    try {
      await api.deleteCollection(deleteCollectionConfirm.id);
      showToast('কালেকশন রেকর্ডটি মুছে ফেলা হয়েছে ও দোকানের বাকি সমন্বয় করা হয়েছে', 'success');
      setDeleteCollectionConfirm(null);
      loadData();
    } catch (error) {
      console.error('Error deleting collection:', error);
      showToast('কালেকশন মুছতে সমস্যা হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Delete Sale
  const handleDeleteSale = async () => {
    if (!deleteSaleConfirm) return;
    setIsDeleting(true);
    try {
      await api.deleteSale(deleteSaleConfirm.id);
      showToast('বিক্রয় চালান সফলভাবে মুছে ফেলা হয়েছে ও ব্যালেন্স সমন্বয় হয়েছে', 'success');
      setDeleteSaleConfirm(null);
      loadData();
    } catch (error) {
      console.error('Error deleting sale:', error);
      showToast('বিক্রয় চালান মুছতে সমস্যা হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // One-Click Bulk Clear / Reset Data
  const handleClearData = async (target: 'expenses' | 'collections' | 'sales' | 'all') => {
    setIsDeleting(true);
    try {
      const res = await api.clearAccountingData(target);
      showToast(res.message || 'ডেটা সফলভাবে মুছে ফেলা হয়েছে', 'success');
      setClearTargetType(null);
      setClearDataModalOpen(false);
      loadData();
    } catch (error: any) {
      console.error('Error clearing data:', error);
      showToast(error.message || 'ডেটা মুছতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Save Collection
  const handleSaveCollection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectionForm.shop_id) {
      showToast('দোকান নির্বাচন করুন', 'error');
      return;
    }
    if (!collectionForm.amount || collectionForm.amount <= 0) {
      showToast('সঠিক কালেকশন পরিমাণ লিখুন', 'error');
      return;
    }

    try {
      await api.createCollection({
        ...collectionForm,
        shop_id: Number(collectionForm.shop_id),
        amount: Number(collectionForm.amount),
      });

      showToast('দোকান কালেকশন সফলভাবে সম্পন্ন হয়েছে', 'success');
      setIsCollectionModalOpen(false);
      loadData();
    } catch (error) {
      console.error('Error saving collection:', error);
      showToast('কালেকশন সংরক্ষণ করতে ব্যর্থ হয়েছে', 'error');
    }
  };

  // Single Voucher Print
  const handlePrintVoucher = (exp: Expense) => {
    const htmlContent = `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 25px; border: 2px solid #0f172a; border-radius: 8px; max-width: 650px; margin: 0 auto;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 15px;">
          <div>
            <h2 style="font-size: 18px; font-weight: bold; margin: 0; color: #0f172a;">টেক্স ওয়্যার অ্যাপারেলস</h2>
            <p style="font-size: 11px; margin: 2px 0 0 0; color: #64748b;">কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর • ফোন: ০১৭১১-২৩৪৫৬৭</p>
          </div>
          <div style="text-align: right;">
            <div style="display: inline-block; background-color: #fee2e2; color: #991b1b; padding: 3px 8px; border-radius: 4px; font-size: 12px; font-weight: bold;">
              ডেবিট ভাউচার (Expense Voucher)
            </div>
            <div style="font-size: 11px; font-weight: bold; font-family: monospace; margin-top: 4px;">ভাউচার: ${exp.voucher_no || (exp as any).expense_no || 'EXP'}</div>
            <div style="font-size: 11px; color: #64748b;">তারিখ: ${exp.date || (exp as any).expense_date || ''}</div>
          </div>
        </div>

        <div style="margin-bottom: 20px; font-size: 12px; line-height: 1.8;">
          <div style="display: flex; justify-content: space-between; border-bottom: 1px dashed #cbd5e1; padding-bottom: 4px; margin-bottom: 6px;">
            <span style="color: #64748b;">প্রাপকের নাম / কারখানায় প্রদান:</span>
            <span style="font-weight: bold; color: #0f172a;">${exp.paid_to || 'কারখানা'}</span>
          </div>
          <div style="display: flex; justify-content: space-between; border-bottom: 1px dashed #cbd5e1; padding-bottom: 4px; margin-bottom: 6px;">
            <span style="color: #64748b;">ব্যয়ের খাত (Expense Head):</span>
            <span style="font-weight: bold; color: #0f172a;">${exp.category}</span>
          </div>
          <div style="display: flex; justify-content: space-between; border-bottom: 1px dashed #cbd5e1; padding-bottom: 4px; margin-bottom: 6px;">
            <span style="color: #64748b;">পরিশোধ মাধ্যম:</span>
            <span style="font-weight: bold; color: #0f172a;">${exp.payment_method}</span>
          </div>
          <div style="display: flex; justify-content: space-between; border-bottom: 1px dashed #cbd5e1; padding-bottom: 4px; margin-bottom: 6px;">
            <span style="color: #64748b;">বিবরণ / ব্যাখ্যা:</span>
            <span style="color: #334155;">${exp.description || 'কারখানা প্রয়োজন'}</span>
          </div>
          <div style="display: flex; justify-content: space-between; background-color: #f8fafc; padding: 10px; border-radius: 6px; margin-top: 15px; border: 1px solid #e2e8f0;">
            <span style="font-size: 14px; font-weight: bold; color: #0f172a;">মোট প্রদেয় অর্থ:</span>
            <span style="font-size: 16px; font-weight: bold; color: #b91c1c; font-family: monospace;">${formatTk(exp.amount)}</span>
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; margin-top: 45px; padding-top: 10px; font-size: 11px;">
          <div style="text-align: center; width: 120px; border-top: 1px dashed #94a3b8; padding-top: 4px;">গ্রহীতার স্বাক্ষর</div>
          <div style="text-align: center; width: 120px; border-top: 1px dashed #94a3b8; padding-top: 4px;">ক্যাশিয়ার / হিসাবরক্ষক</div>
          <div style="text-align: center; width: 120px; border-top: 1px dashed #94a3b8; padding-top: 4px;">অনুমোদনকারী</div>
        </div>
      </div>
    `;

    printHtml(htmlContent, { title: `ভাউচার_${exp.voucher_no || (exp as any).expense_no || 'EXP'}` });
  };

  // Financial aggregates
  const totalSalesGross = sales.reduce((sum, s) => sum + (Number(s.gross_amount) || 0), 0);
  const totalSalesNet = sales.reduce((sum, s) => sum + (Number(s.net_amount) || 0), 0);
  const totalSalesPaid = sales.reduce((sum, s) => sum + (Number(s.paid_amount) || 0), 0);
  const totalSalesDue = sales.reduce((sum, s) => sum + (Number(s.due_amount) || 0), 0);

  const totalExpenseAmount = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const totalCollectionsAmount = collections.reduce((sum, c) => sum + (Number(c.amount) || 0), 0);
  const totalPayrollPayable = payrollPeriods.reduce((sum, p) => sum + (Number(p.total_net_payable) || 0), 0);
  const totalPayrollPaid = payrollPeriods.reduce((sum, p) => sum + (Number(p.total_paid) || 0), 0);
  const totalPayrollDue = payrollPeriods.reduce((sum, p) => sum + (Number(p.total_due) || 0), 0);

  const totalShopPurchased = shops.reduce((sum, s) => sum + (Number(s.total_purchased) || 0), 0);
  const totalShopPaid = shops.reduce((sum, s) => sum + (Number(s.total_paid) || 0), 0);
  const totalShopDue = shops.reduce((sum, s) => sum + (Number(s.current_due) || 0), 0);

  const totalCashIn = totalCollectionsAmount + totalSalesPaid;
  const totalCashOut = totalExpenseAmount;
  const netCashBalance = totalCashIn - totalCashOut;
  const netProfit = (financialStats?.totalSales || totalSalesNet) - (financialStats?.totalExpenses || totalExpenseAmount);

  // Category-wise Breakdown for Statement tab
  const categoryBreakdown = useMemo(() => {
    const map: { [cat: string]: number } = {};
    expenses.forEach((e) => {
      const cat = e.category || 'অন্যান্য';
      map[cat] = (map[cat] || 0) + (Number(e.amount) || 0);
    });

    return Object.entries(map).map(([category, amount]) => ({
      category,
      amount,
      percentage: totalExpenseAmount > 0 ? Math.round((amount / totalExpenseAmount) * 100) : 0,
    })).sort((a, b) => b.amount - a.amount);
  }, [expenses, totalExpenseAmount]);

  return (
    <div className="space-y-5 pb-12 font-['Hind_Siliguri',sans-serif]">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <Wallet className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              হিসাব-নিকাশ ও কারখানা খরচ (Accounting & Expenses)
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            টেক্স ওয়্যার অ্যাপারেলস • কারখানা খরচ, পাইকারি বিক্রয়, মার্কেট বাকি, নগদ কালেকশন ও সকল অফিশিয়াল প্রিন্ট অডিট
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Main Reports Print Button requested by user */}
          <button
            type="button"
            onClick={() => openReportModal('combined')}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs transition-colors"
          >
            <Printer className="w-4 h-4 text-white" />
            <span>রিপোর্ট প্রিন্ট মেনু (বেতন, বিক্রি, বাকি, ক্যাশ, খরচ)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (shops.length > 0) {
                setCollectionForm((prev) => ({ ...prev, shop_id: String(shops[0].id) }));
              }
              setIsCollectionModalOpen(true);
            }}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
            <span>দোকান বকেয়া কালেকশন</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setExpenseForm({
                category: 'কাঁচামাল ও ফেব্রিক (Fabric & Yarn)',
                amount: 5000,
                date: new Date().toISOString().split('T')[0],
                paid_to: '',
                payment_method: 'কারখানা ক্যাশ (Cash)',
                voucher_no: `EXP-${Date.now().toString().slice(-4)}`,
                description: '',
              });
              setIsExpenseModalOpen(true);
            }}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন কারখানা খরচ এন্ট্রি</span>
          </button>
        </div>
      </div>

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>মোট বিক্রয় আয় (Sales)</span>
            <span className="p-1 rounded bg-emerald-100 text-emerald-800 font-bold">
              <ArrowDownLeft className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-2">
            {formatTk(financialStats?.totalSales || totalSalesNet)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">সর্বমোট পাইকারি বিক্রয়</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>মোট কারখানা খরচ (Expenses)</span>
            <span className="p-1 rounded bg-rose-100 text-rose-800 font-bold">
              <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-black text-rose-700 font-mono mt-2">
            {formatTk(financialStats?.totalExpenses || totalExpenseAmount)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">ফেব্রিক, ভাড়া, বিদ্যুৎ ও ইউটিলিটি</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>নিট কারখানা মুনাফা (Profit)</span>
            <span className="p-1 rounded bg-blue-100 text-blue-800 font-bold">
              <TrendingUp className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className={`text-2xl font-black font-mono mt-2 ${netProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {formatTk(netProfit)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">মোট আয় হতে কারখানা ব্যয় বাদ</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>দোকানসমূহের বাকি (Total Due)</span>
            <span className="p-1 rounded bg-amber-100 text-amber-800 font-bold">
              <CreditCard className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-black text-amber-700 font-mono mt-2">
            {formatTk(financialStats?.totalShopDue || financialStats?.totalDues || totalShopDue)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">শোরুম ও পার্টিদের নিকট বকেয়া</p>
        </div>
      </div>

      {/* Secondary Quick Pill Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-600 font-medium">মোট ক্যাশ জমা:</span>
          <span className="font-bold text-teal-700 font-mono">{formatTk(totalCollectionsAmount)}</span>
        </div>
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-600 font-medium">কর্মী প্রদেয় বেতন:</span>
          <span className="font-bold text-blue-700 font-mono">{formatTk(totalPayrollPayable)}</span>
        </div>
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-600 font-medium">চালান সংখ্যা:</span>
          <span className="font-bold text-slate-800 font-mono">{sales.length} টি</span>
        </div>
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-600 font-medium">সক্রিয় দোকান:</span>
          <span className="font-bold text-slate-800 font-mono">{shops.length} টি</span>
        </div>
      </div>

      {/* Subtabs for All 6 Accounting Views */}
      <div className="flex items-center gap-1.5 overflow-x-auto border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('expenses')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'expenses'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>১. কারখানা পরিচালন খরচ ({expenses.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('collections')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'collections'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Banknote className="w-4 h-4" />
          <span>২. নগদ ক্যাশ ও কালেকশন ({collections.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sales')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'sales'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>৩. পাইকারি বিক্রয় ও চালান ({sales.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('dues')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'dues'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>৪. দোকান বাকি খাতা ({shops.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('payroll')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'payroll'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>৫. শ্রমিক বেতন ও ওভারটাইম ({payrollPeriods.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('statements')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'statements'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>৬. লাভ-লোকসান ও অডিট বিশ্লেষণ</span>
        </button>
      </div>

      {/* TAB 1: EXPENSES */}
      {activeTab === 'expenses' && (
        <div className="space-y-4">
          {/* Date-based Search & Filters for Expenses */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded bg-slate-100 text-slate-700">
                  <Filter className="w-4 h-4" />
                </span>
                <span className="font-bold text-sm text-slate-800">তারিখভিত্তিক খরচ খোঁজা ও ফিল্টার</span>
              </div>

              {/* Quick Date Presets */}
              <div className="flex items-center gap-1.5 flex-wrap text-xs">
                <button
                  type="button"
                  onClick={() => setQuickDateRange('today')}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium cursor-pointer transition-colors"
                >
                  আজ
                </button>
                <button
                  type="button"
                  onClick={() => setQuickDateRange('7days')}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium cursor-pointer transition-colors"
                >
                  গত ৭ দিন
                </button>
                <button
                  type="button"
                  onClick={() => setQuickDateRange('this_month')}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium cursor-pointer transition-colors"
                >
                  চলতি মাস
                </button>
                <button
                  type="button"
                  onClick={() => setQuickDateRange('all')}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium cursor-pointer transition-colors"
                >
                  সকল সময়
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">শুরুর তারিখ (Start Date)</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">শেষ তারিখ (End Date)</label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">খরচের খাত (Category)</label>
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
                >
                  <option value="all">সকল খাতের খরচ</option>
                  <option value="কাঁচামাল ও ফেব্রিক (Fabric & Yarn)">কাঁচামাল ও ফেব্রিক (Fabric & Yarn)</option>
                  <option value="শ্রমিক বেতন ও ভাতা (Wages & Salary)">শ্রমিক বেতন ও ভাতা (Wages & Salary)</option>
                  <option value="বিদ্যুৎ ও ইউটিলিটি (Electricity & Gas)">বিদ্যুৎ ও ইউটিলিটি (Electricity & Gas)</option>
                  <option value="মেশিন ও রক্ষণাবেক্ষণ (Maintenance)">মেশিন ও রক্ষণাবেক্ষণ (Maintenance)</option>
                  <option value="কারখানা ভাড়া (Factory Rent)">কারখানা ভাড়া (Factory Rent)</option>
                  <option value="যাতায়াত ও পরিবহন (Transport)">যাতায়াত ও পরিবহন (Transport)</option>
                  <option value="আপ্যায়ন ও বিবিধ (Entertainment & Misc)">আপ্যায়ন ও বিবিধ (Entertainment & Misc)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">ভাউচার / প্রাপক / বিবরণ খুঁজুন</label>
                <div className="relative">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="যেমন: EXP, ফেব্রিক, সালাম..."
                    className="w-full pl-8 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
                  {searchTerm && (
                    <button
                      type="button"
                      onClick={() => setSearchTerm('')}
                      className="absolute right-2.5 top-3 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Filter Summary Banner */}
            <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
              <div className="text-slate-500">
                ফিল্টারকৃত খরচ সংখ্যা: <span className="font-bold text-slate-800">{filteredExpenses.length} টি</span> • মোট খরচ:{' '}
                <span className="font-bold font-mono text-rose-700">{formatTk(totalFilteredExpense)}</span>
              </div>

              {(startDate || endDate || categoryFilter !== 'all' || searchTerm) && (
                <button
                  type="button"
                  onClick={() => {
                    setStartDate('');
                    setEndDate('');
                    setCategoryFilter('all');
                    setSearchTerm('');
                  }}
                  className="text-xs text-rose-600 hover:text-rose-700 font-semibold cursor-pointer"
                >
                  ফিল্টার রিসেট করুন
                </button>
              )}
            </div>
          </div>

          {/* Expenses History Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-800">কারখানা পরিচালন খরচ তালিকা ({filteredExpenses.length})</h3>
                <p className="text-xs text-slate-400">ভাউচারভিত্তিক হিসাব ট্র্যাকিং ও ডেবিট ভাউচার প্রিন্ট</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => openReportModal('expense')}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>খরচ রিপোর্ট প্রিন্ট</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                  <tr>
                    <th className="py-3.5 px-4">ভাউচার ও তারিখ</th>
                    <th className="py-3.5 px-4">খরচের খাত (Category)</th>
                    <th className="py-3.5 px-4">প্রাপক / ব্যক্তি</th>
                    <th className="py-3.5 px-4">বিবরণ / নোট</th>
                    <th className="py-3.5 px-4">পেমেন্ট মাধ্যম</th>
                    <th className="py-3.5 px-4 text-right">খরচ পরিমাণ</th>
                    <th className="py-3.5 px-4 text-center">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredExpenses.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-400">
                        নির্ধারিত তারিখ বা শর্তে কোনো খরচ পাওয়া যায়নি
                      </td>
                    </tr>
                  ) : (
                    filteredExpenses.map((exp) => (
                      <tr key={exp.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4">
                          <div className="font-mono font-bold text-slate-800">{exp.voucher_no || (exp as any).expense_no || 'EXP'}</div>
                          <div className="text-[11px] text-slate-400">{exp.date || (exp as any).expense_date}</div>
                        </td>

                        <td className="py-3 px-4">
                          <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-100">
                            {exp.category}
                          </span>
                        </td>

                        <td className="py-3 px-4 font-medium text-slate-700">{exp.paid_to || 'কারখানা'}</td>

                        <td className="py-3 px-4 text-slate-600 max-w-xs truncate">{exp.description || '—'}</td>

                        <td className="py-3 px-4 text-slate-500">{exp.payment_method}</td>

                        <td className="py-3 px-4 text-right font-black font-mono text-rose-700 text-sm">
                          {formatTk(exp.amount)}
                        </td>

                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handlePrintVoucher(exp)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer inline-flex items-center gap-1 text-[11px] font-medium"
                              title="ভাউচার প্রিন্ট করুন"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>ভাউচার</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteExpenseConfirm(exp)}
                              className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                              title="খরচ ডিলিট করুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: COLLECTIONS & CASH */}
      {activeTab === 'collections' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">দোকান কালেকশন জমা</span>
              <div className="text-xl font-bold text-teal-700 font-mono mt-1">{formatTk(totalCollectionsAmount)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">চালানে তাৎক্ষণিক নগদ প্রাপ্তি</span>
              <div className="text-xl font-bold text-emerald-700 font-mono mt-1">{formatTk(totalSalesPaid)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">মোট ক্যাশ খরচ পরিশোধ</span>
              <div className="text-xl font-bold text-rose-700 font-mono mt-1">{formatTk(totalCashOut)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">বর্তমান নেট ক্যাশ ব্যালেন্স</span>
              <div className="text-xl font-bold text-blue-700 font-mono mt-1">{formatTk(netCashBalance)}</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-800">দোকান কালেকশন ও ক্যাশ আদায় তালিকা ({collections.length})</h3>
                <p className="text-xs text-slate-400">শোরুম থেকে সংগৃহীত নগদ ক্যাশ, বিকাশ ও ব্যাংক জমা</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => openReportModal('cash')}
                  className="px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>ক্যাশ রিপোর্ট প্রিন্ট</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsCollectionModalOpen(true)}
                  className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন জমা এন্ট্রি</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                  <tr>
                    <th className="py-3 px-4">রসিদ নং</th>
                    <th className="py-3 px-4">তারিখ</th>
                    <th className="py-3 px-4">দোকানের নাম</th>
                    <th className="py-3 px-4 text-center">মাধ্যম</th>
                    <th className="py-3 px-4">আদায়কারী</th>
                    <th className="py-3 px-4 text-right">জমা ক্যাশ</th>
                    <th className="py-3 px-4 text-right">অবশিষ্ট বাকি</th>
                    <th className="py-3 px-4">নোট / রেফারেন্স</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {collections.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        কোনো কালেকশন এন্ট্রি নেই
                      </td>
                    </tr>
                  ) : (
                    collections.map((c) => (
                      <tr key={c.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-slate-800">{c.collection_no}</td>
                        <td className="py-3 px-4">{c.collection_date}</td>
                        <td className="py-3 px-4 font-semibold text-slate-800">{c.shop_name || 'দোকান'}</td>
                        <td className="py-3 px-4 text-center">
                          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium text-[10px]">
                            {c.payment_method || 'Cash'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-600">{c.collected_by || 'হিসাব শাখা'}</td>
                        <td className="py-3 px-4 text-right font-black font-mono text-emerald-700 text-sm">
                          {formatTk(c.amount)}
                        </td>
                        <td className="py-3 px-4 text-right font-bold font-mono text-amber-700">
                          {formatTk(c.remaining_due)}
                        </td>
                        <td className="py-3 px-4 text-slate-500">{c.notes || c.reference || '—'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: SALES & INVOICES */}
      {activeTab === 'sales' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">মোট গ্রস বিক্রয়</span>
              <div className="text-xl font-bold text-slate-900 font-mono mt-1">{formatTk(totalSalesGross)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">নিট বিক্রয় মূল্য</span>
              <div className="text-xl font-bold text-emerald-700 font-mono mt-1">{formatTk(totalSalesNet)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">নগদ আদায় (Cash)</span>
              <div className="text-xl font-bold text-emerald-600 font-mono mt-1">{formatTk(totalSalesPaid)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">চালানে বকেয়া বাকি</span>
              <div className="text-xl font-bold text-amber-600 font-mono mt-1">{formatTk(totalSalesDue)}</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-800">পাইকারি বিক্রয় ও মেমো চালান ({sales.length})</h3>
                <p className="text-xs text-slate-400">শোরুম ও পার্টির নিকট চালানের পরিমাণ, পরিশোধিত ও বকেয়া</p>
              </div>

              <button
                type="button"
                onClick={() => openReportModal('sales')}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>বিক্রয় রিপোর্ট প্রিন্ট</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                  <tr>
                    <th className="py-3 px-4">চালান নং</th>
                    <th className="py-3 px-4">তারিখ</th>
                    <th className="py-3 px-4">দোকান / ক্রেতা</th>
                    <th className="py-3 px-4 text-center">মাধ্যম</th>
                    <th className="py-3 px-4 text-right">মোট মূল্য</th>
                    <th className="py-3 px-4 text-right">পরিশোধ</th>
                    <th className="py-3 px-4 text-right">বকেয়া</th>
                    <th className="py-3 px-4 text-center">অবস্থা</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sales.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        কোনো বিক্রয় চালান পাওয়া যায়নি
                      </td>
                    </tr>
                  ) : (
                    sales.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-slate-800">{s.invoice_no}</td>
                        <td className="py-3 px-4">{s.sale_date}</td>
                        <td className="py-3 px-4 font-semibold text-slate-800">{s.shop_name || s.customer_name || 'সাধারণ ক্রেতা'}</td>
                        <td className="py-3 px-4 text-center">
                          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium text-[10px]">
                            {s.payment_method || 'Cash'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-slate-900">{formatTk(s.net_amount)}</td>
                        <td className="py-3 px-4 text-right font-bold text-emerald-700">{formatTk(s.paid_amount)}</td>
                        <td className="py-3 px-4 text-right font-bold text-amber-700">{formatTk(s.due_amount)}</td>
                        <td className="py-3 px-4 text-center">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            s.due_amount === 0 ? 'bg-emerald-100 text-emerald-800' : s.paid_amount > 0 ? 'bg-blue-100 text-blue-800' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {s.due_amount === 0 ? 'পরিশোধিত' : s.paid_amount > 0 ? 'আংশিক' : 'বকেয়া'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SHOP DUES LEDGER */}
      {activeTab === 'dues' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">মার্কেটে সর্বমোট মাল বিক্রয়</span>
              <div className="text-xl font-bold text-slate-900 font-mono mt-1">{formatTk(totalShopPurchased)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">দোকানসমূহ হতে মোট আদায়</span>
              <div className="text-xl font-bold text-emerald-700 font-mono mt-1">{formatTk(totalShopPaid)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">মার্কেটে বর্তমান মোট বাকি (Total Due)</span>
              <div className="text-xl font-bold text-amber-700 font-mono mt-1">{formatTk(totalShopDue)}</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-800">শোরুম ও পাইকারি দোকান খাতা ({shops.length})</h3>
                <p className="text-xs text-slate-400">প্রতিটি দোকানের ক্রয়, পরিশোধ ও বর্তমান বাকি ব্যালেন্স</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => openReportModal('due')}
                  className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>বাকি রিপোর্ট প্রিন্ট</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                  <tr>
                    <th className="py-3 px-4">কোড</th>
                    <th className="py-3 px-4">দোকানের নাম</th>
                    <th className="py-3 px-4">মালিকের নাম</th>
                    <th className="py-3 px-4">ফোন নম্বর</th>
                    <th className="py-3 px-4">ঠিকানা</th>
                    <th className="py-3 px-4 text-right">মোট ক্রয়</th>
                    <th className="py-3 px-4 text-right">মোট পরিশোধ</th>
                    <th className="py-3 px-4 text-right">বর্তমান বাকি</th>
                    <th className="py-3 px-4 text-center">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {shops.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-400">
                        কোনো দোকান তালিকাভুক্ত নেই
                      </td>
                    </tr>
                  ) : (
                    shops.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-slate-700">{s.shop_code || 'SHP'}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{s.name}</td>
                        <td className="py-3 px-4 text-slate-600">{s.owner_name || '—'}</td>
                        <td className="py-3 px-4 font-mono">{s.phone || '—'}</td>
                        <td className="py-3 px-4 text-slate-500">{s.address || '—'}</td>
                        <td className="py-3 px-4 text-right font-semibold">{formatTk(s.total_purchased)}</td>
                        <td className="py-3 px-4 text-right font-semibold text-emerald-700">{formatTk(s.total_paid)}</td>
                        <td className="py-3 px-4 text-right font-black font-mono text-amber-700 text-sm">
                          {formatTk(s.current_due)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              setCollectionForm((prev) => ({
                                ...prev,
                                shop_id: String(s.id),
                                amount: Number(s.current_due) > 0 ? Number(s.current_due) : 5000,
                              }));
                              setIsCollectionModalOpen(true);
                            }}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold rounded-lg text-[11px] cursor-pointer"
                          >
                            কালেকশন জমা
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: WORKER PAYROLL */}
      {activeTab === 'payroll' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">মোট প্রদেয় বেতন (Net Payable)</span>
              <div className="text-xl font-bold text-slate-900 font-mono mt-1">{formatTk(totalPayrollPayable)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">মোট পরিশোধিত বেতন (Paid)</span>
              <div className="text-xl font-bold text-emerald-700 font-mono mt-1">{formatTk(totalPayrollPaid)}</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">বকেয়া বেতন (Unpaid/Due)</span>
              <div className="text-xl font-bold text-rose-700 font-mono mt-1">{formatTk(totalPayrollDue)}</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-800">শ্রমিক ও কর্মচারী বেতন রেজিস্টার ({payrollPeriods.length})</h3>
                <p className="text-xs text-slate-400">মাসিক বেতন শিট, ওভারটাইম ঘণ্টা ও প্রদেয় মজুরি</p>
              </div>

              <button
                type="button"
                onClick={() => openReportModal('salary')}
                className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>বেতন রিপোর্ট প্রিন্ট</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[11px]">
                  <tr>
                    <th className="py-3 px-4">বেতন মাস</th>
                    <th className="py-3 px-4 text-center">কর্মী সংখ্যা</th>
                    <th className="py-3 px-4 text-center">মোট ওভারটাইম</th>
                    <th className="py-3 px-4 text-right">মূল বেতন</th>
                    <th className="py-3 px-4 text-right">নিট প্রদেয়</th>
                    <th className="py-3 px-4 text-right">পরিশোধ</th>
                    <th className="py-3 px-4 text-right">বকেয়া</th>
                    <th className="py-3 px-4 text-center">স্ট্যাটাস</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {payrollPeriods.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        কোনো বেতন রেকর্ড পাওয়া যায়নি
                      </td>
                    </tr>
                  ) : (
                    payrollPeriods.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-bold text-slate-900">{p.month_year}</td>
                        <td className="py-3 px-4 text-center">{p.total_employees || 0} জন</td>
                        <td className="py-3 px-4 text-center font-mono">{p.total_overtime_hours || 0} ঘণ্টা</td>
                        <td className="py-3 px-4 text-right font-semibold">{formatTk(p.total_gross_salary)}</td>
                        <td className="py-3 px-4 text-right font-black font-mono text-slate-900">{formatTk(p.total_net_payable)}</td>
                        <td className="py-3 px-4 text-right font-bold font-mono text-emerald-700">{formatTk(p.total_paid)}</td>
                        <td className="py-3 px-4 text-right font-bold font-mono text-rose-700">{formatTk(p.total_due)}</td>
                        <td className="py-3 px-4 text-center">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            p.status === 'completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {p.status === 'completed' ? 'পরিশোধিত' : 'প্রক্রিয়াধীন'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: STATEMENTS & AUDIT ANALYSIS */}
      {activeTab === 'statements' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Category Breakdown Progress Bars */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-800">কারখানা খরচের খাতভিত্তিক বিভাজন (Category Breakdown)</h3>
                  <p className="text-xs text-slate-400">কোন খাতে কত ব্যয় হচ্ছে তার শতকরা পরিসংখ্যান</p>
                </div>
                <span className="font-mono font-bold text-xs bg-rose-50 text-rose-700 px-2.5 py-1 rounded-lg">
                  মোট: {formatTk(totalExpenseAmount)}
                </span>
              </div>

              <div className="space-y-3 pt-2">
                {categoryBreakdown.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center">কোনো খরচ রেকর্ড নেই</p>
                ) : (
                  categoryBreakdown.map((cat, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-medium text-slate-700">{cat.category}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-bold font-mono text-slate-900">{formatTk(cat.amount)}</span>
                          <span className="text-[11px] text-slate-400 font-mono">({cat.percentage}%)</span>
                        </div>
                      </div>
                      <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            i === 0 ? 'bg-rose-500' : i === 1 ? 'bg-amber-500' : i === 2 ? 'bg-blue-500' : i === 3 ? 'bg-emerald-500' : 'bg-slate-400'
                          }`}
                          style={{ width: `${Math.min(cat.percentage, 100)}%` }}
                        />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Financial Health & Cash Flow Audit */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <h3 className="font-bold text-sm text-slate-800">সার্বিক লাভ-লোকসান ও আর্থিক স্বাস্থ্য বিবরণী</h3>
                <p className="text-xs text-slate-400">পাইকারি বিক্রয়, কারখানা ব্যয় এবং ক্যাশ প্রবাহ নিরীক্ষা</p>

                <div className="mt-4 space-y-2.5 text-xs">
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-600 font-medium">১. সর্বমোট বিক্রয় আয় (Sales Invoices):</span>
                    <span className="font-bold font-mono text-emerald-700">{formatTk(totalSalesNet)}</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-600 font-medium">২. সর্বমোট কারখানা খরচ (Total Expenses):</span>
                    <span className="font-bold font-mono text-rose-700">(-) {formatTk(totalExpenseAmount)}</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-600 font-medium">৩. শ্রমিক ও কর্মচারী প্রদেয় বেতন (Payroll):</span>
                    <span className="font-bold font-mono text-blue-700">{formatTk(totalPayrollPayable)}</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-slate-600 font-medium">৪. মার্কেটে বাকি পাওনা (Total Due):</span>
                    <span className="font-bold font-mono text-amber-700">{formatTk(totalShopDue)}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                    <span className="font-bold text-emerald-900">নিট অপারেটিং লাভ / উদ্বৃত্ত:</span>
                    <span className="text-base font-black font-mono text-emerald-800">{formatTk(netProfit)}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => openReportModal('combined')}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors text-xs"
              >
                <Printer className="w-4 h-4 text-emerald-400" />
                <span>সকল সমন্বিত আর্থিক রিপোর্ট প্রিন্ট করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Business Report Modal (বেতন, বিক্রি, বাকি, ক্যাশ, খরচ ও সমন্বিত অডিট) */}
      <BusinessReportModal
        isOpen={isReportsModalOpen}
        onClose={() => setIsReportsModalOpen(false)}
        initialReportType={selectedReportType}
        expenses={expenses}
        filteredExpenses={filteredExpenses}
        shops={shops}
        sales={sales}
        collections={collections}
        payrollPeriods={payrollPeriods}
        financialStats={financialStats}
        startDate={startDate}
        endDate={endDate}
      />

      {/* Delete Expense Confirmation Modal */}
      <Modal
        isOpen={!!deleteExpenseConfirm}
        onClose={() => setDeleteExpenseConfirm(null)}
        title="খরচের ভাউচার মুছে ফেলার নিশ্চয়তা"
        subtitle="ভুল এন্ট্রি হলে এই খরচ রেকর্ড ডাটাবেজ থেকে বাদ দেওয়া হবে"
        maxWidth="sm"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 space-y-1">
            <div className="font-bold text-sm">
              ভাউচার: {deleteExpenseConfirm?.voucher_no || (deleteExpenseConfirm as any)?.expense_no || 'EXP'}
            </div>
            <div>খাত: {deleteExpenseConfirm?.category}</div>
            <div>পরিমাণ: {formatTk(deleteExpenseConfirm?.amount)}</div>
            <div>তারিখ: {deleteExpenseConfirm?.date || (deleteExpenseConfirm as any)?.expense_date}</div>
          </div>
          <p className="text-slate-600">
            আপনি কি নিশ্চিত যে এই ভাউচারটি মুছে ফেলতে চান?
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setDeleteExpenseConfirm(null)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="button"
              onClick={handleDeleteExpense}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs"
            >
              হ্যাঁ, মুছে ফেলুন
            </button>
          </div>
        </div>
      </Modal>

      {/* Expense Modal */}
      <Modal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        title="নতুন কারখানা খরচ এন্ট্রি (Debit Voucher)"
        subtitle="ফেব্রিক, সুতা, কারিগর ভাতা ও ইউটিলিটি খরচ লিপিবদ্ধ করুন"
        maxWidth="md"
      >
        <form onSubmit={handleSaveExpense} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">ভাউচার নং</label>
              <input
                type="text"
                value={expenseForm.voucher_no}
                onChange={(e) => setExpenseForm({ ...expenseForm, voucher_no: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">তারিখ</label>
              <input
                type="date"
                value={expenseForm.date}
                onChange={(e) => setExpenseForm({ ...expenseForm, date: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">খরচের খাত (Expense Head)</label>
            <select
              value={expenseForm.category}
              onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            >
              <option value="কাঁচামাল ও ফেব্রিক (Fabric & Yarn)">কাঁচামাল ও ফেব্রিক (Fabric & Yarn)</option>
              <option value="শ্রমিক বেতন ও ভাতা (Wages & Salary)">শ্রমিক বেতন ও ভাতা (Wages & Salary)</option>
              <option value="বিদ্যুৎ ও ইউটিলিটি (Electricity & Gas)">বিদ্যুৎ ও ইউটিলিটি (Electricity & Gas)</option>
              <option value="মেশিন ও রক্ষণাবেক্ষণ (Maintenance)">মেশিন ও রক্ষণাবেক্ষণ (Maintenance)</option>
              <option value="কারখানা ভাড়া (Factory Rent)">কারখানা ভাড়া (Factory Rent)</option>
              <option value="যাতায়াত ও পরিবহন (Transport)">যাতায়াত ও পরিবহন (Transport)</option>
              <option value="আপ্যায়ন ও বিবিধ (Entertainment & Misc)">আপ্যায়ন ও বিবিধ (Entertainment & Misc)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">খরচের পরিমাণ (টাকা)</label>
              <input
                type="number"
                min={1}
                value={expenseForm.amount}
                onChange={(e) => setExpenseForm({ ...expenseForm, amount: Number(e.target.value) })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-rose-700 text-sm"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
              <select
                value={expenseForm.payment_method}
                onChange={(e) => setExpenseForm({ ...expenseForm, payment_method: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              >
                <option value="কারখানা ক্যাশ (Cash)">কারখানা ক্যাশ (Cash)</option>
                <option value="বিকাশ (bKash)">বিকাশ (bKash)</option>
                <option value="নগদ (Nagad)">নগদ (Nagad)</option>
                <option value="ব্যাংক একাউন্ট (Bank)">ব্যাংক একাউন্ট (Bank)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">প্রাপকের নাম বা প্রতিষ্ঠান</label>
            <input
              type="text"
              value={expenseForm.paid_to}
              onChange={(e) => setExpenseForm({ ...expenseForm, paid_to: e.target.value })}
              placeholder="যেমন: তুষার টেক্সটাইল / মেকানিক সালাম"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">বিস্তারিত বিবরণ</label>
            <input
              type="text"
              value={expenseForm.description}
              onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
              placeholder="খরচের কারণ বা চালানের বিবরণ..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsExpenseModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs"
            >
              খরচ সংরক্ষণ করুন
            </button>
          </div>
        </form>
      </Modal>

      {/* Collection Modal */}
      <Modal
        isOpen={isCollectionModalOpen}
        onClose={() => setIsCollectionModalOpen(false)}
        title="দোকান থেকে বকেয়া কালেকশন এন্ট্রি"
        subtitle="পাইকারি শোরুম থেকে প্রাপ্ত ক্যাশ বা বিকাশ অর্থ জমা করুন"
        maxWidth="md"
      >
        <form onSubmit={handleSaveCollection} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">দোকান নির্বাচন করুন</label>
            <select
              value={collectionForm.shop_id}
              onChange={(e) => setCollectionForm({ ...collectionForm, shop_id: e.target.value })}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
            >
              <option value="">দোকান বেছে নিন...</option>
              {shops.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} (বর্তমান বাকি: {formatTk(s.current_due)})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">কালেকশন পরিমাণ (টাকা)</label>
              <input
                type="number"
                min={1}
                value={collectionForm.amount}
                onChange={(e) => setCollectionForm({ ...collectionForm, amount: Number(e.target.value) })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-emerald-700 text-sm"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">জমার তারিখ</label>
              <input
                type="date"
                value={collectionForm.collection_date}
                onChange={(e) => setCollectionForm({ ...collectionForm, collection_date: e.target.value })}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">মাধ্যম</label>
              <select
                value={collectionForm.payment_method}
                onChange={(e) => setCollectionForm({ ...collectionForm, payment_method: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              >
                <option value="Cash">ক্যাশ (Cash)</option>
                <option value="bKash">বিকাশ (bKash)</option>
                <option value="Nagad">নগদ (Nagad)</option>
                <option value="Bank">ব্যাংক ডিপোজিট (Bank)</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">ট্রানজেকশন রেফ / স্লিপ নং</label>
              <input
                type="text"
                value={collectionForm.reference}
                onChange={(e) => setCollectionForm({ ...collectionForm, reference: e.target.value })}
                placeholder="যেমন: TRX981273"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">মন্তব্য</label>
            <input
              type="text"
              value={collectionForm.notes}
              onChange={(e) => setCollectionForm({ ...collectionForm, notes: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCollectionModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs"
            >
              জমা সম্পন্ন করুন
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
