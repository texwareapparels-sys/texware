import React, { useState, useMemo } from 'react';
import {
  Printer,
  FileText,
  ExternalLink,
  Users,
  ShoppingBag,
  CreditCard,
  Banknote,
  Receipt,
  PieChart,
  CheckCircle2,
  Sliders,
  RotateCcw
} from 'lucide-react';
import { Modal } from '../common/Modal';
import { printHtml, openReportInNewTab } from '../../utils/printDocument';
import { Expense, Shop } from '../../types';

export type BusinessReportType = 'salary' | 'sales' | 'due' | 'cash' | 'expense' | 'combined';

interface BusinessReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialReportType?: BusinessReportType;
  expenses: Expense[];
  filteredExpenses: Expense[];
  shops: Shop[];
  sales: any[];
  collections: any[];
  payrollPeriods: any[];
  financialStats: any;
  startDate?: string;
  endDate?: string;
}

export const BusinessReportModal: React.FC<BusinessReportModalProps> = ({
  isOpen,
  onClose,
  initialReportType = 'combined',
  expenses,
  filteredExpenses,
  shops,
  sales,
  collections,
  payrollPeriods,
  financialStats,
  startDate,
  endDate,
}) => {
  const [selectedReport, setSelectedReport] = useState<BusinessReportType>(initialReportType);
  const [landscape, setLandscape] = useState<boolean>(false);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);

  // Sync initial type when modal opens or prop changes
  React.useEffect(() => {
    if (isOpen) {
      setSelectedReport(initialReportType);
    }
  }, [isOpen, initialReportType]);

  // Report Definitions
  const reportTabs: { id: BusinessReportType; label: string; icon: React.ReactNode; color: string }[] = [
    { id: 'salary', label: '১. বেতন রিপোর্ট', icon: <Users className="w-3.5 h-3.5" />, color: 'blue' },
    { id: 'sales', label: '২. বিক্রি রিপোর্ট', icon: <ShoppingBag className="w-3.5 h-3.5" />, color: 'emerald' },
    { id: 'due', label: '৩. বাকি রিপোর্ট', icon: <CreditCard className="w-3.5 h-3.5" />, color: 'amber' },
    { id: 'cash', label: '৪. ক্যাশ রিপোর্ট', icon: <Banknote className="w-3.5 h-3.5" />, color: 'teal' },
    { id: 'expense', label: '৫. খরচ রিপোর্ট', icon: <Receipt className="w-3.5 h-3.5" />, color: 'rose' },
    { id: 'combined', label: '৬. পূর্ণাঙ্গ অডিট', icon: <PieChart className="w-3.5 h-3.5" />, color: 'slate' },
  ];

  // 1. বেতন রিপোর্ট (Salary)
  const generateSalaryHtml = () => {
    const totalPayrollPaid = payrollPeriods.reduce((sum, p) => sum + (Number(p.total_paid) || 0), 0);
    const totalPayrollDue = payrollPeriods.reduce((sum, p) => sum + (Number(p.total_due) || 0), 0);
    const totalPayrollNet = payrollPeriods.reduce((sum, p) => sum + (Number(p.total_net_payable) || 0), 0);

    const rowsHtml = payrollPeriods.length > 0
      ? payrollPeriods.map((p, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 6px 8px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px 8px; font-weight: bold;">${p.month_year}</td>
          <td style="padding: 6px 8px; text-align: center;">${p.total_employees || 0} জন</td>
          <td style="padding: 6px 8px; text-align: center;">${p.total_overtime_hours || 0} ঘণ্টা</td>
          <td style="padding: 6px 8px; text-align: right; font-weight: 600;">৳ ${(p.total_gross_salary || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; font-weight: bold;">৳ ${(p.total_net_payable || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; color: #047857; font-weight: bold;">৳ ${(p.total_paid || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; color: #b91c1c; font-weight: bold;">৳ ${(p.total_due || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: center;">
            <span style="padding: 2px 6px; border-radius: 4px; font-size: 10px; background-color: ${p.status === 'completed' ? '#dcfce7; color: #15803d' : '#fef3c7; color: #b45309'};">
              ${p.status === 'completed' ? 'পরিশোধিত' : 'প্রক্রিয়াধীন'}
            </span>
          </td>
        </tr>
      `).join('')
      : `<tr><td colspan="9" style="text-align: center; padding: 20px; color: #94a3b8;">কোনো বেতন রেকর্ড পাওয়া যায়নি</td></tr>`;

    return `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 15px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 15px;">
          <div>
            <h1 style="font-size: 20px; font-weight: bold; margin: 0; color: #0f172a;">টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p style="font-size: 12px; margin: 2px 0 0 0; color: #64748b;">কোনাবাড়ী শিল্প এলাকা, গাজীপুর • স্মার্ট গার্মেন্টস ইআরপি</p>
            <p style="font-size: 14px; font-weight: bold; margin-top: 4px; color: #1d4ed8;">কারখানা শ্রমিক ও কর্মচারীদের মাসিক বেতন ও ওভারটাইম রিপোর্ট</p>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 12px; font-weight: bold; background-color: #f1f5f9; padding: 4px 10px; border-radius: 6px;">
              প্রিন্ট তারিখ: ${new Date().toLocaleDateString('bn-BD')}
            </div>
            <div style="font-size: 11px; color: #64748b; margin-top: 4px;">বেতন শিট সংখ্যা: ${payrollPeriods.length} টি</div>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 6px;">
            <div style="color: #64748b;">মোট প্রদেয় বেতন (Net Payable)</div>
            <div style="font-size: 16px; font-weight: bold; color: #0f172a;">৳ ${totalPayrollNet.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 6px;">
            <div style="color: #166534;">মোট পরিশোধিত বেতন (Paid)</div>
            <div style="font-size: 16px; font-weight: bold; color: #15803d;">৳ ${totalPayrollPaid.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #fef2f2; border: 1px solid #fecaca; padding: 10px; border-radius: 6px;">
            <div style="color: #991b1b;">মোট বকেয়া বেতন (Unpaid/Due)</div>
            <div style="font-size: 16px; font-weight: bold; color: #b91c1c;">৳ ${totalPayrollDue.toLocaleString('bn-BD')}</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #cbd5e1; font-size: 11px; text-align: left;">
              <th style="padding: 7px 8px; text-align: center;">#</th>
              <th style="padding: 7px 8px;">বেতন মাস</th>
              <th style="padding: 7px 8px; text-align: center;">কর্মী সংখ্যা</th>
              <th style="padding: 7px 8px; text-align: center;">মোট ওভারটাইম</th>
              <th style="padding: 7px 8px; text-align: right;">মোট মূল বেতন</th>
              <th style="padding: 7px 8px; text-align: right;">নিট প্রদেয় বেতন</th>
              <th style="padding: 7px 8px; text-align: right;">পরিশোধ</th>
              <th style="padding: 7px 8px; text-align: right;">বকেয়া</th>
              <th style="padding: 7px 8px; text-align: center;">স্ট্যাটাস</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; margin-top: 45px; padding-top: 15px; font-size: 11px;">
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">এইচ আর / হিসাবরক্ষক</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">কারখানা ব্যবস্থাপক</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">স্বত্বাধিকারী / পরিচালক</div>
        </div>
      </div>
    `;
  };

  // 2. বিক্রি রিপোর্ট (Sales)
  const generateSalesHtml = () => {
    const totalGross = sales.reduce((sum, s) => sum + (Number(s.gross_amount) || 0), 0);
    const totalNet = sales.reduce((sum, s) => sum + (Number(s.net_amount) || 0), 0);
    const totalPaid = sales.reduce((sum, s) => sum + (Number(s.paid_amount) || 0), 0);
    const totalDue = sales.reduce((sum, s) => sum + (Number(s.due_amount) || 0), 0);

    const rowsHtml = sales.length > 0
      ? sales.map((s, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 6px 8px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px 8px; font-weight: bold; font-family: monospace;">${s.invoice_no}</td>
          <td style="padding: 6px 8px;">${s.sale_date || ''}</td>
          <td style="padding: 6px 8px; font-weight: 600;">${s.shop_name || s.customer_name || 'সাধারণ ক্রেতা'}</td>
          <td style="padding: 6px 8px; text-align: center;">${s.payment_method || 'Cash'}</td>
          <td style="padding: 6px 8px; text-align: right; font-weight: 600;">৳ ${(Number(s.net_amount) || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; color: #047857; font-weight: bold;">৳ ${(Number(s.paid_amount) || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; color: #ea580c; font-weight: bold;">৳ ${(Number(s.due_amount) || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: center;">
            <span style="padding: 2px 6px; border-radius: 4px; font-size: 10px; background-color: ${s.due_amount === 0 ? '#dcfce7; color: #15803d' : s.paid_amount > 0 ? '#eff6ff; color: #1d4ed8' : '#fee2e2; color: #b91c1c'};">
              ${s.due_amount === 0 ? 'পরিশোধিত' : s.paid_amount > 0 ? 'আংশিক' : 'বকেয়া'}
            </span>
          </td>
        </tr>
      `).join('')
      : `<tr><td colspan="9" style="text-align: center; padding: 20px; color: #94a3b8;">কোনো বিক্রয় চালান পাওয়া যায়নি</td></tr>`;

    return `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 15px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 15px;">
          <div>
            <h1 style="font-size: 20px; font-weight: bold; margin: 0; color: #0f172a;">টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p style="font-size: 12px; margin: 2px 0 0 0; color: #64748b;">কোনাবাড়ী শিল্প এলাকা, গাজীপুর • পাইকারি গেঞ্জি সেলস শাখা</p>
            <p style="font-size: 14px; font-weight: bold; margin-top: 4px; color: #059669;">পাইকারি গেঞ্জি বিক্রয় ও মেমো চালান রিপোর্ট</p>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 12px; font-weight: bold; background-color: #f1f5f9; padding: 4px 10px; border-radius: 6px;">
              প্রিন্ট তারিখ: ${new Date().toLocaleDateString('bn-BD')}
            </div>
            <div style="font-size: 11px; color: #64748b; margin-top: 4px;">মোট চালান: ${sales.length} টি</div>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 8px; border-radius: 6px;">
            <div style="color: #64748b;">মোট গ্রস বিক্রয়</div>
            <div style="font-size: 15px; font-weight: bold; color: #0f172a;">৳ ${totalGross.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 8px; border-radius: 6px;">
            <div style="color: #64748b;">নিট বিক্রয় মূল্য (Net)</div>
            <div style="font-size: 15px; font-weight: bold; color: #059669;">৳ ${totalNet.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 8px; border-radius: 6px;">
            <div style="color: #166534;">নগদ আদায় (Paid Cash)</div>
            <div style="font-size: 15px; font-weight: bold; color: #15803d;">৳ ${totalPaid.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #fff7ed; border: 1px solid #fed7aa; padding: 8px; border-radius: 6px;">
            <div style="color: #9a3412;">মার্কেট বকেয়া (Due)</div>
            <div style="font-size: 15px; font-weight: bold; color: #ea580c;">৳ ${totalDue.toLocaleString('bn-BD')}</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #cbd5e1; font-size: 11px; text-align: left;">
              <th style="padding: 7px 8px; text-align: center;">#</th>
              <th style="padding: 7px 8px;">চালান নং</th>
              <th style="padding: 7px 8px;">তারিখ</th>
              <th style="padding: 7px 8px;">দোকান / ক্রেতা</th>
              <th style="padding: 7px 8px; text-align: center;">মাধ্যম</th>
              <th style="padding: 7px 8px; text-align: right;">মোট মূল্য</th>
              <th style="padding: 7px 8px; text-align: right;">পরিশোধ</th>
              <th style="padding: 7px 8px; text-align: right;">বকেয়া</th>
              <th style="padding: 7px 8px; text-align: center;">অবস্থা</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; margin-top: 45px; padding-top: 15px; font-size: 11px;">
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">সেলস এক্সিকিউটিভ</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">হিসাব নিরীক্ষক</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">পরিচালক / স্বত্বাধিকারী</div>
        </div>
      </div>
    `;
  };

  // 3. বাকি রিপোর্ট (Due)
  const generateDueHtml = () => {
    const shopsWithDue = shops.filter((s) => (Number(s.current_due) || 0) > 0);
    const totalDue = shops.reduce((sum, s) => sum + (Number(s.current_due) || 0), 0);
    const totalPurchased = shops.reduce((sum, s) => sum + (Number(s.total_purchased) || 0), 0);
    const totalPaid = shops.reduce((sum, s) => sum + (Number(s.total_paid) || 0), 0);

    const rowsHtml = shopsWithDue.length > 0
      ? shopsWithDue.map((s, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 6px 8px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px 8px; font-weight: bold; font-family: monospace;">${s.shop_code || 'SHP'}</td>
          <td style="padding: 6px 8px; font-weight: bold; color: #0f172a;">${s.name}</td>
          <td style="padding: 6px 8px;">${s.owner_name || '—'}</td>
          <td style="padding: 6px 8px; font-family: monospace;">${s.phone || '—'}</td>
          <td style="padding: 6px 8px; color: #64748b;">${s.address || '—'}</td>
          <td style="padding: 6px 8px; text-align: right;">৳ ${(Number(s.total_purchased) || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; color: #15803d;">৳ ${(Number(s.total_paid) || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; font-weight: bold; color: #ea580c; font-size: 12px;">৳ ${(Number(s.current_due) || 0).toLocaleString('bn-BD')}</td>
        </tr>
      `).join('')
      : `<tr><td colspan="9" style="text-align: center; padding: 20px; color: #15803d;">আলহামদুলিল্লাহ, কোনো বকেয়া বা বাকি নেই!</td></tr>`;

    return `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 15px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 15px;">
          <div>
            <h1 style="font-size: 20px; font-weight: bold; margin: 0; color: #0f172a;">টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p style="font-size: 12px; margin: 2px 0 0 0; color: #64748b;">কোনাবাড়ী শিল্প এলাকা, গাজীপুর • পাইকারি গেঞ্জি সেলস শাখা</p>
            <p style="font-size: 14px; font-weight: bold; margin-top: 4px; color: #ea580c;">দোকান ও পাইকারি পার্টির মার্কেট বাকি (Due) লেজার খাতা</p>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 12px; font-weight: bold; background-color: #f1f5f9; padding: 4px 10px; border-radius: 6px;">
              প্রিন্ট তারিখ: ${new Date().toLocaleDateString('bn-BD')}
            </div>
            <div style="font-size: 11px; color: #64748b; margin-top: 4px;">বাকিযুক্ত দোকান: ${shopsWithDue.length} টি</div>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 6px;">
            <div style="color: #64748b;">মার্কেটে সর্বমোট মাল বিক্রয়</div>
            <div style="font-size: 16px; font-weight: bold; color: #0f172a;">৳ ${totalPurchased.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 6px;">
            <div style="color: #166534;">দোকানসমূহ হতে মোট আদায়</div>
            <div style="font-size: 16px; font-weight: bold; color: #15803d;">৳ ${totalPaid.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #fff7ed; border: 1px solid #fed7aa; padding: 10px; border-radius: 6px;">
            <div style="color: #9a3412;">মার্কেটে বর্তমান মোট বাকি (Total Due)</div>
            <div style="font-size: 16px; font-weight: bold; color: #ea580c;">৳ ${totalDue.toLocaleString('bn-BD')}</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #cbd5e1; font-size: 11px; text-align: left;">
              <th style="padding: 7px 8px; text-align: center;">#</th>
              <th style="padding: 7px 8px;">কোড</th>
              <th style="padding: 7px 8px;">দোকানের নাম</th>
              <th style="padding: 7px 8px;">মালিকের নাম</th>
              <th style="padding: 7px 8px;">ফোন নম্বর</th>
              <th style="padding: 7px 8px;">ঠিকানা</th>
              <th style="padding: 7px 8px; text-align: right;">মোট ক্রয়</th>
              <th style="padding: 7px 8px; text-align: right;">মোট জমা</th>
              <th style="padding: 7px 8px; text-align: right;">বর্তমান বাকি</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
            <tr style="background-color: #f1f5f9; font-weight: bold; border-top: 2px solid #94a3b8; font-size: 12px;">
              <td colspan="8" style="padding: 8px; text-align: right;">সর্বমোট মার্কেট বকেয়া পাওনা:</td>
              <td style="padding: 8px; text-align: right; color: #ea580c;">৳ ${totalDue.toLocaleString('bn-BD')}</td>
            </tr>
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; margin-top: 45px; padding-top: 15px; font-size: 11px;">
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">কালেকশন অফিসার</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">হিসাবরক্ষক</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">কারখানা মালিক / পরিচালক</div>
        </div>
      </div>
    `;
  };

  // 4. ক্যাশ রিপোর্ট (Cash)
  const generateCashHtml = () => {
    const totalCollection = collections.reduce((sum, c) => sum + (Number(c.amount) || 0), 0);
    const totalSalesCash = sales.reduce((sum, s) => sum + (Number(s.paid_amount) || 0), 0);
    const totalCashIn = totalCollection + totalSalesCash;
    const totalCashOut = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const netCashBalance = totalCashIn - totalCashOut;

    const rowsHtml = collections.length > 0
      ? collections.map((c, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 6px 8px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px 8px; font-weight: bold; font-family: monospace;">${c.collection_no}</td>
          <td style="padding: 6px 8px;">${c.collection_date || ''}</td>
          <td style="padding: 6px 8px; font-weight: 600;">${c.shop_name || 'দোকান'}</td>
          <td style="padding: 6px 8px; text-align: center;">${c.payment_method || 'Cash'}</td>
          <td style="padding: 6px 8px; color: #64748b;">${c.collected_by || 'হিসাব শাখা'}</td>
          <td style="padding: 6px 8px; text-align: right; color: #15803d; font-weight: bold;">৳ ${(Number(c.amount) || 0).toLocaleString('bn-BD')}</td>
          <td style="padding: 6px 8px; text-align: right; color: #ea580c;">৳ ${(Number(c.remaining_due) || 0).toLocaleString('bn-BD')}</td>
        </tr>
      `).join('')
      : `<tr><td colspan="8" style="text-align: center; padding: 20px; color: #94a3b8;">কোনো কালেকশন এন্ট্রি নেই</td></tr>`;

    return `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 15px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 15px;">
          <div>
            <h1 style="font-size: 20px; font-weight: bold; margin: 0; color: #0f172a;">টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p style="font-size: 12px; margin: 2px 0 0 0; color: #64748b;">কোনাবাড়ী শিল্প এলাকা, গাজীপুর • কারখানা ক্যাশ ও অ্যাকাউন্টস শাখা</p>
            <p style="font-size: 14px; font-weight: bold; margin-top: 4px; color: #047857;">দৈনিক ক্যাশ ও নগদ অর্থ আদায় বিবরণী রিপোর্ট</p>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 12px; font-weight: bold; background-color: #f1f5f9; padding: 4px 10px; border-radius: 6px;">
              প্রিন্ট তারিখ: ${new Date().toLocaleDateString('bn-BD')}
            </div>
            <div style="font-size: 11px; color: #64748b; margin-top: 4px;">মোট আদায় ট্রানজেকশন: ${collections.length} টি</div>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 8px; border-radius: 6px;">
            <div style="color: #166534;">দোকান কালেকশন আদায়</div>
            <div style="font-size: 15px; font-weight: bold; color: #15803d;">৳ ${totalCollection.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 8px; border-radius: 6px;">
            <div style="color: #166534;">চালানে তাৎক্ষণিক নগদ প্রাপ্তি</div>
            <div style="font-size: 15px; font-weight: bold; color: #15803d;">৳ ${totalSalesCash.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #fef2f2; border: 1px solid #fecaca; padding: 8px; border-radius: 6px;">
            <div style="color: #991b1b;">কারখানা পরিচালন খরচ পরিশোধ</div>
            <div style="font-size: 15px; font-weight: bold; color: #b91c1c;">৳ ${totalCashOut.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; padding: 8px; border-radius: 6px;">
            <div style="color: #1e40af;">বর্তমান নেট ক্যাশ স্থিতি</div>
            <div style="font-size: 15px; font-weight: bold; color: #1d4ed8;">৳ ${netCashBalance.toLocaleString('bn-BD')}</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #cbd5e1; font-size: 11px; text-align: left;">
              <th style="padding: 7px 8px; text-align: center;">#</th>
              <th style="padding: 7px 8px;">রসিদ নং</th>
              <th style="padding: 7px 8px;">তারিখ</th>
              <th style="padding: 7px 8px;">দোকান / উৎস</th>
              <th style="padding: 7px 8px; text-align: center;">মাধ্যম</th>
              <th style="padding: 7px 8px;">আদায়কারী</th>
              <th style="padding: 7px 8px; text-align: right;">জমা ক্যাশ</th>
              <th style="padding: 7px 8px; text-align: right;">অবশিষ্ট বাকি</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
            <tr style="background-color: #f1f5f9; font-weight: bold; border-top: 2px solid #94a3b8; font-size: 12px;">
              <td colspan="6" style="padding: 8px; text-align: right;">মোট সংগৃহীত ক্যাশ অর্থ:</td>
              <td style="padding: 8px; text-align: right; color: #15803d;">৳ ${totalCollection.toLocaleString('bn-BD')}</td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; margin-top: 45px; padding-top: 15px; font-size: 11px;">
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">ক্যাশিয়ার</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">হিসাব ব্যবস্থাপক</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">মালিক / পরিচালক</div>
        </div>
      </div>
    `;
  };

  // 5. খরচ রিপোর্ট (Expense)
  const generateExpenseHtml = () => {
    const listToUse = filteredExpenses.length > 0 ? filteredExpenses : expenses;
    const totalFiltered = listToUse.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

    const rowsHtml = listToUse.length > 0
      ? listToUse.map((exp, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 6px 8px; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px 8px; font-weight: bold; font-family: monospace;">${exp.voucher_no || (exp as any).expense_no || 'EXP'}</td>
          <td style="padding: 6px 8px;">${exp.date || (exp as any).expense_date || ''}</td>
          <td style="padding: 6px 8px; font-weight: 600;">${exp.category}</td>
          <td style="padding: 6px 8px;">${exp.paid_to || 'কারখানা'}</td>
          <td style="padding: 6px 8px; color: #475569;">${exp.description || '—'}</td>
          <td style="padding: 6px 8px; text-align: center;">${exp.payment_method || 'Cash'}</td>
          <td style="padding: 6px 8px; text-align: right; font-weight: bold; color: #b91c1c;">৳ ${(Number(exp.amount) || 0).toLocaleString('bn-BD')}</td>
        </tr>
      `).join('')
      : `<tr><td colspan="8" style="text-align: center; padding: 20px; color: #94a3b8;">কোনো খরচ রেকর্ড পাওয়া যায়নি</td></tr>`;

    return `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 15px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 15px;">
          <div>
            <h1 style="font-size: 20px; font-weight: bold; margin: 0; color: #0f172a;">টেক্স ওয়্যার অ্যাপারেলস</h1>
            <p style="font-size: 12px; margin: 2px 0 0 0; color: #64748b;">কোনাবাড়ী শিল্প এলাকা, গাজীপুর • কারখানা অ্যাকাউন্টস শাখা</p>
            <p style="font-size: 14px; font-weight: bold; margin-top: 4px; color: #b91c1c;">তারিখভিত্তিক কারখানা খরচ ও ক্যাশবুক লেজার শিট</p>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 12px; font-weight: bold; background-color: #f1f5f9; padding: 4px 10px; border-radius: 6px;">
              তারিখ: ${new Date().toLocaleDateString('bn-BD')}
            </div>
            <div style="font-size: 11px; color: #64748b; margin-top: 4px;">
              ${startDate && endDate ? `সময়কাল: ${startDate} থেকে ${endDate}` : 'সকল খরচ'} (${listToUse.length} টি ভাউচার)
            </div>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 15px; font-size: 11px;">
          <div style="background-color: #fef2f2; border: 1px solid #fecaca; padding: 10px; border-radius: 6px;">
            <div style="color: #991b1b;">ফিল্টারকৃত সর্বমোট খরচ</div>
            <div style="font-size: 16px; font-weight: bold; color: #b91c1c;">৳ ${totalFiltered.toLocaleString('bn-BD')}</div>
          </div>
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 6px;">
            <div style="color: #64748b;">মোট ভাউচার সংখ্যা</div>
            <div style="font-size: 16px; font-weight: bold; color: #0f172a;">${listToUse.length} টি</div>
          </div>
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 6px;">
            <div style="color: #166534;">নিট কারখানা বিক্রয়</div>
            <div style="font-size: 16px; font-weight: bold; color: #15803d;">৳ ${(financialStats?.totalSales || 0).toLocaleString('bn-BD')}</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f8fafc; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #cbd5e1; font-size: 11px; text-align: left;">
              <th style="padding: 7px 8px; text-align: center;">#</th>
              <th style="padding: 7px 8px;">ভাউচার নং</th>
              <th style="padding: 7px 8px;">তারিখ</th>
              <th style="padding: 7px 8px;">খরচের খাত</th>
              <th style="padding: 7px 8px;">প্রাপক / ব্যক্তি</th>
              <th style="padding: 7px 8px;">বিবরণ</th>
              <th style="padding: 7px 8px; text-align: center;">মাধ্যম</th>
              <th style="padding: 7px 8px; text-align: right;">পরিমাণ</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
            <tr style="background-color: #f1f5f9; font-weight: bold; border-top: 2px solid #94a3b8; font-size: 12px;">
              <td colspan="7" style="padding: 8px; text-align: right;">সর্বমোট কারখানা ব্যয়:</td>
              <td style="padding: 8px; text-align: right; color: #b91c1c;">৳ ${totalFiltered.toLocaleString('bn-BD')}</td>
            </tr>
          </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; margin-top: 45px; padding-top: 15px; font-size: 11px;">
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">হিসাবরক্ষক</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">ফ্যাক্টরি ম্যানেজার</div>
          <div style="text-align: center; width: 140px; border-top: 1px dashed #94a3b8; padding-top: 5px;">মালিক / পরিচালক</div>
        </div>
      </div>
    `;
  };

  // 6. সমন্বিত আর্থিক প্রতিবেদন (Combined Audit)
  const generateCombinedHtml = () => {
    const totalSales = sales.reduce((sum, s) => sum + (Number(s.net_amount) || 0), 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const totalSalaries = payrollPeriods.reduce((sum, p) => sum + (Number(p.total_net_payable) || 0), 0);
    const totalDue = shops.reduce((sum, s) => sum + (Number(s.current_due) || 0), 0);
    const totalCashCollections = collections.reduce((sum, c) => sum + (Number(c.amount) || 0), 0);
    const netProfit = totalSales - totalExpenses;

    return `
      <div style="font-family: 'Hind Siliguri', 'Segoe UI', Tahoma, sans-serif; color: #1e293b; padding: 20px;">
        <div style="text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 15px; margin-bottom: 20px;">
          <h1 style="font-size: 24px; font-weight: bold; margin: 0; color: #0f172a;">টেক্স ওয়্যার অ্যাপারেলস</h1>
          <p style="font-size: 13px; margin: 3px 0 0 0; color: #64748b;">কোনাবাড়ী শিল্প এলাকা, গাজীপুর • স্মার্ট গার্মেন্টস ইআরপি ও ফিন্যান্সিয়াল স্টেটমেন্ট</p>
          <div style="margin-top: 8px; display: inline-block; background-color: #0f172a; color: #ffffff; padding: 4px 14px; border-radius: 4px; font-size: 13px; font-weight: bold;">
            সার্বিক সমন্বিত ব্যবসায়িক অডিট ও লাভ-লোকসান প্রতিবেদন
          </div>
          <p style="font-size: 11px; color: #64748b; margin-top: 6px;">
            প্রস্তুতের তারিখ: ${new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        <h3 style="font-size: 14px; font-weight: bold; margin-bottom: 10px; color: #0f172a; border-left: 4px solid #1d4ed8; padding-left: 8px;">
          মূল ৬টি ব্যবসায়িক সূচক সারসংক্ষেপ (Key Financial Indicators)
        </h3>

        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; font-size: 12px;">
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
            <div style="color: #166534; font-weight: 600;">১. মোট পাইকারি বিক্রয় (Sales)</div>
            <div style="font-size: 18px; font-weight: bold; color: #15803d; margin-top: 4px;">৳ ${totalSales.toLocaleString('bn-BD')}</div>
            <div style="font-size: 10px; color: #166534; margin-top: 2px;">মোট ${sales.length} টি পাইকারি চালান</div>
          </div>

          <div style="background-color: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px;">
            <div style="color: #991b1b; font-weight: 600;">২. মোট কারখানা পরিচালন ব্যয় (Expenses)</div>
            <div style="font-size: 18px; font-weight: bold; color: #b91c1c; margin-top: 4px;">৳ ${totalExpenses.toLocaleString('bn-BD')}</div>
            <div style="font-size: 10px; color: #991b1b; margin-top: 2px;">মোট ${expenses.length} টি অনুমোদিত ভাউচার</div>
          </div>

          <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; padding: 12px; border-radius: 8px;">
            <div style="color: #1e40af; font-weight: 600;">৩. নিট কারখানা মুনাফা (Net Profit)</div>
            <div style="font-size: 18px; font-weight: bold; color: #1d4ed8; margin-top: 4px;">৳ ${netProfit.toLocaleString('bn-BD')}</div>
            <div style="font-size: 10px; color: #1e40af; margin-top: 2px;">মোট বিক্রয় হতে সমস্ত কারখানা ব্যয় বাদ</div>
          </div>

          <div style="background-color: #fff7ed; border: 1px solid #fed7aa; padding: 12px; border-radius: 8px;">
            <div style="color: #9a3412; font-weight: 600;">৪. মার্কেট বাকি পাওনা (Market Due)</div>
            <div style="font-size: 18px; font-weight: bold; color: #ea580c; margin-top: 4px;">৳ ${totalDue.toLocaleString('bn-BD')}</div>
            <div style="font-size: 10px; color: #9a3412; margin-top: 2px;">শোরুম ও পাইকারি পার্টিদের নিকট মোট বকেয়া</div>
          </div>

          <div style="background-color: #fdf4ff; border: 1px solid #f5d0fe; padding: 12px; border-radius: 8px;">
            <div style="color: #86198f; font-weight: 600;">৫. মোট ক্যাশ কালেকশন জমা (Cash)</div>
            <div style="font-size: 18px; font-weight: bold; color: #a21caf; margin-top: 4px;">৳ ${totalCashCollections.toLocaleString('bn-BD')}</div>
            <div style="font-size: 10px; color: #86198f; margin-top: 2px;">মোট ${collections.length} টি কালেকশন রসিদ</div>
          </div>

          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 8px;">
            <div style="color: #475569; font-weight: 600;">৬. কর্মী প্রদেয় বেতন (Payroll)</div>
            <div style="font-size: 18px; font-weight: bold; color: #0f172a; margin-top: 4px;">৳ ${totalSalaries.toLocaleString('bn-BD')}</div>
            <div style="font-size: 10px; color: #64748b; margin-top: 2px;">শ্রমিক ও কর্মকর্তাদের মোট প্রদেয় বেতন</div>
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; margin-top: 55px; padding-top: 15px; font-size: 11px;">
          <div style="text-align: center; width: 150px; border-top: 1px dashed #94a3b8; padding-top: 5px;">প্রধান হিসাবরক্ষক</div>
          <div style="text-align: center; width: 150px; border-top: 1px dashed #94a3b8; padding-top: 5px;">কারখানা ব্যবস্থাপক (GM)</div>
          <div style="text-align: center; width: 150px; border-top: 1px dashed #94a3b8; padding-top: 5px;">ম্যানেজিং ডিরেক্টর / স্বত্বাধিকারী</div>
        </div>
      </div>
    `;
  };

  // Current HTML calculation
  const currentHtml = useMemo(() => {
    switch (selectedReport) {
      case 'salary':
        return generateSalaryHtml();
      case 'sales':
        return generateSalesHtml();
      case 'due':
        return generateDueHtml();
      case 'cash':
        return generateCashHtml();
      case 'expense':
        return generateExpenseHtml();
      case 'combined':
      default:
        return generateCombinedHtml();
    }
  }, [selectedReport, expenses, filteredExpenses, shops, sales, collections, payrollPeriods, financialStats]);

  const currentTitle = useMemo(() => {
    const dateStr = new Date().toISOString().split('T')[0];
    switch (selectedReport) {
      case 'salary':
        return `বেতন_রিপোর্ট_${dateStr}`;
      case 'sales':
        return `বিক্রয়_রিপোর্ট_${dateStr}`;
      case 'due':
        return `মার্কেট_বাকি_রিপোর্ট_${dateStr}`;
      case 'cash':
        return `ক্যাশ_রিপোর্ট_${dateStr}`;
      case 'expense':
        return `খরচ_লেজার_${dateStr}`;
      case 'combined':
      default:
        return `সমন্বিত_আর্থিক_অডিট_রিপোর্ট_${dateStr}`;
    }
  }, [selectedReport]);

  const handlePrint = () => {
    setIsPrinting(true);
    printHtml(currentHtml, { title: currentTitle, landscape });
    setTimeout(() => {
      setIsPrinting(false);
    }, 1200);
  };

  const handleOpenNewTab = () => {
    openReportInNewTab(currentHtml, currentTitle);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="ব্যবসায়িক রিপোর্ট প্রিন্ট ও অডিট সেন্টার"
      subtitle="টেক্স ওয়্যার অ্যাপারেলস • বেতন, বিক্রি, বাকি, ক্যাশ এবং খরচের পৃথক ও সমন্বিত রিপোর্ট"
      maxWidth="4xl"
    >
      <div className="space-y-4 font-['Hind_Siliguri',sans-serif]">
        {/* Top Report Tab Switcher */}
        <div className="bg-slate-100 p-1.5 rounded-xl flex items-center gap-1 overflow-x-auto">
          {reportTabs.map((tab) => {
            const isActive = selectedReport === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSelectedReport(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Action Controls Bar */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">প্রিন্ট পৃষ্ঠা বিন্যাস:</span>
            <div className="inline-flex bg-white p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setLandscape(false)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold cursor-pointer transition-colors ${
                  !landscape ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                পোর্ট্রেট (Portrait)
              </button>
              <button
                type="button"
                onClick={() => setLandscape(true)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold cursor-pointer transition-colors ${
                  landscape ? 'bg-slate-800 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                ল্যান্ডস্কেপ (Landscape)
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleOpenNewTab}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 font-semibold border border-slate-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
              title="নতুন ব্রাউজার উইন্ডোতে ওপেন করে সংরক্ষণ করুন"
            >
              <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
              <span>নতুন ট্যাবে খুলুন (PDF)</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              disabled={isPrinting}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg flex items-center gap-1.5 cursor-pointer transition-all shadow-xs disabled:opacity-50"
            >
              <Printer className="w-4 h-4" />
              <span>{isPrinting ? 'প্রিন্ট পাঠানো হচ্ছে...' : 'এখনই প্রিন্ট করুন (Print)'}</span>
            </button>
          </div>
        </div>

        {/* Live A4 Print Paper Preview */}
        <div className="border border-slate-300 rounded-xl bg-slate-100/80 p-3 sm:p-5 max-h-[60vh] overflow-y-auto shadow-inner">
          <div className="text-center text-[11px] text-slate-500 font-semibold mb-2 flex items-center justify-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>অফিশিয়াল প্রিন্ট প্রিভিউ (A4 কাগজের মাপ অনুযায়ী অপ্টিমাইজড)</span>
          </div>

          <div className="bg-white shadow-md rounded-lg p-5 sm:p-8 max-w-4xl mx-auto border border-slate-200">
            <div
              dangerouslySetInnerHTML={{ __html: currentHtml }}
              className="garments-print-preview"
            />
          </div>
        </div>

        {/* Footer info & close button */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
          <div className="text-slate-500 hidden sm:block">
            রেজিস্ট্রেশন: <strong className="text-slate-700">BD-GAR-TEX-49021</strong> • টেক্স ওয়্যার অ্যাপারেলস
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer transition-colors"
            >
              বন্ধ করুন
            </button>
            <button
              type="button"
              onClick={handlePrint}
              disabled={isPrinting}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-2 cursor-pointer shadow-xs transition-colors disabled:opacity-50"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট করুন</span>
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
