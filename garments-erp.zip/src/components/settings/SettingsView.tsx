import React, { useState, useEffect } from 'react';
import {
  Settings as SettingsIcon,
  Save,
  Building2,
  Clock,
  Key,
  Database,
  Send,
  CheckCircle2,
  FileSpreadsheet,
  MessageSquare,
  Shield,
  UserPlus,
  RefreshCw,
  AlertCircle,
  Printer
} from 'lucide-react';
import { api } from '../../services/api';
import { useToast } from '../common/Toast';
import { Modal } from '../common/Modal';
import { printHtml } from '../../utils/printDocument';

interface SettingsViewProps {
  initialTab?: 'company' | 'integrations' | 'users';
}

export const SettingsView: React.FC<SettingsViewProps> = ({ initialTab = 'company' }) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'company' | 'integrations' | 'users'>(initialTab);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Settings State
  const [settings, setSettings] = useState({
    company_name_bn: 'টেক্স ওয়্যার অ্যাপারেলস লিমিটেড',
    company_name_en: 'Texware Apparels Ltd.',
    factory_address: 'প্লট #১২, কোনাবাড়ী শিল্পাঞ্চল, গাজীপুর, বাংলাদেশ',
    phone: '+880 1711-000000',
    email: 'info@texwareapparels.com',
    currency_symbol: '৳',
    work_start_time: '08:00',
    work_end_time: '17:00',
    late_threshold_minutes: 15,
    late_days_per_penalty_day: 3,
    absent_penalty_days_ratio: 3,
    ot_formula: 'standard_double', // 2x basic hourly
    google_sheet_id: '1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms',
    sms_provider: 'Greenweb SMS BD',
    sms_api_key: 'gw_live_sample_token_880',
    sms_sender_id: 'MEGHNA-GAR',
    enable_salary_sms: true,
    enable_leave_sms: true,
  });

  // Users state
  const [users, setUsers] = useState<any[]>([]);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [userForm, setUserForm] = useState({
    username: '',
    full_name: '',
    role: 'manager',
    password: '',
  });

  // Test SMS state
  const [testMobile, setTestMobile] = useState('01700000000');
  const [sendingSms, setSendingSms] = useState(false);
  const [syncingSheets, setSyncingSheets] = useState(false);

  const fetchSettingsAndUsers = async () => {
    setLoading(true);
    try {
      const [sets, usrs] = await Promise.all([api.getSettings(), api.getUsers()]);
      if (sets && Object.keys(sets).length > 0) {
        setSettings((prev) => ({ ...prev, ...sets }));
      }
      setUsers(usrs);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettingsAndUsers();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.updateSettings(settings);
      showToast('কারখানা সেটিংস সফলভাবে সংরক্ষিত হয়েছে', 'success');
    } catch (err: any) {
      showToast(err.message || 'সংরক্ষণ ব্যর্থ হয়েছে', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createUser(userForm);
      showToast('নতুন সিস্টেম ব্যবহারকারী তৈরি হয়েছে', 'success');
      setIsUserModalOpen(false);
      fetchSettingsAndUsers();
    } catch (err: any) {
      showToast(err.message || 'ইউজার তৈরিতে সমস্যা হয়েছে', 'error');
    }
  };

  const handleSyncGoogleSheets = async () => {
    setSyncingSheets(true);
    try {
      const res = await api.syncGoogleSheets(settings.google_sheet_id);
      showToast(res.message || 'গুগল শিট ক্লাউড ব্যাকআপ সফলভাবে সিঙ্ক সম্পন্ন হয়েছে!', 'success');
    } catch (err: any) {
      showToast(err.message || 'শিট সিঙ্ক ব্যর্থ হয়েছে', 'error');
    } finally {
      setSyncingSheets(false);
    }
  };

  const handleSendTestSms = async () => {
    setSendingSms(true);
    try {
      const res = await api.sendTestSms({
        mobile: testMobile,
        message: 'টেক্স ওয়্যার অ্যাপারেলস: আপনার বেতন একাউন্টে জমা হয়েছে। ধন্যবাদ।',
      });
      showToast(res.message || 'টেস্ট এসএমএস গেটওয়েতে সফলভাবে প্রেরণ করা হয়েছে!', 'success');
    } catch (err: any) {
      showToast(err.message || 'এসএমএস প্রেরণ ব্যর্থ হয়েছে', 'error');
    } finally {
      setSendingSms(false);
    }
  };

  const handlePrintPolicy = () => {
    const htmlContent = `
      <div class="print-header">
        <h1 class="company-title">${settings.company_name_bn}</h1>
        <div class="company-sub">${settings.company_name_en} • ${settings.factory_address}</div>
        <div class="company-sub">ফোন: ${settings.phone} • ইমেইল: ${settings.email}</div>
        <div class="doc-title">কারখানা শিফট সময়সূচী, ওভারটাইম ও শৃঙ্খলা নীতিমালা</div>
      </div>

      <div class="summary-strip">
        <span><strong>প্রজ্ঞাপন নং:</strong> TW/HR-RULES/2026</span>
        <span><strong>কার্যকর তারিখ:</strong> ০১ জানুয়ারি ২০২৬ হতে চলমান</span>
        <span><strong>অধিক্ষেত্র:</strong> সকল কর্মকর্তা, কর্মচারী ও পোশাক শ্রমিক</span>
      </div>

      <div style="margin-top: 15px; font-size: 11px; line-height: 1.6; color: #1e293b;">
        <h3 style="font-size: 13px; font-weight: bold; color: #064e3b; margin-bottom: 6px; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px;">
          ১. কারখানা সাধারণ কর্মঘণ্টা ও শিফট নীতিমালা:
        </h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px;">
          <tr style="background: #f8fafc;">
            <th style="padding: 6px 10px; border: 1px solid #cbd5e1; width: 40%;">বিষয়বস্তু</th>
            <th style="padding: 6px 10px; border: 1px solid #cbd5e1;">কারখানা নির্ধারিত মান</th>
            <th style="padding: 6px 10px; border: 1px solid #cbd5e1;">নিয়মাবলী</th>
          </tr>
          <tr>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold;">শিফট শুরুর সময়</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold; color: #047857;">${settings.work_start_time} AM</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1;">সকাল ৮:০০ ঘটিকার মধ্যে ডিজিটাল পাঞ্চ / কার্ড পাঞ্চ সম্পন্ন করতে হবে।</td>
          </tr>
          <tr>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold;">দেরিতে প্রবেশের ছাড় (Grace Period)</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold; color: #b45309;">${settings.late_threshold_minutes} মিনিট</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1;">সকাল ৮:১৫ এর পর প্রবেশ করলে সিস্টেমে 'বিলম্বিত (Late)' হিসেবে নথিভুক্ত হবে।</td>
          </tr>
          <tr>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold;">নিয়মিত শিফট সমাপ্তি</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold; color: #047857;">${settings.work_end_time} PM (বিকেল ৫:০০)</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1;">দৈনিক ৮ কর্মঘণ্টা + ১ ঘণ্টা মধ্যাহ্নভোজ ও বিশ্রামের বিরতি অন্তর্ভুক্ত।</td>
          </tr>
          <tr>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold;">ওভারটাইম (OT) ক্যালকুলেশন</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; color: #0369a1;">বাংলাদেশ শ্রম আইন ২০০৬ অনুযায়ী দ্বিগুণ (2x)</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1;">বিকেল ৫:০০ এর পর প্রতিটি অতিরিক্ত কর্মঘণ্টা দ্বিগুণ হারে মূল বেসিক বেতনের অনুপাতে প্রদেয়।</td>
          </tr>
        </table>

        <h3 style="font-size: 13px; font-weight: bold; color: #064e3b; margin-top: 15px; margin-bottom: 6px; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px;">
          ২. কারখানা গেট পাস ও জরুরি প্রস্থান বিধি:
        </h3>
        <p style="margin: 4px 0;">
          কারখানা চলাকালীন কর্মঘণ্টায় জরুরি ব্যক্তিগত বা দাপ্তরিক প্রয়োজনে কারখানা প্রাঙ্গণ ত্যাগের পূর্বে অনুমোদিত ডিজিটাল গেট পাস সংগ্রহ করতে হবে। মূল গেটের সিকিউরিটিতে পাস প্রদর্শন ব্যতীত প্রস্থান অনুমোদিত নয়।
        </p>

        <h3 style="font-size: 13px; font-weight: bold; color: #064e3b; margin-top: 15px; margin-bottom: 6px; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px;">
          ৩. বেতন প্রদান ও হাজিরা বোনাস:
        </h3>
        <p style="margin: 4px 0;">
          প্রতি মাসের ৭ কর্মদিবসের মধ্যে পূর্ববর্তী মাসের বেতন, ওভারটাইম ভাতা ও অনুমোদিত ইনসেন্টিভ সরাসরি নগদ বা মোবাইল ব্যাংকিং মাধ্যমে পরিশোধ করা হবে। পুরো মাসে কোনো বিলম্ব ব্যতীত শতভাগ উপস্থিতির জন্য নিয়মিত হাজিরা বোনাস প্রযোজ্য।
        </p>
      </div>

      <div class="signature-grid cols-4" style="margin-top: 50px;">
        <div>
          <div class="signature-line">এইচআর ও অ্যাডমিন শাখা</div>
        </div>
        <div>
          <div class="signature-line">কমপ্লায়েন্স ও ওয়েলফেয়ার অফিসার</div>
        </div>
        <div>
          <div class="signature-line">উৎপাদন ও ফ্লোর ইনচার্জ</div>
        </div>
        <div>
          <div class="signature-line">ব্যবস্থাপনা পরিচালক / জিএম</div>
        </div>
      </div>
    `;

    printHtml(htmlContent, {
      title: `${settings.company_name_bn}_কারখানা_পলিসি_নিয়মাবলী`,
      landscape: false
    });
  };

  return (
    <div className="space-y-5 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-slate-100 text-slate-800">
              <SettingsIcon className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              সিস্টেম ও কারখানা সেটিংস (Settings & Integrations)
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            ফ্যাক্টরি প্রোফাইল, শিফট ও ওভারটাইম নিয়মাবলী, গুগল শিট ব্যাকআপ ও এসএমএস ইন্টিগ্রেশন
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handlePrintPolicy}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer border border-slate-200 transition-colors shadow-2xs"
            title="কারখানা পলিসি ও শিফট রুলস শীট প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4 text-emerald-700" />
            <span>পলিসি শীট প্রিন্ট</span>
          </button>

          <button
            onClick={handleSaveSettings}
            disabled={saving}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs shadow-emerald-600/20 disabled:opacity-60 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'সেটিংস সংরক্ষণ করুন'}</span>
          </button>
        </div>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex border-b border-slate-200 text-xs font-semibold gap-2">
        <button
          onClick={() => setActiveTab('company')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors ${
            activeTab === 'company'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          কারখানা প্রোফাইল ও শিফট রুলস
        </button>
        <button
          onClick={() => setActiveTab('integrations')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors ${
            activeTab === 'integrations'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          গুগল শিট ও এসএমএস গেটওয়ে
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`pb-3 px-4 border-b-2 cursor-pointer transition-colors ${
            activeTab === 'users'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          সিস্টেম ইউজার ও পারমিশন ({users.length})
        </button>
      </div>

      {/* Tab 1: Company Profile & Shift Rules */}
      {activeTab === 'company' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-6 text-xs">
          <div>
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-3">
              <Building2 className="w-4 h-4 text-emerald-700" />
              <span>কারখানা প্রাথমিক তথ্য ও লেটারহেড</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">কারখানার নাম (বাংলায়)</label>
                <input
                  type="text"
                  value={settings.company_name_bn}
                  onChange={(e) => setSettings({ ...settings, company_name_bn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Company Name (English)</label>
                <input
                  type="text"
                  value={settings.company_name_en}
                  onChange={(e) => setSettings({ ...settings, company_name_en: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">কারখানা ও অফিসের ঠিকানা</label>
                <input
                  type="text"
                  value={settings.factory_address}
                  onChange={(e) => setSettings({ ...settings, factory_address: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">যোগাযোগ ফোন / মোবাইল</label>
                <input
                  type="text"
                  value={settings.phone}
                  onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">অফিসিয়াল ইমেইল</label>
                <input
                  type="email"
                  value={settings.email}
                  onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-6">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-3">
              <Clock className="w-4 h-4 text-emerald-700" />
              <span>কারখানা শিফট ও ওভারটাইম নীতি (Bangladesh Labor Law)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">শিফট শুরুর সময় (সকাল)</label>
                <input
                  type="time"
                  value={settings.work_start_time}
                  onChange={(e) => setSettings({ ...settings, work_start_time: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">শিফট সমাপ্তির সময় (বিকাল)</label>
                <input
                  type="time"
                  value={settings.work_end_time}
                  onChange={(e) => setSettings({ ...settings, work_end_time: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">দেরি ছাড় সীমা (মিনিট)</label>
                <input
                  type="number"
                  value={settings.late_threshold_minutes}
                  onChange={(e) => setSettings({ ...settings, late_threshold_minutes: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  সকাল ৮:১৫ এর পর পাঞ্চ করলে 'দেরি' গণ্য হবে
                </span>
              </div>

              <div className="sm:col-span-3">
                <label className="block font-semibold text-slate-700 mb-1">ওভারটাইম (OT) হিসাবের সূত্র</label>
                <select
                  value={settings.ot_formula}
                  onChange={(e) => setSettings({ ...settings, ot_formula: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                >
                  <option value="standard_double">
                    দ্বিগুণ হার (Standard 2x): (মূল বেসিক বেতন ÷ ২০৮ ঘণ্টা) × ২ × মোট ওটি ঘণ্টা
                  </option>
                  <option value="standard_single">
                    সাধারণ হার (1x Basic Rate): (মূল বেসিক বেতন ÷ ২০৮ ঘণ্টা) × ১ × মোট ওটি ঘণ্টা
                  </option>
                  <option value="fixed_hourly">নির্দিষ্ট ঘণ্টা চুক্তি (Fixed Tk. 80 / Hour)</option>
                </select>
              </div>

              {/* Attendance Penalty Rules (৩ দিন লেটে ১ দিন, ৩ দিন না বলে অনুপস্থিতিতে ১ দিন জরিমানা) */}
              <div className="sm:col-span-3 border-t border-slate-100 pt-5 mt-2">
                <div className="bg-slate-50/90 rounded-xl p-4 border border-slate-200/90 space-y-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                    <h4 className="font-bold text-slate-800 text-sm">
                      কারখানা হাজিরা কর্তন ও জরিমানা নীতি (Attendance Penalty Rules)
                    </h4>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        লেট হাজিরা কর্তন অনুপাত (দিন)
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min={1}
                          max={10}
                          value={settings.late_days_per_penalty_day}
                          onChange={(e) => setSettings({ ...settings, late_days_per_penalty_day: Number(e.target.value) })}
                          className="w-24 px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono font-bold text-center"
                        />
                        <span className="text-slate-600 font-medium">দিন লেট করলে ১ দিনের হাজিরা কাটা হবে</span>
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        উদাহরণ: মাসে ৩ দিন লেট করলে ১ দিন, ৬ দিন লেট করলে ২ দিনের বেতন কাটা যাবে।
                      </span>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        অনুপস্থিতি জরিমানা অনুপাত (দিন)
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min={1}
                          max={10}
                          value={settings.absent_penalty_days_ratio}
                          onChange={(e) => setSettings({ ...settings, absent_penalty_days_ratio: Number(e.target.value) })}
                          className="w-24 px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono font-bold text-center"
                        />
                        <span className="text-slate-600 font-medium">দিন না বলে অনুপস্থিত থাকলে অতিরিক্ত ১ দিন জরিমানা</span>
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        উদাহরণ: ২৬ দিনে ৩ দিন অনুপস্থিত থাকলে ৩ দিন + অতিরিক্ত ১ দিন = মোট ৪ দিনের হাজিরা কাটা হবে।
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200/60 text-xs text-emerald-950 font-medium">
                    📌 <strong>সক্রিয় স্বয়ংক্রিয় নিয়ম:</strong> কোনো শ্রমিক যদি ২৬ দিনের মধ্যে ৩ দিন অনুপস্থিত থাকে, তবে তার মূল ৩ দিনের অনুপস্থিতির সাথে জরিমানা বাবদ আরও ১ দিন যোগ হয়ে মোট ৪ দিনের হাজিরা কাটা হবে। পাশাপাশি ৩ দিন লেট করলে ১ দিনের হাজিরা কাটা হবে।
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Integrations (Google Sheets & SMS) */}
      {activeTab === 'integrations' && (
        <div className="space-y-5 text-xs">
          {/* Google Sheets Integration Card */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">গুগল শিট রিয়েলটাইম ক্লাউড ব্যাকআপ</h3>
                  <p className="text-xs text-slate-500">
                    দৈনিক হাজিরা, স্টক ও বিক্রয় ডাটা স্বয়ংক্রিয়ভাবে আপনার গুগল স্প্রেডশিটে সিঙ্ক করুন
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSyncGoogleSheets}
                disabled={syncingSheets}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-60 transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncingSheets ? 'animate-spin' : ''}`} />
                <span>{syncingSheets ? 'সিঙ্ক হচ্ছে...' : 'এখনই শিটে সিঙ্ক করুন'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Google Sheet Spreadsheet ID</label>
                <input
                  type="text"
                  value={settings.google_sheet_id}
                  onChange={(e) => setSettings({ ...settings, google_sheet_id: e.target.value })}
                  placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">স্বয়ংক্রিয় সিঙ্কের ফ্রিকোয়েন্সি</label>
                <select className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium">
                  <option>প্রতিটি বিক্রির পরপরই (Realtime Instant)</option>
                  <option>প্রতিদিন রাত ১২টায় (Daily Midnight)</option>
                  <option>ম্যানুয়াল ক্লিক শুধুমাত্র</option>
                </select>
              </div>
            </div>
          </div>

          {/* SMS Gateway Integration Card */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">বাংলাদেশ বাল্ক এসএমএস গেটওয়ে</h3>
                  <p className="text-xs text-slate-500">
                    বেতন পরিশোধ, বকেয়া রিমাইন্ডার এবং ডেলিভারি কনফার্মেশন এসএমএস নোটিফিকেশন
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">এসএমএস গেটওয়ে প্রোভাইডার</label>
                <select
                  value={settings.sms_provider}
                  onChange={(e) => setSettings({ ...settings, sms_provider: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                >
                  <option value="Greenweb SMS BD">Greenweb SMS BD (বাংলাদেশ)</option>
                  <option value="BulkSMS BD">BulkSMS BD</option>
                  <option value="Alpha Net SMS">Alpha Net SMS API</option>
                  <option value="Onnorokom SMS">অন্যরকম এসএমএস (Onnorokom)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">API Key / Token</label>
                <input
                  type="password"
                  value={settings.sms_api_key}
                  onChange={(e) => setSettings({ ...settings, sms_api_key: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Masking Sender ID (সেন্ডার নাম)</label>
                <input
                  type="text"
                  value={settings.sms_sender_id}
                  onChange={(e) => setSettings({ ...settings, sms_sender_id: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                />
              </div>
            </div>

            {/* Test SMS Action */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="w-full sm:w-72">
                <label className="block text-[10px] text-slate-500 mb-1 font-semibold">টেস্ট মোবাইল নম্বর</label>
                <input
                  type="text"
                  value={testMobile}
                  onChange={(e) => setTestMobile(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <button
                type="button"
                onClick={handleSendTestSms}
                disabled={sendingSms}
                className="w-full sm:w-auto px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-semibold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-60"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{sendingSms ? 'পাঠানো হচ্ছে...' : 'টেস্ট এসএমএস পাঠান'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: System Users & Roles */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-800">অনুমোদিত সিস্টেম ব্যবহারকারী</h3>
              <p className="text-xs text-slate-500">এডমিন, ম্যানেজার ও একাউন্টেন্টদের রোলভিত্তিক এক্সেস</p>
            </div>

            <button
              onClick={() => {
                setUserForm({
                  username: '',
                  full_name: '',
                  role: 'manager',
                  password: '',
                });
                setIsUserModalOpen(true);
              }}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer shadow-xs"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>নতুন ইউজার যোগ করুন</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">ইউজারনেম</th>
                  <th className="py-3 px-4">পূর্ণ নাম</th>
                  <th className="py-3 px-4">রোল / দায়িত্ব</th>
                  <th className="py-3 px-4">স্ট্যাটাস</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{u.username}</td>
                    <td className="py-3 px-4 font-semibold text-slate-700">{u.full_name}</td>
                    <td className="py-3 px-4">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-800">
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        সক্রিয়
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      <Modal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
        title="নতুন সিস্টেম ইউজার তৈরি করুন"
        subtitle="সিস্টেমে লগইন করার জন্য নতুন ক্রেডেনশিয়াল ও ভূমিকা নির্ধারণ করুন"
        maxWidth="md"
      >
        <form onSubmit={handleCreateUser} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">লগইন ইউজারনেম (Username)</label>
            <input
              type="text"
              value={userForm.username}
              onChange={(e) => setUserForm({ ...userForm, username: e.target.value.toLowerCase().trim() })}
              required
              placeholder="যেমন: manager_kamal"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">পূর্ণ নাম</label>
            <input
              type="text"
              value={userForm.full_name}
              onChange={(e) => setUserForm({ ...userForm, full_name: e.target.value })}
              required
              placeholder="যেমন: মোঃ কামাল হোসেন"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">ভূমিকা (Role)</label>
            <select
              value={userForm.role}
              onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
            >
              <option value="admin">সিস্টেম অ্যাডমিন (Full Access)</option>
              <option value="manager">ফ্যাক্টরি ম্যানেজার (Workforce & HR Control)</option>
              <option value="accountant">পে-রোল ও হিসাবরক্ষক (Payroll & Staff Accounts)</option>
              <option value="supervisor">ফ্লোর সুপারভাইজার (Attendance & Gate Pass)</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">লগইন পাসওয়ার্ড</label>
            <input
              type="password"
              value={userForm.password}
              onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
              required
              placeholder="কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsUserModalOpen(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl cursor-pointer shadow-xs"
            >
              ইউজার তৈরি করুন
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
