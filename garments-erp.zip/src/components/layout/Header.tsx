import React, { useState } from 'react';
import {
  Menu,
  KeyRound,
  LogOut,
  ChevronDown,
  Building2,
  Clock,
  Sparkles,
  UserPlus,
  CalendarCheck,
  Banknote,
  MessageSquare,
  ShieldCheck,
  PlusCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { NavTab } from './Sidebar';

export type QuickActionType =
  | 'add_employee'
  | 'mark_attendance'
  | 'payroll'
  | 'issue_gatepass'
  | 'send_sms';

export interface HeaderProps {
  currentTab?: NavTab | string;
  currentView?: NavTab | string;
  onOpenSidebar?: () => void;
  onToggleSidebar?: () => void;
  onToggleMobileMenu?: () => void;
  onOpenChangePassword?: () => void;
  onChangePassword?: () => void;
  onQuickAction?: (action: QuickActionType) => void;
  onNavigate?: (tab: any) => void;
  isSidebarOpen?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  currentView,
  onOpenSidebar,
  onToggleSidebar,
  onToggleMobileMenu,
  onOpenChangePassword,
  onChangePassword,
  onQuickAction,
  onNavigate
}) => {
  const { user, logout } = useAuth();
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [quickMenuOpen, setQuickMenuOpen] = useState(false);

  const activeTab = (currentTab || currentView || 'dashboard') as NavTab;

  const titles: Record<string, { bn: string; en: string }> = {
    dashboard: { bn: 'ড্যাশবোর্ড ও নিয়ন্ত্রণ কেন্দ্র', en: 'Dashboard & Workforce Control' },
    employees: { bn: 'শ্রমিক ও কর্মচারী ব্যবস্থাপনা', en: 'Employees & Workforce Directory' },
    attendance: { bn: 'দৈনিক হাজিরা, ছুটি ও গেট পাস', en: 'Daily Attendance, Leave & Gate Pass' },
    payroll: { bn: 'মাসিক বেতন ও ওভারটাইম শিট', en: 'Monthly Payroll, Bonus & Overtime' },
    idcards: { bn: 'কর্মী পরিচয়পত্র (ID Card Studio)', en: 'Employee ID Card Studio & Printing' },
    sms: { bn: 'বাংলা এসএমএস নোটিফিকেশন', en: 'Bangla SMS Broadcasting System' },
    backup: { bn: 'গুগল শিট ক্লাউড ব্যাকআপ ও সিঙ্ক', en: 'Google Sheets Cloud Backup' },
    settings: { bn: 'অ্যাডমিন সেটিংস ও কারখানা নীতিমালা', en: 'Admin Settings & Factory Rules' },
  };

  const currentTitle = titles[activeTab] || { bn: 'গার্মেন্টস ইআরপি', en: 'Garments ERP' };

  const handleToggleMenu = () => {
    if (onToggleSidebar) {
      onToggleSidebar();
    } else if (onOpenSidebar) {
      onOpenSidebar();
    } else if (onToggleMobileMenu) {
      onToggleMobileMenu();
    }
  };

  const handleQuick = (action: QuickActionType) => {
    setQuickMenuOpen(false);
    if (onQuickAction) {
      onQuickAction(action);
    } else if (onNavigate) {
      if (action === 'add_employee') onNavigate('employees');
      else if (action === 'mark_attendance') onNavigate('attendance');
      else if (action === 'payroll') onNavigate('payroll');
      else if (action === 'issue_gatepass') onNavigate('attendance');
      else if (action === 'send_sms') onNavigate('sms');
    }
  };

  const handleChangePassword = () => {
    setUserDropdownOpen(false);
    if (onOpenChangePassword) onOpenChangePassword();
    else if (onChangePassword) onChangePassword();
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 py-3 transition-all print:hidden">
      <div className="flex items-center justify-between gap-4">
        {/* Left side: Hamburger 3-lines menu + Page Title */}
        <div className="flex items-center gap-3">
          <button
            id="mobile-menu-toggle"
            onClick={handleToggleMenu}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 active:bg-slate-200 rounded-xl transition-colors cursor-pointer flex items-center justify-center shrink-0 border border-slate-200/60 shadow-2xs"
            aria-label="Toggle navigation menu (৩লাইন)"
            title="মেনু খুলুন / বন্ধ করুন (৩লাইন)"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <h1 className="text-base sm:text-lg font-bold text-slate-800 tracking-tight flex items-center gap-2">
              <span>{currentTitle.bn}</span>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-xs border border-emerald-200/60 font-normal">
                {currentTitle.en}
              </span>
            </h1>
          </div>
        </div>

        {/* Right side: Quick Action + Profile Dropdown */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Action Dropdown */}
          <div className="relative">
            <button
              id="quick-actions-btn"
              onClick={() => {
                setQuickMenuOpen(!quickMenuOpen);
                setUserDropdownOpen(false);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs shadow-emerald-600/20 transition-colors cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">দ্রুত কাজ</span>
              <ChevronDown className="w-3 h-3" />
            </button>

            {quickMenuOpen && (
              <div
                className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-1.5 z-50 text-xs animate-in fade-in zoom-in-95 duration-100"
                onClick={() => setQuickMenuOpen(false)}
              >
                <button
                  onClick={() => handleQuick('add_employee')}
                  className="w-full px-3.5 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4 text-emerald-600" />
                  <span>নতুন কর্মী নিবন্ধন</span>
                </button>
                <button
                  onClick={() => handleQuick('mark_attendance')}
                  className="w-full px-3.5 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                >
                  <CalendarCheck className="w-4 h-4 text-blue-600" />
                  <span>আজকের হাজিরা গ্রহণ</span>
                </button>
                <button
                  onClick={() => handleQuick('payroll')}
                  className="w-full px-3.5 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                >
                  <Banknote className="w-4 h-4 text-emerald-600" />
                  <span>বেতন ও ওভারটাইম শিট</span>
                </button>
                <button
                  onClick={() => handleQuick('issue_gatepass')}
                  className="w-full px-3.5 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                >
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>জরুরি গেট পাস ইস্যু</span>
                </button>
                <button
                  onClick={() => handleQuick('send_sms')}
                  className="w-full px-3.5 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4 text-indigo-600" />
                  <span>এসএমএস নোটিশ পাঠান</span>
                </button>
              </div>
            )}
          </div>

          {/* User Profile */}
          <div className="relative">
            <button
              id="user-menu-btn"
              onClick={() => {
                setUserDropdownOpen(!userDropdownOpen);
                setQuickMenuOpen(false);
              }}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 bg-slate-100 hover:bg-slate-200/80 rounded-xl transition-colors cursor-pointer text-slate-700"
            >
              <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white font-bold flex items-center justify-center text-xs">
                {user?.full_name?.charAt(0) || 'A'}
              </div>
              <div className="hidden md:block text-left">
                <div className="text-xs font-semibold text-slate-800 leading-tight">
                  {user?.full_name?.split(' ')[0] || user?.username}
                </div>
                <div className="text-[10px] text-slate-500 uppercase font-mono">{user?.role}</div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {userDropdownOpen && (
              <div
                className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50 text-xs animate-in fade-in zoom-in-95 duration-100"
                onClick={() => setUserDropdownOpen(false)}
              >
                <div className="px-4 py-2 border-b border-slate-100">
                  <p className="font-bold text-slate-800">{user?.full_name}</p>
                  <p className="text-slate-500 text-[11px] font-mono">@{user?.username}</p>
                </div>

                <button
                  onClick={handleChangePassword}
                  className="w-full px-4 py-2.5 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 transition-colors cursor-pointer"
                >
                  <KeyRound className="w-4 h-4 text-slate-500" />
                  <span>পাসওয়ার্ড পরিবর্তন</span>
                </button>

                <div className="border-t border-slate-100 mt-1 pt-1">
                  <button
                    onClick={logout}
                    className="w-full px-4 py-2 text-left text-rose-600 hover:bg-rose-50 flex items-center gap-2.5 transition-colors cursor-pointer font-medium"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>লগআউট করুন</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
