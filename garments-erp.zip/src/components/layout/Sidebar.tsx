import React from 'react';
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  Banknote,
  Contact,
  MessageSquare,
  FileSpreadsheet,
  Settings,
  LogOut,
  Shirt,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export type NavTab =
  | 'dashboard'
  | 'employees'
  | 'attendance'
  | 'payroll'
  | 'idcards'
  | 'sms'
  | 'backup'
  | 'settings';

export interface SidebarProps {
  currentTab?: NavTab | string;
  currentView?: NavTab | string;
  setCurrentTab?: (tab: NavTab) => void;
  onNavigate?: (tab: any) => void;
  isOpen?: boolean;
  mobileOpen?: boolean;
  onClose?: () => void;
  onCloseMobile?: () => void;
  isDesktopOpen?: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  currentView,
  setCurrentTab,
  onNavigate,
  isOpen,
  mobileOpen,
  onClose,
  onCloseMobile,
  isDesktopOpen = true,
}) => {
  const { user, logout, hasPermission } = useAuth();

  const activeTab = (currentTab || currentView || 'dashboard') as NavTab;
  const isMobileOpen = Boolean(isOpen ?? mobileOpen);
  const desktopVisible = isDesktopOpen !== false;

  const handleClose = () => {
    if (onClose) onClose();
    if (onCloseMobile) onCloseMobile();
  };

  const handleSelect = (tab: NavTab) => {
    if (setCurrentTab) setCurrentTab(tab);
    if (onNavigate) onNavigate(tab);
    handleClose();
  };

  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'ড্যাশবোর্ড',
      sublabel: 'Dashboard',
      icon: LayoutDashboard,
      perm: 'view_dashboard',
    },
    {
      id: 'employees' as NavTab,
      label: 'শ্রমিক ও কর্মচারী',
      sublabel: 'Workers & Staff',
      icon: Users,
      perm: 'view_employees',
    },
    {
      id: 'attendance' as NavTab,
      label: 'হাজিরা, ছুটি ও গেট পাস',
      sublabel: 'Attendance & Gate Pass',
      icon: CalendarCheck,
      perm: 'view_attendance',
    },
    {
      id: 'payroll' as NavTab,
      label: 'বেতন ও ওভারটাইম শিট',
      sublabel: 'Payroll & Overtime',
      icon: Banknote,
      perm: 'view_payroll',
    },
    {
      id: 'idcards' as NavTab,
      label: 'কর্মী পরিচয়পত্র (ID Card)',
      sublabel: 'ID Card Studio & Print',
      icon: Contact,
      perm: 'print_documents',
    },
    {
      id: 'sms' as NavTab,
      label: 'বাংলা এসএমএস নোটিফিকেশন',
      sublabel: 'SMS Broadcasting',
      icon: MessageSquare,
      perm: 'send_sms',
    },
    {
      id: 'backup' as NavTab,
      label: 'গুগল শিট ব্যাকআপ',
      sublabel: 'Sheets Cloud Sync',
      icon: FileSpreadsheet,
      perm: 'google_sheets_sync',
    },
    {
      id: 'settings' as NavTab,
      label: 'অ্যাডমিন কন্ট্রোল ও রুলস',
      sublabel: 'Control Center & Rules',
      icon: Settings,
      perm: 'manage_settings',
    },
  ];

  return (
    <>
      {/* Mobile backdrop overlay */}
      {isMobileOpen && (
        <div
          id="sidebar-mobile-backdrop"
          className="fixed inset-0 z-40 bg-slate-900/40 lg:hidden backdrop-blur-xs transition-opacity cursor-pointer print:hidden"
          onClick={handleClose}
        />
      )}

      {/* Sidebar container - Pure Crisp WHITE background as requested */}
      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-72 bg-white text-slate-800 flex flex-col transition-transform duration-300 ease-in-out print:hidden ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        } ${
          desktopVisible ? 'lg:translate-x-0' : 'lg:-translate-x-full'
        } border-r border-slate-200/90 shadow-2xl lg:shadow-xs`}
      >
        {/* Top Logo & Factory Name */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 shrink-0">
              <Shirt className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                <span>গার্মেন্টস ইআরপি</span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-mono font-bold uppercase">
                  PRO
                </span>
              </h2>
              <p className="text-[11px] text-emerald-700 font-semibold truncate max-w-[170px]">
                টেক্স ওয়্যার অ্যাপারেলস
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="lg:hidden p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Card */}
        <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs shrink-0 border border-emerald-200/60">
              {user?.full_name?.charAt(0) || 'A'}
            </div>
            <div className="truncate">
              <p className="text-xs font-bold text-slate-800 truncate">{user?.full_name}</p>
              <span className="text-[10px] text-slate-500 font-mono capitalize">
                @{user?.username} • <span className="text-emerald-700 font-semibold">{user?.role}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1 scrollbar-thin scrollbar-thumb-slate-200">
          <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            প্রধান মডিউলসমূহ (Modules)
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            const allowed = hasPermission(item.perm);

            if (!allowed) return null;

            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all duration-150 cursor-pointer group ${
                  isActive
                    ? 'bg-emerald-600 text-white font-semibold shadow-sm shadow-emerald-600/30'
                    : 'text-slate-700 hover:text-emerald-700 hover:bg-emerald-50/70 font-medium'
                }`}
              >
                <Icon
                  className={`w-4.5 h-4.5 shrink-0 transition-colors ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-emerald-600'
                  }`}
                />
                <div className="flex-1 min-w-0">
                  <div className={`text-xs truncate ${isActive ? 'text-white font-bold' : 'text-slate-800 group-hover:text-emerald-900 font-medium'}`}>
                    {item.label}
                  </div>
                  <div
                    className={`text-[10px] truncate ${
                      isActive ? 'text-emerald-100' : 'text-slate-400 group-hover:text-emerald-600/80'
                    }`}
                  >
                    {item.sublabel}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Logout Footer */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/50">
          <button
            id="sidebar-logout-btn"
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 border border-rose-200/80 transition-all cursor-pointer shadow-2xs"
          >
            <LogOut className="w-4 h-4" />
            <span>লগআউট করুন</span>
          </button>
        </div>
      </aside>
    </>
  );
};
