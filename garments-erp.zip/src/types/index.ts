export interface User {
  id: number;
  username: string;
  full_name: string;
  email: string | null;
  role: 'admin' | 'manager' | 'accountant' | 'supervisor' | 'staff';
  permissions: string[];
  must_change_password: boolean;
  is_active?: boolean;
  created_at?: string;
  last_login_at?: string | null;
}

export interface CompanySettings {
  id: number;
  company_name_bn: string;
  company_name_en: string;
  subtitle: string;
  logo_url: string;
  address: string;
  phone: string;
  email: string;
  currency: string;
  working_days_per_month: number;
  daily_standard_hours: number;
  ot_multiplier: number;
  late_days_per_penalty_day?: number;
  absent_penalty_days_ratio?: number;
  allow_negative_stock: number;
  sms_provider: string;
  sms_api_key?: string;
  sms_sender_id: string;
  google_sheet_id?: string;
  google_sheet_synced_at?: string | null;
}

export interface Employee {
  id: number;
  employee_code: string;
  full_name: string;
  guardian_name?: string;
  dob?: string;
  gender: 'Male' | 'Female' | 'Other';
  mobile: string;
  address?: string;
  nid?: string;
  joining_date: string;
  department: string;
  designation: string;
  employee_type: 'worker' | 'staff' | 'supervisor' | 'manager' | 'other';
  salary_type: 'monthly' | 'daily' | 'piece_rate';
  basic_salary: number;
  overtime_rate: number;
  status: 'active' | 'inactive' | 'resigned';
  resignation_date?: string;
  resignation_reason?: string;
  emergency_contact?: string;
  photo_url?: string;
  notes?: string;
  blood_group?: string;
  created_at?: string;
  updated_at?: string;
}

export interface AttendanceRecord {
  employee_id: number;
  employee_code: string;
  full_name: string;
  department: string;
  designation: string;
  salary_type: string;
  basic_salary: number;
  overtime_rate: number;
  attendance_id?: number | null;
  date: string;
  status: 'present' | 'absent' | 'late' | 'leave' | 'half_day' | 'holiday' | null;
  in_time?: string;
  out_time?: string;
  ot_hours?: number;
  notes?: string;
}

export interface LeaveRecord {
  id: number;
  employee_id: number;
  employee_code?: string;
  full_name?: string;
  department?: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  total_days: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  approved_by?: string;
  created_at?: string;
}

export interface GatePass {
  id: number;
  pass_no: string;
  employee_id: number;
  employee_code?: string;
  full_name?: string;
  department?: string;
  designation?: string;
  mobile?: string;
  date: string;
  out_time: string;
  expected_return_time?: string;
  actual_return_time?: string;
  reason: string;
  status: 'pending' | 'approved' | 'returned' | 'not_returned';
  approved_by?: string;
  created_at?: string;
}

export interface PayrollPeriod {
  id: number;
  month_year: string;
  total_employees: number;
  total_payable: number;
  total_paid: number;
  total_due: number;
  status: 'draft' | 'approved' | 'finalized';
  finalized_by?: string;
  finalized_at?: string;
  notes?: string;
  created_at: string;
}

export interface PayrollItem {
  id: number;
  payroll_period_id: number;
  employee_id: number;
  employee_name: string;
  employee_code: string;
  department: string;
  designation: string;
  salary_type: string;
  basic_salary: number;
  present_days: number;
  late_days?: number;
  absent_days: number;
  leave_days: number;
  late_penalty_days?: number;
  absent_penalty_days?: number;
  total_penalty_days?: number;
  attendance_deduction?: number;
  payable_days?: number;
  ot_hours: number;
  ot_amount: number;
  bonus_amount: number;
  allowances: number;
  advance_deduction: number;
  other_deduction: number;
  net_payable: number;
  paid_amount: number;
  due_amount: number;
  payment_status: 'unpaid' | 'partial' | 'paid';
  payment_date?: string;
  payment_method?: string;
  payment_ref?: string;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface ProductVariant {
  id: number;
  product_id: number;
  size: string;
  color: string;
  sku: string;
  stock_quantity: number;
  opening_stock: number;
  alert_threshold: number;
  created_at?: string;
}

export interface Product {
  id: number;
  product_code: string;
  name_bn: string;
  name_en: string;
  category: string;
  unit: string;
  cost_price: number;
  selling_price: number;
  description?: string;
  is_active: number;
  created_at?: string;
  variants?: ProductVariant[];
  totalStock?: number;
}

export interface ProductionRecord {
  id: number;
  batch_no: string;
  date: string;
  product_id: number;
  variant_id: number;
  product_name?: string;
  size?: string;
  color?: string;
  sku?: string;
  quantity: number;
  defect_quantity: number;
  supervisor_name?: string;
  notes?: string;
  created_at?: string;
}

export interface Shop {
  id: number;
  shop_code: string;
  name: string;
  owner_name?: string;
  phone: string;
  address?: string;
  credit_limit: number;
  opening_due: number;
  current_due: number;
  total_purchased: number;
  total_paid: number;
  notes?: string;
  created_at?: string;
}

export interface SaleItem {
  id?: number;
  sale_id?: number;
  product_id: number;
  variant_id: number;
  product_name: string;
  size: string;
  color: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

export interface Sale {
  id: number;
  invoice_no: string;
  sale_date: string;
  shop_id?: number | null;
  shop_name: string;
  customer_name?: string;
  customer_phone?: string;
  gross_amount: number;
  discount_amount: number;
  net_amount: number;
  paid_amount: number;
  due_amount: number;
  payment_method: string;
  payment_status: 'paid' | 'partial' | 'due';
  notes?: string;
  created_by?: string;
  created_at: string;
  total_items?: number;
  total_pieces?: number;
}

export interface Expense {
  id: number;
  expense_no: string;
  expense_date: string;
  voucher_no?: string;
  date?: string;
  category: string;
  description: string;
  amount: number;
  payment_method: string;
  paid_to?: string;
  receipt_url?: string;
  approved_by?: string;
  notes?: string;
  created_at: string;
}

export interface Collection {
  id: number;
  collection_no: string;
  collection_date: string;
  shop_id: number;
  shop_name: string;
  invoice_no?: string;
  amount: number;
  payment_method: string;
  collected_by?: string;
  remaining_due: number;
  notes?: string;
  created_at: string;
}

export interface SmsLog {
  id: number;
  recipient_phone: string;
  recipient_name?: string;
  message: string;
  template_type: string;
  status: string;
  response_id?: string;
  sent_at: string;
  cost: number;
}

export interface AuditLog {
  id: number;
  user_id?: number;
  username?: string;
  action: string;
  module: string;
  details: string;
  ip_address: string;
  timestamp: string;
}

export interface DashboardStats {
  totalEmployees: number;
  activeEmployees: number;
  attendance: {
    present: number;
    absent: number;
    leave: number;
    late: number;
    otHours: number;
  };
  deptAttendance?: {
    department: string;
    total: number;
    present: number;
    absent: number;
    ot_hours: number;
  }[];
  monthlyPayroll: {
    totalPayable: number;
    totalPaid: number;
    totalDue: number;
    otAmount: number;
  };
  production: {
    totalPiecesProduced: number;
    totalDefects: number;
    currentStockPieces: number;
    lowStockItems: number;
  };
  sales: {
    totalRevenue: number;
    totalPaid?: number;
    totalPiecesSold: number;
    totalOutstandingDue: number;
  };
  accounts: {
    totalExpenses: number;
    totalCollections: number;
    estimatedProfitOrLoss: number;
    cashInHand?: number;
    totalMarketDue?: number;
    totalShops?: number;
  };
  todayFinancials?: {
    date: string;
    todaySales: number;
    todayCashSales: number;
    todayDueSales: number;
    todayCollections: number;
    todayCashIn: number;
    todayExpenses: number;
    todayNetCash: number;
  };
  topDueShops?: {
    name: string;
    phone: string;
    current_due: number;
    credit_limit: number;
  }[];
  expenseCategories?: {
    category: string;
    total: number;
  }[];
  companySettings?: any;
  gatePassesToday?: {
    total: number;
    pending: number;
    approved: number;
    returned: number;
    currentlyOut: number;
  };
  pendingLeavesCount?: number;
  recentEmployees?: {
    id: number;
    employee_code: string;
    full_name: string;
    department: string;
    designation: string;
    joining_date: string;
    status: string;
  }[];
  recentSales?: any[];
  recentPayments: any[];
  alerts: string[];
}
