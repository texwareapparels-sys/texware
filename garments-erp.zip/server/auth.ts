import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { queryOne, executeRun, queryAll } from './db.ts';

// In-memory active sessions mapping token -> user
interface SessionUser {
  id: number;
  username: string;
  full_name: string;
  email: string | null;
  role: string;
  permissions: string[];
  must_change_password: boolean;
}

const activeSessions = new Map<string, { user: SessionUser; expiresAt: number }>();

export function generateToken(user: SessionUser): string {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
  activeSessions.set(token, { user, expiresAt });
  return token;
}

export function verifySessionToken(token: string): SessionUser | null {
  const session = activeSessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return null;
  }
  return session.user;
}

export function revokeSessionToken(token: string): void {
  activeSessions.delete(token);
}

export interface AuthRequest extends Request {
  user?: SessionUser;
}

export function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'লগইন করুন বা অথরাইজেশন টোকেন প্রদান করুন' });
  }

  const token = authHeader.split(' ')[1];
  const user = verifySessionToken(token);
  if (!user) {
    return res.status(401).json({ error: 'সেশনের মেয়াদ শেষ হয়েছে। পুনরায় লগইন করুন।' });
  }

  req.user = user;
  next();
}

export function requirePermission(permission: string) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'অননুমোদিত অ্যাক্সেস' });
    }
    if (req.user.role === 'admin' || req.user.permissions.includes(permission)) {
      return next();
    }
    return res.status(403).json({ error: 'এই অপশনটি ব্যবহারের আপনার অনুমতি নেই' });
  };
}

export function logAudit(userId: number | null, username: string, action: string, module: string, details: string, ip: string = '127.0.0.1') {
  try {
    executeRun(`
      INSERT INTO audit_logs (user_id, username, action, module, details, ip_address, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
    `, [userId, username, action, module, details, ip]);
  } catch (e) {
    console.error('Failed to write audit log:', e);
  }
}
