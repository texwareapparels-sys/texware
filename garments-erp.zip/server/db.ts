import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

let dbInstance: Database | null = null;
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'garments_erp.sqlite');

export async function getDb(): Promise<Database> {
  if (dbInstance) return dbInstance;

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE)) {
    const fileBuffer = fs.readFileSync(DB_FILE);
    dbInstance = new SQL.Database(fileBuffer);
  } else {
    dbInstance = new SQL.Database();
  }

  // Enable foreign keys
  dbInstance.run("PRAGMA foreign_keys = ON;");
  
  // Initialize tables
  initSchema(dbInstance);
  saveDb();

  return dbInstance;
}

export function saveDb() {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (err) {
    console.error('Error saving SQLite database to disk:', err);
  }
}

// Database helper functions for standard query patterns
export function queryAll<T = any>(sql: string, params: any[] = []): T[] {
  if (!dbInstance) throw new Error('Database not initialized');
  const stmt = dbInstance.prepare(sql);
  stmt.bind(params);
  const rows: T[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as unknown as T);
  }
  stmt.free();
  return rows;
}

export function queryOne<T = any>(sql: string, params: any[] = []): T | null {
  const rows = queryAll<T>(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

export function executeRun(sql: string, params: any[] = []): { lastInsertRowid: number; changes: number } {
  if (!dbInstance) throw new Error('Database not initialized');
  dbInstance.run(sql, params);
  const lastIdRes = queryOne<{ id: number }>('SELECT last_insert_rowid() as id');
  const changesRes = queryOne<{ c: number }>('SELECT changes() as c');
  saveDb();
  return {
    lastInsertRowid: lastIdRes ? lastIdRes.id : 0,
    changes: changesRes ? changesRes.c : 0,
  };
}

function initSchema(db: Database) {
  db.run(`
    CREATE TABLE IF NOT EXISTS company_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      company_name_bn TEXT NOT NULL,
      company_name_en TEXT NOT NULL,
      subtitle TEXT,
      logo_url TEXT,
      address TEXT,
      phone TEXT,
      email TEXT,
      currency TEXT DEFAULT 'BDT (৳)',
      working_days_per_month INTEGER DEFAULT 26,
      daily_standard_hours REAL DEFAULT 8.0,
      ot_multiplier REAL DEFAULT 1.5,
      late_days_per_penalty_day INTEGER DEFAULT 3,
      absent_penalty_days_ratio INTEGER DEFAULT 3,
      allow_negative_stock INTEGER DEFAULT 0,
      sms_provider TEXT DEFAULT 'generic',
      sms_api_key TEXT,
      sms_sender_id TEXT,
      google_sheet_id TEXT,
      google_sheet_synced_at TEXT,
      updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT,
      role TEXT NOT NULL DEFAULT 'staff',
      permissions TEXT NOT NULL,
      is_active INTEGER DEFAULT 1,
      must_change_password INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      last_login_at TEXT
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      timestamp TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_code TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      guardian_name TEXT,
      dob TEXT,
      gender TEXT DEFAULT 'Male',
      mobile TEXT NOT NULL,
      address TEXT,
      nid TEXT,
      joining_date TEXT NOT NULL,
      department TEXT NOT NULL,
      designation TEXT NOT NULL,
      employee_type TEXT NOT NULL DEFAULT 'worker',
      salary_type TEXT NOT NULL DEFAULT 'monthly',
      basic_salary REAL NOT NULL DEFAULT 0,
      overtime_rate REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      emergency_contact TEXT,
      photo_url TEXT,
      notes TEXT,
      blood_group TEXT DEFAULT 'B+',
      created_at TEXT NOT NULL,
      updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      status TEXT NOT NULL,
      in_time TEXT,
      out_time TEXT,
      ot_hours REAL DEFAULT 0,
      notes TEXT,
      recorded_by TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT,
      UNIQUE(employee_id, date),
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS leave_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      leave_type TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      total_days INTEGER NOT NULL DEFAULT 1,
      reason TEXT,
      status TEXT NOT NULL DEFAULT 'approved',
      approved_by TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gate_passes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pass_no TEXT UNIQUE NOT NULL,
      employee_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      out_time TEXT NOT NULL,
      expected_return_time TEXT,
      actual_return_time TEXT,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'approved',
      approved_by TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS payroll_periods (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      month_year TEXT UNIQUE NOT NULL,
      total_employees INTEGER DEFAULT 0,
      total_payable REAL DEFAULT 0,
      total_paid REAL DEFAULT 0,
      total_due REAL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'draft',
      finalized_by TEXT,
      finalized_at TEXT,
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payroll_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      payroll_period_id INTEGER NOT NULL,
      employee_id INTEGER NOT NULL,
      employee_name TEXT NOT NULL,
      employee_code TEXT NOT NULL,
      department TEXT NOT NULL,
      designation TEXT NOT NULL,
      salary_type TEXT NOT NULL,
      basic_salary REAL NOT NULL,
      present_days REAL DEFAULT 0,
      late_days REAL DEFAULT 0,
      absent_days REAL DEFAULT 0,
      leave_days REAL DEFAULT 0,
      late_penalty_days REAL DEFAULT 0,
      absent_penalty_days REAL DEFAULT 0,
      total_penalty_days REAL DEFAULT 0,
      attendance_deduction REAL DEFAULT 0,
      payable_days REAL DEFAULT 0,
      ot_hours REAL DEFAULT 0,
      ot_amount REAL DEFAULT 0,
      bonus_amount REAL DEFAULT 0,
      allowances REAL DEFAULT 0,
      advance_deduction REAL DEFAULT 0,
      other_deduction REAL DEFAULT 0,
      net_payable REAL NOT NULL,
      paid_amount REAL DEFAULT 0,
      due_amount REAL DEFAULT 0,
      payment_status TEXT NOT NULL DEFAULT 'unpaid',
      payment_date TEXT,
      payment_method TEXT,
      payment_ref TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT,
      FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id) ON DELETE CASCADE,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS salary_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      payroll_item_id INTEGER NOT NULL,
      employee_id INTEGER NOT NULL,
      amount REAL NOT NULL,
      payment_date TEXT NOT NULL,
      payment_method TEXT NOT NULL,
      transaction_ref TEXT,
      notes TEXT,
      recorded_by TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (payroll_item_id) REFERENCES payroll_items(id) ON DELETE CASCADE,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_code TEXT UNIQUE NOT NULL,
      name_bn TEXT NOT NULL,
      name_en TEXT NOT NULL,
      category TEXT NOT NULL,
      unit TEXT DEFAULT 'Pcs',
      cost_price REAL NOT NULL DEFAULT 0,
      selling_price REAL NOT NULL DEFAULT 0,
      description TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS product_variants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      size TEXT NOT NULL,
      color TEXT NOT NULL,
      sku TEXT UNIQUE NOT NULL,
      stock_quantity INTEGER NOT NULL DEFAULT 0,
      opening_stock INTEGER NOT NULL DEFAULT 0,
      alert_threshold INTEGER DEFAULT 20,
      created_at TEXT NOT NULL,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS production_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_no TEXT NOT NULL,
      date TEXT NOT NULL,
      product_id INTEGER NOT NULL,
      variant_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      defect_quantity INTEGER DEFAULT 0,
      supervisor_name TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
      FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS shops (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      owner_name TEXT,
      phone TEXT NOT NULL,
      address TEXT,
      credit_limit REAL DEFAULT 50000,
      opening_due REAL DEFAULT 0,
      current_due REAL DEFAULT 0,
      total_purchased REAL DEFAULT 0,
      total_paid REAL DEFAULT 0,
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_no TEXT UNIQUE NOT NULL,
      sale_date TEXT NOT NULL,
      shop_id INTEGER,
      shop_name TEXT NOT NULL,
      customer_name TEXT,
      customer_phone TEXT,
      gross_amount REAL NOT NULL,
      discount_amount REAL DEFAULT 0,
      net_amount REAL NOT NULL,
      paid_amount REAL DEFAULT 0,
      due_amount REAL DEFAULT 0,
      payment_method TEXT DEFAULT 'Cash',
      payment_status TEXT NOT NULL DEFAULT 'due',
      notes TEXT,
      created_by TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (shop_id) REFERENCES shops(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      variant_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      size TEXT NOT NULL,
      color TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      total_price REAL NOT NULL,
      FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id),
      FOREIGN KEY (variant_id) REFERENCES product_variants(id)
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      expense_no TEXT UNIQUE NOT NULL,
      expense_date TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      amount REAL NOT NULL,
      payment_method TEXT DEFAULT 'Cash',
      paid_to TEXT,
      receipt_url TEXT,
      approved_by TEXT,
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS collections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      collection_no TEXT UNIQUE NOT NULL,
      collection_date TEXT NOT NULL,
      shop_id INTEGER NOT NULL,
      shop_name TEXT NOT NULL,
      invoice_no TEXT,
      amount REAL NOT NULL,
      payment_method TEXT DEFAULT 'Cash',
      collected_by TEXT,
      remaining_due REAL DEFAULT 0,
      notes TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (shop_id) REFERENCES shops(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sms_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      recipient_phone TEXT NOT NULL,
      recipient_name TEXT,
      message TEXT NOT NULL,
      template_type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'sent',
      response_id TEXT,
      sent_at TEXT NOT NULL,
      cost REAL DEFAULT 0.40
    );

    CREATE TABLE IF NOT EXISTS google_sheet_sync_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sync_type TEXT NOT NULL,
      status TEXT NOT NULL,
      records_count INTEGER DEFAULT 0,
      details TEXT,
      synced_at TEXT NOT NULL
    );
  `);

    try {
      db.run("ALTER TABLE employees ADD COLUMN blood_group TEXT DEFAULT 'B+'");
    } catch (e) {}
    try {
      db.run("ALTER TABLE employees ADD COLUMN resignation_date TEXT");
    } catch (e) {}
    try {
      db.run("ALTER TABLE employees ADD COLUMN resignation_reason TEXT");
    } catch (e) {}
    try {
      db.run("ALTER TABLE payroll_items ADD COLUMN late_days REAL DEFAULT 0");
    } catch (e) {}
    try {
      db.run("ALTER TABLE payroll_items ADD COLUMN late_penalty_days REAL DEFAULT 0");
    } catch (e) {}
    try {
      db.run("ALTER TABLE payroll_items ADD COLUMN absent_penalty_days REAL DEFAULT 0");
    } catch (e) {}
    try {
      db.run("ALTER TABLE payroll_items ADD COLUMN total_penalty_days REAL DEFAULT 0");
    } catch (e) {}
    try {
      db.run("ALTER TABLE payroll_items ADD COLUMN attendance_deduction REAL DEFAULT 0");
    } catch (e) {}
    try {
      db.run("ALTER TABLE payroll_items ADD COLUMN payable_days REAL DEFAULT 0");
    } catch (e) {}
    try {
      db.run("ALTER TABLE company_settings ADD COLUMN late_days_per_penalty_day INTEGER DEFAULT 3");
    } catch (e) {}
    try {
      db.run("ALTER TABLE company_settings ADD COLUMN absent_penalty_days_ratio INTEGER DEFAULT 3");
    } catch (e) {}

    // Seed default admin and company settings if not present
    seedInitialData(db);
  }

export function clearAllDemoData(db?: Database) {
  const database = db || dbInstance;
  if (!database) return;
  try {
    const tablesToClear = [
      'sale_items',
      'sales',
      'collections',
      'salary_payments',
      'payroll_items',
      'payroll_periods',
      'attendance',
      'leave_records',
      'gate_passes',
      'expenses',
      'production_records',
      'cutting_orders',
      'material_movements',
      'raw_materials',
      'product_variants',
      'products',
      'shops',
      'employees'
    ];

    database.run('PRAGMA foreign_keys = OFF;');
    for (const table of tablesToClear) {
      try {
        database.run(`DELETE FROM ${table}`);
      } catch (tableErr) {
        // Table might not exist in schema, skip silently
      }
    }
    database.run('PRAGMA foreign_keys = ON;');
    saveDb();
    console.log('🧹 All demo data cleared and saved to disk.');
  } catch (err) {
    console.error('Error clearing demo data:', err);
  }
}

function seedInitialData(db: Database) {
  const existingSettings = queryOne('SELECT id, company_name_bn FROM company_settings WHERE id = 1');
  if (!existingSettings) {
    db.run(`
      INSERT INTO company_settings (
        id, company_name_bn, company_name_en, subtitle, logo_url, address, phone, email,
        currency, working_days_per_month, daily_standard_hours, ot_multiplier, allow_negative_stock,
        sms_provider, sms_sender_id, updated_at
      ) VALUES (
        1,
        'টেক্স ওয়্যার অ্যাপারেলস',
        'Texware Apparels',
        'স্মার্ট গার্মেন্টস ও গেঞ্জি উৎপাদন এবং পাইকারি বিক্রয় ব্যবস্থাপনা',
        '',
        'প্লট #১২, কোনাবাড়ী শিল্প এলাকা, গাজীপুর, বাংলাদেশ',
        '+880 1711-234567',
        'info@texwareapparels.com',
        'BDT (৳)',
        26,
        8.0,
        1.5,
        0,
        'Bangladeshi Bulk SMS API (Onnorokom/Greenweb/Elitbuzz)',
        'TEXWARE',
        datetime('now')
      );
    `);
  } else {
    // Ensure company name is set to Texware Apparels
    try {
      db.run(`
        UPDATE company_settings SET
          company_name_bn = 'টেক্স ওয়্যার অ্যাপারেলস',
          company_name_en = 'Texware Apparels',
          sms_sender_id = 'TEXWARE',
          email = 'info@texwareapparels.com'
        WHERE id = 1 AND (company_name_bn LIKE '%মেঘনা%' OR company_name_bn = '' OR company_name_bn IS NULL)
      `);
    } catch (e) {}
  }

  // Check admin users
  const adminUser = queryOne('SELECT id FROM users WHERE username = ?', ['admin']);
  const demoUser = queryOne('SELECT id FROM users WHERE username = ?', ['Demo']);

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync('1234', salt);

  const fullPermissions = JSON.stringify([
    'view_dashboard',
    'manage_employees',
    'view_employees',
    'mark_attendance',
    'view_attendance',
    'manage_payroll',
    'view_payroll',
    'approve_payroll',
    'finalize_payroll',
    'send_sms',
    'google_sheets_sync',
    'manage_users',
    'manage_settings',
    'print_documents',
    'export_data'
  ]);

  if (!adminUser) {
    db.run(`
      INSERT INTO users (
        username, password_hash, full_name, email, role, permissions, is_active, must_change_password, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `, [
      'admin',
      hash,
      'প্রধান অ্যাডমিন (Admin Master)',
      'admin@texwareapparels.com',
      'admin',
      fullPermissions,
      1,
      0
    ]);
  }

  if (!demoUser) {
    db.run(`
      INSERT INTO users (
        username, password_hash, full_name, email, role, permissions, is_active, must_change_password, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `, [
      'Demo',
      hash,
      'অ্যাডমিন (Admin Master)',
      'admin@texwareapparels.com',
      'admin',
      fullPermissions,
      1,
      0
    ]);
  }

  // Ensure database remains 100% clean of all demo records
  clearAllDemoData(db);
}

// Keep functions for backwards compatibility (no-op: no demo data is seeded)
export function seedAccountingData(_db?: Database) {
  // Demo seeding is intentionally disabled per user instructions: "কোন ডেমো তথ্য থাকবে না"
}

export function seedSampleWorkers(_db?: Database) {
  // Demo workers seeding is intentionally disabled per user instructions: "কোন ডেমো তথ্য থাকবে না"
}


